'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const config = JSON.parse($('logic-config').textContent);
  const gameKey = config.gameKey;
  const isPattern = gameKey === 'pattern-logic';
  const totalSteps = config.totalSteps;
  const levelNames = {easy:'Dễ', normal:'Bình thường', advanced:'Khá', hard:'Khó'};
  const directions = {
    U:{x:0,y:-1,text:'↑',name:'lên'}, D:{x:0,y:1,text:'↓',name:'xuống'},
    L:{x:-1,y:0,text:'←',name:'sang trái'}, R:{x:1,y:0,text:'→',name:'sang phải'}
  };
  const storeGet = (key,fallback) => { try {let v=localStorage.getItem('lb-'+key);return v===null?fallback:JSON.parse(v);}catch{return fallback;} };
  const storeSet = (key,v) => { try {localStorage.setItem('lb-'+key,JSON.stringify(v));}catch{} };
  const escapeHtml = v => String(v ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const state = {
    profiles:[], playerId:null, catalog:null, level:storeGet(gameKey+'-level','easy'),
    sound:storeGet('sound',true), reduceMotion:storeGet('reduced-motion',false),
    generation:0, pending:false, started:false, finished:false, saving:false,
    startPromise:null, roundToken:null, stage:0, attempts:0, mistakes:0, hints:0,
    elapsed:0, startTime:0, interval:null, timeouts:[], busy:false,
    question:null, wrongChoices:new Set(), maze:null, queue:[], robotPosition:null,
    running:false, robotSuccessPending:false, shownHint:null, visited:new Set(), audio:null,
  };
  const api = async (action, body=null, params={}) => {
    const url = new URL('../../api/index.php', location.href);
    url.searchParams.set('action',action);
    Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,String(v)));
    let response;
    try {response = await fetch(url,body===null?{credentials:'same-origin',cache:'no-store'}:{
      method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},
      body:JSON.stringify(body),credentials:'same-origin',cache:'no-store'
    });} catch {throw new Error('Chưa kết nối được máy chủ PHP.');}
    let value;try{value=await response.json();}catch{throw new Error('PHP chưa trả về dữ liệu hợp lệ.');}
    if(!response.ok||!value.ok)throw new Error(value.error||'Có lỗi xảy ra.');
    return value.data;
  };
  function later(fn,ms){ const timer=setTimeout(()=>{state.timeouts=state.timeouts.filter(x=>x!==timer);fn();},ms);state.timeouts.push(timer);return timer; }
  function clearTasks(){ state.timeouts.forEach(clearTimeout);state.timeouts=[];clearInterval(state.interval);state.interval=null; }
  function shuffle(arr){for(let i=arr.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]];}return arr;}
  function random(min,max){return Math.floor(Math.random()*(max-min+1))+min;}
  const durationText=seconds=>`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
  function feedback(message,kind='neutral'){$('logic-feedback').textContent=message;$('logic-feedback').dataset.tone=kind;}
  function toast(message){const el=$('logic-toast');el.textContent=message;el.hidden=false;clearTimeout(toast.timeout);toast.timeout=setTimeout(()=>el.hidden=true,3600);}
  function sound(kind){
    if(!state.sound)return;
    try {
      const AudioCtx=window.AudioContext||window.webkitAudioContext;if(!AudioCtx)return;
      state.audio ||= new AudioCtx();if(state.audio.state==='suspended')state.audio.resume().catch(()=>{});
      const notes=kind==='win'?[523,659,784,988]:kind==='correct'?[620,830]:kind==='wrong'?[310,275]:[520];
      notes.forEach((note,i)=>{
        const t=state.audio.currentTime+i*.105;
        const o=state.audio.createOscillator(),v=state.audio.createGain();
        o.type='sine';o.frequency.value=note;
        v.gain.setValueAtTime(.0001,t);v.gain.exponentialRampToValueAtTime(.055,t+.015);v.gain.exponentialRampToValueAtTime(.0001,t+.19);
        o.connect(v);v.connect(state.audio.destination);o.start(t);o.stop(t+.2);
      });
    }catch{ /* Optional audio: never block the game. */ }
  }
  function updateStats(){
    $('logic-progress-stat').textContent=`${state.stage}/${totalSteps}`;
    $('logic-attempts').textContent=String(state.attempts);
    $('logic-time').textContent=durationText(state.elapsed);
    $('logic-step-dots').innerHTML=Array.from({length:totalSteps},(_,i)=>`<i class="${i<state.stage?'done':i===state.stage?'current':''}"></i>`).join('');
    $('logic-stage-label').textContent=state.finished?`Hoàn thành ${totalSteps} / ${totalSteps}`:`${isPattern?'Câu':'Bản đồ'} ${Math.min(state.stage+1,totalSteps)} / ${totalSteps}`;
    $('logic-restart').disabled=state.saving;
    $('logic-hint').disabled=state.saving||state.finished||state.busy||state.running;
    $('logic-level-tag').textContent=`✦ ${levelNames[state.level]}`;
    document.querySelectorAll('[data-level]').forEach(btn=>{const active=btn.dataset.level===state.level;btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));});
  }
  function begin(){
    if(state.started)return;
    state.started=true;
    state.startTime=performance.now();
    state.interval=setInterval(()=>{state.elapsed=Math.min(86400,Math.floor((performance.now()-state.startTime)/1000));$('logic-time').textContent=durationText(state.elapsed);},250);
    const generation=state.generation;
    state.startPromise=api('start_challenge',{game_key:gameKey,difficulty:state.level,player_id:state.playerId}).then(data=>{
      if(generation===state.generation)state.roundToken=data.round_token;
      return data;
    }).catch(e=>{if(generation===state.generation)toast(`Không thể lưu: ${e.message}`);throw e;});
    state.startPromise.catch(()=>{});
  }
  function freshRound(){
    state.generation++;
    clearTasks();state.started=false;state.finished=false;state.saving=false;state.pending=false;
    state.startPromise=null;state.roundToken=null;state.stage=0;state.attempts=0;state.mistakes=0;state.hints=0;
    state.elapsed=0;state.busy=false;state.running=false;state.robotSuccessPending=false;state.shownHint=null;state.wrongChoices.clear();state.queue=[];
    $('logic-stars').textContent='☆☆☆';
    if(isPattern)buildQuestion();else buildMission();
    updateStats();feedback(isPattern?'Bé hãy chọn hình đúng với quy luật nào! ✨':'Xếp mũi tên cho Robot rồi nhấn Chạy thử nhé! ✨');
  }
  function modal(body){$('logic-modal-body').innerHTML=body;$('logic-modal').hidden=false;$('logic-modal-close').focus();}
  function closeModal(){
    $('logic-modal').hidden=true;
    // Dismissing the congratulation modal by X, Escape or clicking outside
    // also advances once. The child can never get stuck on a finished map.
    if(!isPattern&&state.robotSuccessPending){
      state.robotSuccessPending=false;
      nextStage(true);
    }
  }
  function checkBeforeChange(action){
    if(state.saving){toast('Kết quả đang được lưu, bé nhé!');return;}
    if(!state.started||state.finished){action();return;}
    modal(`<div class="result-mark">↻</div><h2 id="logic-modal-title">Bé muốn đổi ván mới?</h2><p>Ván đang chơi sẽ không được tính thành tích. Bé có muốn đổi không?</p><div class="logic-modal-actions"><button type="button" id="logic-stay" class="logic-soft-button">Chơi tiếp</button><button type="button" id="logic-change" class="logic-main-button">Đổi ván mới →</button></div>`);
    $('logic-stay').onclick=closeModal;
    $('logic-change').onclick=()=>{closeModal();action();};
  }
  async function finish(){
    if(state.finished||state.saving||state.stage!==totalSteps)return;
    state.finished=true;state.saving=true;state.busy=true;
    if(state.started){state.elapsed=Math.min(86400,Math.floor((performance.now()-state.startTime)/1000));}
    clearInterval(state.interval);state.interval=null;updateStats();
    const generation=state.generation;
    try {
      const started=await state.startPromise;
      if(generation!==state.generation)return;
      const record=await api('finish_challenge',{
        round_token:started.round_token, attempts:state.attempts, mistakes:state.mistakes,
        hints_used:state.hints, duration_seconds:state.elapsed
      });
      if(generation!==state.generation)return;
      state.saving=false;state.busy=false;updateStats();
      $('logic-stars').textContent='★'.repeat(record.stars)+'☆'.repeat(3-record.stars);
      sound('win');feedback('Hoan hô! Bé đã hoàn thành và lưu thành tích rồi! 🌟','good');
      modal(`<div class="result-mark">🏆</div><div class="result-small">HOAN HÔ NHÀ THÁM HIỂM NHÍ!</div><h2 id="logic-modal-title">Bé giỏi quá!</h2><p>Bé đã hoàn thành <strong>${totalSteps} ${isPattern?'câu tìm quy luật':'nhiệm vụ lập trình'}</strong> rồi!</p><div class="result-big-stars">${'★'.repeat(record.stars)}<span>${'☆'.repeat(3-record.stars)}</span></div><div class="result-overview"><div><b>${record.attempts}</b><small>Lượt thử</small></div><div><b>${durationText(record.duration_seconds)}</b><small>Thời gian</small></div><div><b>${Number(record.accuracy).toFixed(1)}%</b><small>Chính xác</small></div></div><p class="result-saved">✓ Đã lưu vào lịch sử của bé</p><div class="logic-modal-actions"><a class="logic-soft-button" href="../../index.php#history">Xem lịch sử</a><button type="button" id="logic-play-again" class="logic-main-button">Chơi tiếp →</button></div>`);
      $('logic-play-again').onclick=()=>{closeModal();freshRound();};
    }catch(e){
      if(generation!==state.generation)return;
      state.saving=false;state.busy=false;updateStats();
      modal(`<div class="result-mark">♡</div><h2 id="logic-modal-title">Bé đã hoàn thành rồi!</h2><p>Chưa lưu được kết quả: ${escapeHtml(e.message)}. Bé có thể thử lưu lại.</p><div class="logic-modal-actions"><button id="logic-save-retry" class="logic-main-button">↻ Thử lưu lại</button></div>`);
      $('logic-save-retry').onclick=()=>{closeModal();state.finished=false;finish();};
    }
  }
  function nextStage(immediate=false){
    state.stage++;updateStats();
    if(state.stage===totalSteps){finish();return;}
    const generation=state.generation;
    const advance=()=>{
      if(generation!==state.generation)return;
      if(isPattern)buildQuestion();else buildMission();
      state.busy=false;updateStats();
    };
    if(immediate)advance();else later(advance,750);
  }
  function makeProfiles(){
    const el=$('logic-player');
    el.innerHTML=state.profiles.map(p=>`<option value="${escapeHtml(p.id)}" ${p.id===state.playerId?'selected':''}>${escapeHtml(p.name)}</option>`).join('');
  }

  // PATTERN LOGIC: each puzzle has exactly one key matching one of four distinct choices.
  const shapeNames = ['circle','square','triangle','diamond','star'];
  const shapeColors = [
    {id:'coral',value:'#fa929d',bg:'#ffeff0'},
    {id:'sky',value:'#79b3f4',bg:'#edf6ff'},
    {id:'mint',value:'#69cda8',bg:'#eafaf2'},
    {id:'yellow',value:'#f0bf60',bg:'#fff8e6'},
    {id:'lilac',value:'#ac91eb',bg:'#f5f0ff'},
  ];
  const patternRules={
    easy:[[0,1],[0,0,1,1]],
    normal:[[0,1,2],[0,0,1],[0,1,1],[0,1,2,2]],
  };
  function tokenKey(t){return t.kind==='shape'?`${t.shape}|${t.color.id}`:t.id;}
  function buildQuestion(){
    state.busy=false;state.wrongChoices.clear();
    const level=state.level;
    if(level==='easy'||level==='normal'){
      const pool=[...state.catalog.animals.items,...state.catalog.fruits.items,...state.catalog.vehicles.items];
      const symbols=shuffle(pool).slice(0,4).map(item=>({kind:'image',id:item.id+'-'+item.src,src:'../../'+item.src,label:item.label}));
      const patterns=patternRules[level];
      const rule=patterns[(state.stage+random(0,patterns.length-1))%patterns.length];
      const length=level==='easy'?6:8;
      const target=length-1;
      const sequence=Array.from({length},(_,i)=>symbols[rule[i%rule.length]]);
      state.question={sequence,target,answer:tokenKey(sequence[target]),choices:shuffle([...symbols]),kind:'image',label:'Tìm quy luật của các hình',detail:'Hình nào sẽ xuất hiện ở dấu hỏi ?'};
    }else{
      const shapePool=shuffle([...shapeNames]);
      const colors=shuffle([...shapeColors]);
      const shapeCycle=level==='advanced'?2:3;
      const colorCycle=level==='advanced'?3:2;
      const length=level==='advanced'?9:10;
      const target=level==='hard'?(state.stage%2===0?length-1:length-3):length-1;
      const make=i=>({kind:'shape',shape:shapePool[i%shapeCycle],color:colors[i%colorCycle]});
      const sequence=Array.from({length},(_,i)=>make(i));
      const correct=sequence[target];
      const options=[correct,
        {kind:'shape',shape:shapePool[(target+1)%shapeCycle],color:correct.color},
        {kind:'shape',shape:correct.shape,color:colors[(target+1)%colorCycle]},
        {kind:'shape',shape:shapePool[(target+1)%shapeCycle],color:colors[(target+1)%colorCycle]},
      ];
      state.question={sequence,target,answer:tokenKey(correct),choices:shuffle(options),kind:'shape',label:'Quy luật hình và màu',detail:'Chú ý cả hình dạng và màu sắc nhé!'};
    }
    // Randomized alternatives are distinct; the correct option appears once.
    renderQuestion();
  }
  function tokenMarkup(token){
    if(token.kind==='image')return `<span class="pattern-token"><img draggable="false" src="${escapeHtml(token.src)}" alt="${escapeHtml(token.label)}"></span>`;
    return `<span class="pattern-token shape-token" style="--token-bg:${token.color.bg}"><span class="pattern-geometry shape-${token.shape}" style="--shape-color:${token.color.value}"></span></span>`;
  }
  function renderQuestion(){
    const q=state.question;
    $('pattern-prompt').textContent=q.label;
    $('pattern-subtitle').textContent=q.detail;
    $('pattern-sequence').dataset.difficulty=state.level;
    $('pattern-sequence').innerHTML=q.sequence.map((t,i)=>`<div class="pattern-cell ${i===q.target?'is-missing':''}" aria-label="${i===q.target?'Ô còn thiếu':'Hình số '+(i+1)}">${i===q.target?'<span class="pattern-question">?</span>':tokenMarkup(t)}<small>${i+1}</small></div>`).join('');
    $('pattern-options').innerHTML=q.choices.map((choice,i)=>`<button type="button" data-choice="${i}" aria-label="Đáp án ${String.fromCharCode(65+i)}" class="pattern-answer"><span class="answer-index">${String.fromCharCode(65+i)}</span>${tokenMarkup(choice)}<span class="answer-decor">✦</span></button>`).join('');
  }
  function chooseAnswer(index){
    if(state.busy||state.finished||state.saving||state.wrongChoices.has(index))return;
    const q=state.question,choice=q?.choices[index];if(!choice)return;
    begin();state.attempts++;
    const button=$('pattern-options').querySelector(`[data-choice="${index}"]`);
    if(tokenKey(choice)===q.answer){
      state.busy=true;button.classList.add('correct');sound('correct');feedback('Chính xác! Bé đã tìm ra quy luật rồi! 🌟','good');
      const missing=$('pattern-sequence').querySelector('.is-missing');
      missing.innerHTML=tokenMarkup(choice)+`<small>${q.target+1}</small>`;
      missing.classList.add('is-solved');missing.classList.remove('is-missing');
      nextStage();
    }else{
      state.mistakes++;state.wrongChoices.add(index);button.disabled=true;button.classList.add('try-another');sound('wrong');
      feedback('Gần đúng rồi! Bé nhìn lại những hình ở đầu dãy nhé. 💜','try');
    }
    updateStats();
  }

  // LITTLE CODER: 5 distinct, hand-curated maps per difficulty (20 in total).
  // S = robot start, G = star, # = rock, . = free cell.
  // Keeping layouts here allows a stable, progressively varied five-map journey.
  const robotMaps = {
    easy: [
      ['...G','....','....','S...'],
      ['S...','...#','...G','....'],
      ['#...','G...','....','.#.S'],
      ['#.S.','....','....','G..#'],
      ['G.#.','#..S','....','#...'],
    ],
    normal: [
      ['....G','.....','.....','...#.','S##..'],
      ['S...#','.....','.#..#','...#G','.....'],
      ['G..#.','#...#','.#...','.....','#...S'],
      ['.#S.#','..#..','.##.#','.....','G....'],
      ['.#..#','.....','S.#..','##..#','#...G'],
    ],
    advanced: [
      ['#....G','......','..#...','.#...#','#.....','S...#.'],
      ['S.#...','...#..','...#.#','.....#','#..#.G','.....#'],
      ['G.....','......','.#..#.','.#.#..','.##..#','.##..S'],
      ['...S#.','.##...','##.#..','...#.#','......','G#..#.'],
      ['#...#.','......','S#...#','...#.#','##.#..','..#.#G'],
    ],
    hard: [
      ['#.#...G','#.##...','...##..','.......','...#...','.....#.','S#.#...'],
      ['S#...#.','...#...','..#..#.','....#..','.....#.','.#.###G','.#.....'],
      ['G.#..#.','#..##..','..###.#','.#....#','..#....','.......','....#.S'],
      ['#.#S..#','##.#...','.#.....','..##.#.','.#.....','......#','G..#..#'],
      ['.......','##..##.','...#...','S###.#.','#......','..#.###','#.....G'],
    ],
  };
  function cellKey(x,y){return `${x},${y}`;}
  function shortestRoute(map,from){
    const startKey=cellKey(from.x,from.y),goalKey=cellKey(map.goal.x,map.goal.y);
    const queue=[{x:from.x,y:from.y,path:[]}];let head=0;const seen=new Set([startKey]);
    while(head<queue.length){
      const n=queue[head++];if(cellKey(n.x,n.y)===goalKey)return n.path;
      for(const d of ['R','U','L','D']){
        const x=n.x+directions[d].x,y=n.y+directions[d].y,k=cellKey(x,y);
        if(x<0||y<0||x>=map.size||y>=map.size||map.walls.has(k)||seen.has(k))continue;
        seen.add(k);queue.push({x,y,path:[...n.path,d]});
      }
    }
    return null;
  }
  function buildMaze(){
    const rows=robotMaps[state.level]?.[state.stage];
    if(!rows)throw new Error('Không tìm thấy bản đồ của cấp độ này.');
    const size=rows.length, walls=new Set();
    let start=null,goal=null;
    for(let y=0;y<size;y++){
      if(rows[y].length!==size)throw new Error('Bản đồ không đúng kích thước.');
      for(let x=0;x<size;x++){
        const c=rows[y][x];
        if(c==='S'){
          if(start)throw new Error('Bản đồ có nhiều vị trí xuất phát.');
          start={x,y};
        }else if(c==='G'){
          if(goal)throw new Error('Bản đồ có nhiều đích.');
          goal={x,y};
        }else if(c==='#')walls.add(cellKey(x,y));
        else if(c!=='.')throw new Error('Bản đồ chứa ô không hợp lệ.');
      }
    }
    if(!start||!goal)throw new Error('Bản đồ thiếu điểm bắt đầu hoặc đích.');
    const map={size,start,goal,walls};
    const solution=shortestRoute(map,start);
    if(!solution||solution.length>24)throw new Error('Bản đồ chưa có đường đi phù hợp.');
    return {...map,solution};
  }
  function buildMission(){
    state.busy=false;state.running=false;state.queue=[];state.shownHint=null;
    state.maze=buildMaze();state.robotPosition={...state.maze.start};state.visited=new Set([cellKey(state.maze.start.x,state.maze.start.y)]);
    $('robot-map-size').textContent=`${state.maze.size} × ${state.maze.size} ô`;
    $('robot-prompt').textContent=`Bản đồ ${state.stage+1} / ${totalSteps} · Đưa Robot đến ngôi sao!`;
    $('robot-hint-message').textContent='💡 Xếp mũi tên rồi nhấn Chạy thử!';
    renderMap();renderQueue();
  }
  function renderMap(){
    const map=state.maze;if(!map)return;
    const target=$('robot-map');target.style.setProperty('--map-size',map.size);
    target.innerHTML=Array.from({length:map.size*map.size},(_,i)=>{
      const x=i%map.size,y=Math.floor(i/map.size),key=cellKey(x,y);
      const isRock=map.walls.has(key),goal=key===cellKey(map.goal.x,map.goal.y);
      const here=key===cellKey(state.robotPosition.x,state.robotPosition.y);
      const start=key===cellKey(map.start.x,map.start.y);
      const classList=['robot-cell',isRock?'robot-rock':'',goal?'robot-goal':'',start?'robot-start':'',state.visited.has(key)?'robot-visited':''];
      return `<div data-cell="${key}" class="${classList.filter(Boolean).join(' ')}">${isRock?'<img alt="Tảng đá" src="../../assets/images/robot/rock.svg">':here?'<img class="robot-sprite" alt="Robot" src="../../assets/images/robot/robot.svg">':goal?'<img alt="Ngôi sao" src="../../assets/images/robot/goal.svg">':start?'<span class="start-circle">BĐ</span>':''}</div>`;
    }).join('');
  }
  function renderQueue(active=-1){
    const queue=$('robot-queue');
    const max=Math.min(26,state.maze.solution.length+8);
    const locked=state.running||state.busy||state.saving||state.finished;
    $('robot-command-count').textContent=`${state.queue.length} / ${max} bước`;
    queue.innerHTML=state.queue.length ? state.queue.map((d,i)=>`
      <span class="queue-command ${active===i?'executing':''}" role="group" aria-label="Bước ${i+1}: đi ${directions[d].name}">
        <span class="queue-symbol" aria-hidden="true">${directions[d].text}</span>
        <small class="queue-number">${i+1}</small>
        <button type="button" class="queue-remove" data-remove-step="${i}" aria-label="Xóa bước ${i+1}: đi ${directions[d].name}" title="Xóa bước ${i+1}" ${locked?'disabled':''}><span aria-hidden="true">×</span></button>
      </span>`).join('') : '<span class="robot-queue-empty">Chọn mũi tên để bắt đầu...</span>';
    document.querySelectorAll('[data-command]').forEach(button=>button.disabled=locked||state.queue.length>=max);
    $('robot-undo').disabled=locked||!state.queue.length;
    $('robot-clear').disabled=locked||!state.queue.length;
    $('robot-run').disabled=locked||!state.queue.length;
  }
  function removeCommandAt(index){
    // Removing any step must preserve the relative order of all remaining steps.
    if(state.running||state.busy||state.saving||state.finished)return;
    if(!Number.isInteger(index)||index<0||index>=state.queue.length)return;
    state.queue.splice(index,1);
    // An edited program always starts from the original starting square.
    state.robotPosition={...state.maze.start};
    state.visited=new Set([cellKey(state.maze.start.x,state.maze.start.y)]);
    renderMap();renderQueue();sound('tap');
    feedback(`Đã xóa bước ${index+1}. Bé chọn mũi tên khác nhé!`);
    const rest=$('robot-queue').querySelectorAll('.queue-remove');
    if(rest.length)rest[Math.min(index,rest.length-1)].focus();
  }
  function addCommand(command){
    if(!directions[command]||state.running||state.busy||state.finished||state.saving)return;
    const max=Math.min(26,state.maze.solution.length+8);
    if(state.queue.length>=max){toast('Đã đủ mũi tên cho nhiệm vụ này. Bé thử chạy nhé!');return;}
    begin();state.queue.push(command);sound('tap');
    renderQueue();feedback('Hay lắm! Bé xếp tiếp mũi tên hoặc nhấn Chạy thử nào.');
  }
  function previewQueue(){
    let pos={...state.maze.start};
    for(const d of state.queue){
      const nx=pos.x+directions[d].x,ny=pos.y+directions[d].y;
      if(nx<0||ny<0||nx>=state.maze.size||ny>=state.maze.size||state.maze.walls.has(cellKey(nx,ny)))return null;
      pos={x:nx,y:ny};
      if(pos.x===state.maze.goal.x&&pos.y===state.maze.goal.y)return pos;
    }
    return pos;
  }
  function runRobot(){
    if(state.running||state.busy||state.finished||!state.queue.length)return;
    begin();state.running=true;state.busy=true;state.attempts++;
    state.robotPosition={...state.maze.start};state.visited=new Set([cellKey(state.maze.start.x,state.maze.start.y)]);
    renderMap();renderQueue();updateStats();
    $('robot-hint-message').textContent='🤖 Robot đang thực hiện từng lệnh...';
    feedback('Robot bắt đầu di chuyển! Bé xem chương trình của mình nhé.','neutral');
    const commands=[...state.queue],gen=state.generation;
    function stopAndRetry(reason){
      if(gen!==state.generation)return;
      state.mistakes++;state.running=false;state.busy=false;renderQueue();updateStats();sound('wrong');
      $('robot-hint-message').textContent='💡 Chọn Sửa lệnh hoặc Xóa hết để thử lại.';
      showRobotError(reason);
    }
    function travel(i){
      if(gen!==state.generation)return;
      if(i>=commands.length){stopAndRetry('incomplete');return;}
      renderQueue(i);
      later(()=>{
        if(gen!==state.generation)return;
        const delta=directions[commands[i]];
        const nx=state.robotPosition.x+delta.x,ny=state.robotPosition.y+delta.y;
        if(nx<0||ny<0||nx>=state.maze.size||ny>=state.maze.size||state.maze.walls.has(cellKey(nx,ny))){
          stopAndRetry(nx<0||ny<0||nx>=state.maze.size||ny>=state.maze.size?'bounds':'obstacle');return;
        }
        state.robotPosition={x:nx,y:ny};state.visited.add(cellKey(nx,ny));renderMap();
        if(nx===state.maze.goal.x&&ny===state.maze.goal.y){
          state.running=false;state.busy=true;renderQueue();sound('correct');
          $('robot-hint-message').textContent='⭐ Robot đã chạm ngôi sao!';
          feedback('Robot đã đến đích! Bé giỏi quá! 🌟','good');showRobotSuccess();return;
        }
        travel(i+1);
      },state.reduceMotion?130:350);
    }
    travel(0);
  }
  function hint(){
    if(state.finished||state.busy||state.running||state.saving)return;
    if(isPattern){
      const q=state.question;
      const firstKey=tokenKey(q.sequence[0]);
      state.hints++;
      if(q.kind==='shape')feedback('Gợi ý: Hình dạng lặp lại một nhịp, màu sắc lặp lại một nhịp khác. Bé nhìn 3 hình đầu nhé! ☀','hint');
      else feedback(`Gợi ý: Bé hãy tìm xem hình đầu tiên xuất hiện lại ở những vị trí nào nhé! ☀`,'hint');
      $('pattern-sequence').classList.add('show-hint');
      later(()=>$('pattern-sequence')?.classList.remove('show-hint'),1700);
    }else{
      const pos=previewQueue();
      let route=pos?shortestRoute(state.maze,pos):null;
      if(!route){route=shortestRoute(state.maze,state.maze.start);state.hints++;$('robot-hint-message').textContent='☀ Có lệnh đi vào chỗ bị chặn. Bé xóa vài lệnh rồi thử nhé!';}
      else if(route.length===0){$('robot-hint-message').textContent='⭐ Robot đã có đường đến đích. Nhấn Chạy thử nhé!';return;}
      else{state.hints++;$('robot-hint-message').textContent=`☀ Gợi ý: Mũi tên tiếp theo có thể là ${directions[route[0]].text} (${directions[route[0]].name}).`;}
      if(route.length){const button=$(`[data-command="${route[0]}"]`);button?.classList.add('hint-direction');later(()=>button?.classList.remove('hint-direction'),2200);}
      feedback('Bé có thể dùng gợi ý để tìm ra bước tiếp theo nhé! ☀','hint');
    }
    sound('tap');
  }
  function setSidebarOpen(open){
    $('logic-workspace').classList.toggle('sidebar-collapsed',!open);
    const toggle=$('logic-panel-toggle');
    toggle.setAttribute('aria-expanded',String(open));
    toggle.textContent=open?'✕ Đóng tùy chọn':'⚙ Tùy chọn';
  }
  function openCreateProfile(){
    modal(`<h2 id="logic-modal-title">Thêm hồ sơ bé</h2><form id="logic-profile-form" class="logic-profile-form"><label for="logic-profile-name">Tên bé</label><input id="logic-profile-name" type="text" maxlength="24" autocomplete="off" required placeholder="Ví dụ: Bé Na"><div class="logic-modal-actions"><button type="button" id="logic-profile-cancel" class="logic-soft-button">Hủy</button><button type="submit" id="logic-profile-save" class="logic-main-button">Tạo hồ sơ</button></div></form>`);
    $('logic-profile-cancel').onclick=closeModal;
    $('logic-profile-name').focus();
    $('logic-profile-form').onsubmit=async event=>{
      event.preventDefault();
      const button=$('logic-profile-save');button.disabled=true;
      try{
        const player=await api('create_profile',{name:$('logic-profile-name').value});
        state.profiles.push(player);state.playerId=player.id;storeSet('player-id',player.id);
        makeProfiles();closeModal();freshRound();toast('Đã tạo hồ sơ cho '+player.name+'!');
      }catch(e){toast(e.message);button.disabled=false;}
    };
  }
  function showRobotSuccess(){
    if(state.robotSuccessPending||state.finished||state.saving)return;
    state.robotSuccessPending=true;
    const last=state.stage===totalSteps-1;
    const message=last
      ? `Bé đã giúp Robot vượt qua cả <strong>${totalSteps} bản đồ</strong>!`
      : `Robot đã tới ngôi sao ở <strong>bản đồ ${state.stage+1}/${totalSteps}</strong>!`;
    modal(`<div class="result-mark robot-success-mark"><img src="../../assets/images/robot/goal.svg" alt="Ngôi sao chiến thắng"></div><h2 id="logic-modal-title">🎉 ${last?'Xuất sắc!':'Chúc mừng bé!'}</h2><p>${message}</p><div class="robot-success-progress">${last?'🏆 Hoàn thành cấp độ':'⭐ Đã vượt qua bản đồ '+(state.stage+1)+' / '+totalSteps}</div><div class="logic-modal-actions"><button type="button" id="robot-next-map" class="logic-main-button">${last?'Xem thành tích':'Bản đồ tiếp theo →'}</button></div>`);
    $('robot-next-map').onclick=closeModal;
    $('robot-next-map').focus();
  }
  function showRobotError(reason){
    const heading=reason==='obstacle'?'Robot gặp tảng đá!':reason==='bounds'?'Robot ra ngoài bản đồ!':'Robot chưa đến đích!';
    const suggestion=reason==='obstacle'?'Đường có đá chắn. Bé đổi hướng đi nhé.':reason==='bounds'?'Robot đi ra ngoài ô. Bé chọn hướng khác nhé.':'Bé thử thêm hoặc đổi các mũi tên nhé.';
    feedback(suggestion,'try');
    modal(`<div class="result-mark robot-error-mark">↶</div><h2 id="logic-modal-title">${heading}</h2><p>${suggestion}</p><div class="logic-modal-actions"><button type="button" id="robot-edit-queue" class="logic-main-button">Sửa lệnh</button><button type="button" id="robot-reset-queue" class="logic-soft-button">Xóa hết</button></div>`);
    $('robot-edit-queue').onclick=()=>{closeModal();$('robot-queue').scrollIntoView({block:'nearest',behavior:'auto'});};
    $('robot-reset-queue').onclick=()=>{
      closeModal();state.queue=[];state.robotPosition={...state.maze.start};
      state.visited=new Set([cellKey(state.maze.start.x,state.maze.start.y)]);
      renderMap();renderQueue();feedback('Chọn mũi tên rồi thử lại nhé!');
    };
  }
  function bind(){
    $('logic-panel-toggle').onclick=()=>setSidebarOpen($('logic-workspace').classList.contains('sidebar-collapsed'));
    $('logic-sidebar-close').onclick=()=>setSidebarOpen(false);
    $('logic-add-profile').onclick=()=>checkBeforeChange(openCreateProfile);
    $('logic-sound').onclick=()=>{state.sound=!state.sound;storeSet('sound',state.sound);updateSound();if(state.sound)sound('tap');};
    $('logic-fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast('Trình duyệt không hỗ trợ chế độ toàn màn hình.');}};
    $('logic-restart').onclick=()=>checkBeforeChange(freshRound);
    $('logic-hint').onclick=hint;
    $('logic-levels').addEventListener('click',e=>{const b=e.target.closest('[data-level]');if(!b||b.dataset.level===state.level)return;checkBeforeChange(()=>{state.level=b.dataset.level;storeSet(gameKey+'-level',state.level);freshRound();});});
    $('logic-player').onchange=e=>{
      const wanted=e.target.value;e.target.value=state.playerId;
      if(wanted===state.playerId)return;
      checkBeforeChange(async()=>{
        try{await api('select_profile',{player_id:wanted});state.playerId=wanted;storeSet('player-id',wanted);makeProfiles();freshRound();toast('Đã đổi hồ sơ của bé!');}
        catch(err){toast(err.message);makeProfiles();}
      });
    };
    $('logic-modal-close').onclick=closeModal;
    $('logic-modal').onclick=e=>{if(e.target===$('logic-modal'))closeModal();};
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('logic-modal').hidden)closeModal();});
    if(isPattern){
      $('pattern-options').addEventListener('click',e=>{const b=e.target.closest('[data-choice]');if(b)chooseAnswer(Number(b.dataset.choice));});
    }else{
      document.querySelectorAll('[data-command]').forEach(btn=>btn.onclick=()=>addCommand(btn.dataset.command));
      // Each small X removes exactly its own step, including a step in the middle.
      $('robot-queue').addEventListener('click',event=>{
        const remove=event.target.closest('[data-remove-step]');
        if(!remove||!$('robot-queue').contains(remove))return;
        event.preventDefault();
        removeCommandAt(Number(remove.dataset.removeStep));
      });
      $('robot-undo').onclick=()=>{if(state.running||state.busy||!state.queue.length)return;removeCommandAt(state.queue.length-1);};
      $('robot-clear').onclick=()=>{if(state.running||state.busy)return;state.queue=[];renderQueue();};
      $('robot-run').onclick=runRobot;
    }
  }
  function updateSound(){$('logic-sound').textContent=state.sound?'♫':'♪̸';$('logic-sound').setAttribute('aria-pressed',String(state.sound));$('logic-sound').classList.toggle('muted',!state.sound);}
  async function initialize(){
    bind();updateSound();
    document.body.classList.toggle('reduce-motion',state.reduceMotion);
    if(!levelNames[state.level])state.level='easy';
    try{
      const data=await api('bootstrap');state.catalog=data.themes;state.profiles=data.players;state.playerId=data.player_id;
      const remember=storeGet('player-id',state.playerId);
      if(remember!==state.playerId&&data.players.some(p=>p.id===remember)){
        try{await api('select_profile',{player_id:remember});state.playerId=remember;}catch{}
      }
      makeProfiles();freshRound();
    }catch(err){
      feedback('Chưa tải được trò chơi. Hãy kiểm tra PHP và thử tải lại trang.','try');
      toast(err.message);
      if(isPattern)$('pattern-sequence').innerHTML=`<div class="load-error">${escapeHtml(err.message)}</div>`;
      else $('robot-map').innerHTML=`<div class="load-error">${escapeHtml(err.message)}</div>`;
    }
  }
  initialize();
})();
