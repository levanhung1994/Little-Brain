# LITTLE BRAIN – PC EDITION · 6 trò chơi

Ứng dụng web giáo dục cho trẻ 4–6 tuổi, tối ưu máy tính Windows/laptop. **PHP 8.3 trở lên**, JavaScript, CSS và các hình SVG lưu offline. **Không yêu cầu MySQL, SQLite, CDN hoặc Internet** khi sử dụng tại nhà.

## Sáu trò chơi đã mở

| Game | Nội dung | Cấp độ |
|---|---|---|
| Memory Match | Lật thẻ tìm hai hình giống nhau, 5 chủ đề, 6/12/20/30 ô | Dễ, Vừa, Khá, Khó |
| Pattern Logic | Tìm hình còn thiếu trong chuỗi quy luật; 6 câu/ván | Dễ, Vừa, Khá, Khó |
| Little Coder | Lập trình Robot bằng mũi tên; 5 bản đồ/cấp độ, tổng 20 map | Dễ, Vừa, Khá, Khó |
| Balance Puzzle | Cân trái cây theo trọng lượng; 5 câu/cấp độ | Dễ, Vừa, Khá, Khó |
| **Missing Number – Tìm số bí mật** | Điền con số còn thiếu vào phép tính, 5 câu/ván, nhiều biến thể | Dễ, Vừa, Khá, Khó |
| **Little Shop – Siêu thị của bé** | Chọn trái cây vào giỏ, dùng tiền xu để trả tiền hoặc tính tiền thừa; 5 đơn/ván | Dễ, Vừa, Khá, Khó |

Ngoài 6 trò chơi đã mở, kho còn 5 trò đánh dấu **Sắp ra mắt**. Giao diện PC mở trực tiếp Kho trò chơi, trong game bảng Tùy chọn mặc định thu gọn để bàn chơi rộng.

## Chi tiết hai game toán mới

### Tìm số bí mật (`public/games/missing-number/index.php`)

- **Dễ:** cộng trong phạm vi 5; trực quan hóa bằng chấm tròn.
- **Vừa:** cộng trừ trong phạm vi 10, dấu hỏi ở các vị trí khác nhau.
- **Khá:** cộng trừ trong phạm vi 20, tìm số hạng/số bị trừ/số trừ.
- **Khó:** hai phép tính liên tiếp trong phạm vi 20.
- Mỗi ván có 5 câu rút ngẫu nhiên từ ngân hàng câu đố. Có 4 đáp án lớn, gợi ý, thông báo khi sai, popup chúc mừng sau từng câu, đánh giá 1–3 sao và lưu JSON sau khi xong cả ván.

### Siêu thị của bé (`public/games/little-shop/index.php`)

- **Dễ:** mua một loại trái cây; đếm và chọn xu trả vừa đủ.
- **Vừa:** mua nhiều loại trái cây; cộng giá hàng và dùng tiền xu.
- **Khá:** mua nhiều loại; tính số xu được thối lại khi đưa 10/15/20 xu.
- **Khó:** mua nhiều loại với số lượng lớn hơn; thanh toán bằng 20 xu và tính tiền thừa.
- Có giỏ hàng, nút `+`/`−` theo từng loại quả, tổng tiền realtime, nút xóa giỏ, tiền xu 1/2/5/10, bốn đáp án tiền thừa, kiểm tra đúng danh sách, gợi ý, popup chúc mừng và kết quả 1–3 sao. Mỗi ván rút 5 đơn từ nhiều bộ đơn chuẩn bị sẵn, không lặp trong cùng ván.
- Xu là **đơn vị tiền mô phỏng trong game**, không phải tiền thật.

## Cài đặt mới trên Windows

1. Giải nén bản `LITTLE_BRAIN_6_GAMES_PC_FULL.zip` và vào thư mục `little-brain-memory-match`.
2. Đảm bảo máy đã cài PHP 8.3+ và `php` có trong PATH.
3. Nhấp đúp `start-windows.bat` **hoặc** mở CMD trong **thư mục gốc dự án (nơi chứa `public` và `app`)** rồi chạy:

```bat
php -S 127.0.0.1:8080 -t public public/router.php
```

4. Mở Edge/Chrome tại **http://127.0.0.1:8080**. Nhấn `Ctrl+F5` sau khi cập nhật file.

Nếu báo `Directory public does not exist`, hãy chuyển CMD vào đúng thư mục chứa `public/`, không chạy từ `C:\Users\...>`.

## Nâng cấp từ bản 4 game – giữ nguyên dữ liệu

**Nên dùng:** `LITTLE_BRAIN_6_GAMES_PC_UPDATE_ONLY.zip`.

1. Dừng cửa sổ PHP bằng `Ctrl+C`.
2. Sao lưu nguyên thư mục **`data/`** trong website đang dùng.
3. Giải nén **nội dung** của ZIP cập nhật **trực tiếp vào thư mục gốc chứa `app/`, `public/`**, đồng ý ghi đè file trùng tên. Không tạo một cấp `little-brain-memory-match` lồng thêm vào dự án cũ.
4. **Không xóa hoặc ghi đè `data/`.** ZIP UPDATE **không** chứa `data/` và không đụng tới hồ sơ/lịch sử cũ.
5. Khởi động lại PHP, sau đó `Ctrl+F5` trong trình duyệt.

Bản **FULL** để cài đặt mới. Nếu chuyển sang thư mục mới, sao lưu và chép `data/` từ bản cũ sang trước khi chơi.

## Lịch sử, điểm số và lưu trữ

- PHP tự khởi tạo các file JSON trong `data/` (nằm **ngoài** thư mục web root `public/`). Dữ liệu được bảo vệ bằng khóa file và bản sao `.bak`.
- Cả sáu trò chơi dùng chung hồ sơ; lịch sử mỗi game có mã `game_key` riêng và được tổng hợp **kỷ lục theo game/cấp độ**, không ghi đè kỷ lục Memory Match.
- Hai game toán mới chỉ lưu kết quả **khi hoàn thành đủ 5 câu/đơn**. Độ chính xác = `5 / số lượt trả lời tính điểm × 100%`; 3 sao khi ≥80%, 2 sao khi ≥60%, còn lại 1 sao. Chọn sai được thử lại, không có hình phạt.
- Kết quả được PHP tính sao lại và dùng mã phiên chơi để tránh lưu trùng. Số lần gợi ý được thống kê riêng.
- Khi chạy Apache/IIS, **trỏ DocumentRoot/web root vào `public/`**, tuyệt đối không trỏ vào thư mục gốc có `data/`.
- Kiểm tra bảo mật: `http://127.0.0.1:8080/data/history.json` phải trả **404**.

## Cấu trúc chính

```text
little-brain-memory-match/
  app/
    GameService.php             # lưu ván, hồ sơ, thành tích các game
    games.php                   # danh mục game
    math-game-template.php      # giao diện chung hai game toán mới
    logic-game-template.php     # Tìm quy luật + Robot
    balance-game-template.php
    Storage.php                 # an toàn JSON
  public/
    index.php                   # Kho trò chơi + Memory Match
    games/
      missing-number/index.php
      little-shop/index.php
      pattern-logic/index.php
      robot-coder/index.php
      balance-puzzle/index.php
    assets/css/math-games.css
    assets/js/math-games.js
    assets/images/math/*.svg
    api/index.php
  data/                         # PRIVATE, KHÔNG thuộc web root
  tests/
  start-windows.bat
```

Cả hai game mới dùng hình SVG đã nằm sẵn trong `assets/images/`, không có phụ thuộc bên ngoài. Các trò khác vẫn giữ logic đã có.
