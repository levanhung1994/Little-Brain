# RETRO ARCADE - Official EmulatorJS Stable Offline Asset Installer
# Run on your own Windows PC with Internet access; all runtime files remain local.
param(
    [string]$Source = 'https://cdn.emulatorjs.org/stable/data',
    [switch]$SkipLegacyCores
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$dest = Join-Path $root 'emulator\data'
$Source = $Source.TrimEnd('/')
$files = @(
    'loader.js',
    'emulator.min.js',
    'emulator.min.css',
    'version.json',
    'src/GameManager.js',
    'src/compression.js',
    'src/emulator.js',
    'src/gamepad.js',
    'src/nipplejs.js',
    'src/shaders.js',
    'src/socket.io.min.js',
    'src/storage.js',
    'compression/extractzip.js',
    'compression/extract7z.js',
    'compression/libunrar.js',
    'compression/libunrar.wasm',
    'localization/en-US.json',
    'localization/vi-VN.json',
    'cores/cores.json',
    'cores/reports/fbneo.json',
    'cores/reports/fceumm.json',
    'cores/reports/mame2003.json',
    'cores/fbneo-wasm.data',
    'cores/fceumm-wasm.data',
    'cores/mame2003-wasm.data'
)
if (!$SkipLegacyCores) {
    $files += @(
        'cores/fbneo-legacy-wasm.data',
        'cores/fceumm-legacy-wasm.data',
        'cores/mame2003-legacy-wasm.data'
    )
}
Write-Host ''
Write-Host '========================================' -ForegroundColor Magenta
Write-Host ' RETRO ARCADE | EMULATORJS INSTALLER ' -ForegroundColor Magenta
Write-Host '========================================' -ForegroundColor Magenta
Write-Host ('Official source : ' + $Source)
Write-Host ('Install folder : ' + $dest)
Write-Host 'No commercial ROM or BIOS files are downloaded.'
Write-Host ''
$failed = @()
$counter = 0
foreach ($relative in $files) {
    $counter++
    $localFile = Join-Path $dest ($relative.Replace('/','\'))
    $parent = Split-Path -Parent $localFile
    if (!(Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    if ((Test-Path -LiteralPath $localFile) -and (Get-Item -LiteralPath $localFile).Length -gt 100) {
        Write-Host ('['+$counter+'/'+$files.Count+'] Cached: '+$relative) -ForegroundColor DarkGreen
        continue
    }
    $url = $Source + '/' + $relative
    $temporary = $localFile + '.download'
    $success = $false
    for ($try = 1; $try -le 3 -and !$success; $try++) {
        try {
            Write-Host ('['+$counter+'/'+$files.Count+'] Download '+$relative+' ('+$try+'/3)') -ForegroundColor Cyan
            Invoke-WebRequest -Uri $url -OutFile $temporary -UseBasicParsing -TimeoutSec 180
            $size = (Get-Item -LiteralPath $temporary).Length
            $minimum = if ($relative -like 'cores/*-wasm.data') { 200000 } elseif ($relative -like '*emulator.min.js') { 100000 } else { 80 }
            if ($size -lt $minimum) { throw ('Unexpectedly small response (' + $size + ' bytes).') }
            $signature = [System.IO.File]::ReadAllBytes($temporary)
            $head = [System.Text.Encoding]::ASCII.GetString($signature,0,[Math]::Min(20,$signature.Length)).ToLowerInvariant()
            if ($head.StartsWith('<!doctype') -or $head.StartsWith('<html')) { throw 'Server returned HTML, not an asset.' }
            if (Test-Path -LiteralPath $localFile) { Remove-Item -LiteralPath $localFile -Force }
            Move-Item -LiteralPath $temporary -Destination $localFile -Force
            $success = $true
        } catch {
            Write-Warning ($relative+': '+$_.Exception.Message)
            if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
            if ($try -lt 3) { Start-Sleep -Seconds 2 }
        }
    }
    if (!$success) { $failed += $relative }
}
Write-Host ''
if ($failed.Count -eq 0) {
    Write-Host ('SUCCESS: ' + $files.Count + ' official emulator assets are installed.') -ForegroundColor Green
    Write-Host 'You can now run RETRO ARCADE entirely offline (with your own matching ROM/BIOS).'
    Write-Host 'Use PHP localhost and click Refresh Library.'
} else {
    Write-Host ('INCOMPLETE: ' + $failed.Count + ' files could not be downloaded:') -ForegroundColor Red
    foreach ($item in $failed) { Write-Host (' - ' + $item) -ForegroundColor Red }
    Write-Host 'Check connectivity and rerun this script. Existing downloads are retained.'
    exit 1
}
