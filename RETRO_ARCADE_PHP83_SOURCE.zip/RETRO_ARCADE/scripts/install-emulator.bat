@echo off
setlocal
cd /d "%~dp0.."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-emulator.ps1" %*
if errorlevel 1 (echo EmulatorJS install incomplete. & pause & exit /b 1)
echo.
echo Press any key to close.
pause >nul
