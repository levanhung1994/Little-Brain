<?php
declare(strict_types=1);
require_once __DIR__ . '/lib/app.php';
$library = ra_library();
$user = ra_user_data();
ra_head('Kho Game Tuổi Thơ', 'library');
?>
<div class="app-shell">
<?php ra_sidebar('home'); ?>
<main class="main-content">
  <header class="topbar">
    <button class="icon-button mobile-menu" type="button" id="menu-toggle" aria-label="Menu">☰</button>
    <div class="breadcrumbs">GAME LIBRARY <span>/</span> <strong>KHO GAME TUỔI THƠ</strong></div>
    <div class="top-actions"><span class="top-status"><i></i> LOCAL SYSTEM</span><a href="settings.php" class="icon-button settings-shortcut" title="Cài đặt">⚙</a><span class="avatar">RA</span></div>
  </header>
  <section class="page-inner">
    <div class="section-eyebrow"><span></span> YOUR PERSONAL TIME MACHINE <b> / </b> EST. 1990</div>
    <section class="hero">
      <div class="hero-copy">
        <span class="hero-chip">★ CLASSIC GAME COLLECTION</span>
        <h1>CHƠI LẠI<br><em>TUỔI THƠ.</em></h1>
        <p>Từ Metal Slug đến Contra. Những trận chiến huyền thoại, ngay trong trình duyệt của bạn.</p>
        <div class="hero-actions"><a href="#library" class="btn btn-primary">⊳ &nbsp; KHÁM PHÁ KHO GAME</a><button class="btn btn-ghost" id="hero-refresh" type="button">↻ &nbsp; QUÉT GAME</button></div>
        <div class="hero-tags"><span>● NO DATABASE</span><span>● OFFLINE READY*</span><span>● 2 PLAYER SUPPORT</span></div>
      </div>
      <div class="hero-image" role="img" aria-label="Minh họa game arcade phong cách retro"><div class="hero-tint"></div><div class="hero-art-label">PRESS <b>START</b> <small>TO REWIND</small></div></div>
      <span class="hero-deco">01 / COLLECTION</span>
    </section>
    <section class="stats-strip" aria-label="Thống kê thư viện">
      <div class="stat"><span class="stat-icon magenta">▦</span><div><b id="stat-total">0</b><small>GAME ĐÃ THÊM</small></div></div>
      <div class="stat"><span class="stat-icon violet">◈</span><div><b id="stat-arcade">0</b><small>GAME ARCADE</small></div></div>
      <div class="stat"><span class="stat-icon cyan">♡</span><div><b id="stat-favorites">0</b><small>YÊU THÍCH</small></div></div>
      <div class="stat"><span class="stat-icon gold">▶</span><div><b id="stat-ready">0</b><small>CÓ THỂ THỬ CHƠI</small></div></div>
    </section>
    <section class="library" id="library">
      <div class="section-row"><div><div class="eyebrow-small">YOUR GAME SHELF</div><h2>KHO GAME <span>ARCADE</span></h2></div><button class="btn btn-outlined btn-small" type="button" id="refresh-library">↻ &nbsp; REFRESH LIBRARY</button></div>
      <div class="controls-bar"><div class="filter-scroller" id="filter-bar">
          <button class="filter-pill active" data-filter="all">Tất cả <span id="filter-count"></span></button>
          <button class="filter-pill" data-filter="arcade">Arcade</button>
          <button class="filter-pill" data-filter="neogeo">Neo Geo</button>
          <button class="filter-pill" data-filter="pgm">IGS PGM</button>
          <button class="filter-pill" data-filter="nes">NES</button>
          <button class="filter-pill" data-filter="favorites">♥ Yêu thích</button>
      </div><div class="search-box"><span>⌕</span><input id="search-games" type="search" placeholder="Tìm tên game, ROM..." autocomplete="off"><span class="search-hint">/</span></div></div>
      <div class="grid-note"><span id="grid-note">Đang đọc thư viện…</span><select id="genre-filter" aria-label="Thể loại"><option value="all">Mọi thể loại</option><option value="action">Hành động</option><option value="fighting">Đối kháng</option><option value="shooter">Bắn súng</option><option value="other">Khác</option></select></div>
      <div class="games-grid" id="games-grid" aria-live="polite"></div>
      <div id="empty-state" class="empty-state hidden"><div class="empty-glyph">◈</div><h3>Chưa tìm thấy game</h3><p>Hãy sao chép ROM vào thư mục tương ứng rồi chọn Refresh Library.</p><a class="btn btn-primary btn-small" href="settings.php">HƯỚNG DẪN CÀI ĐẶT →</a></div>
    </section>
    <section id="recent-section" class="recent-section hidden"><div class="section-row"><div><div class="eyebrow-small">PICK UP WHERE YOU LEFT OFF</div><h2>CHƠI <span>GẦN ĐÂY</span></h2></div></div><div class="recent-list" id="recent-games"></div></section>
    <section class="start-guide" id="guide"><div class="guide-icon">✦</div><div><strong>BẮT ĐẦU TRONG 3 BƯỚC</strong><p>Chạy <code>scripts/install-emulator.ps1</code> một lần khi có Internet → chép ROM/BIOS hợp pháp vào <code>games/</code> → Refresh Library. Sau đó có thể chơi offline.</p></div><a href="settings.php">XEM HƯỚNG DẪN <b>↗</b></a></section>
    <footer class="footer">RETRO ARCADE <span>•</span> ALL GAMES ARE USER SUPPLIED <span>•</span> NO ROMS INCLUDED <span class="footer-right">© 2026 LOCAL EDITION</span></footer>
  </section>
</main></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<script>window.RA_INIT = <?php echo json_encode(['games'=>$library['games'], 'user'=>$user, 'filter'=>($_GET['filter'] ?? 'all'), 'can_admin'=>ra_can_admin()], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE); ?>;</script>
<script src="assets/js/app.js" defer></script>
</body></html>
