<?php
declare(strict_types=1);

const RA_ROOT = __DIR__ . '/..';
const RA_DATA = RA_ROOT . '/data';
const RA_SUPPORTED_CORES = ['fbneo', 'fceumm', 'mame2003'];

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('retro_arcade_sid');
    session_set_cookie_params(['httponly'=>true, 'samesite'=>'Lax', 'path'=>'/']);
    session_start();
}
if (empty($_SESSION['ra_csrf'])) {
    $_SESSION['ra_csrf'] = bin2hex(random_bytes(24));
}
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

function ra_json(string $file, array $fallback = []): array {
    if (!is_file($file)) return $fallback;
    $contents = @file_get_contents($file);
    if ($contents === false) return $fallback;
    $json = json_decode($contents, true);
    return is_array($json) ? $json : $fallback;
}

function ra_save_json(string $file, array $value): void {
    $dir = dirname($file);
    if (!is_dir($dir) || !is_writable($dir)) throw new RuntimeException('Không thể ghi dữ liệu vào ' . $dir);
    $lockFile = $dir . '/.' . basename($file) . '.lock';
    $lock = @fopen($lockFile, 'c');
    if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Không thể khóa file dữ liệu.');
    try {
        $tmp = tempnam($dir, '.ra_');
        if ($tmp === false) throw new RuntimeException('Không thể tạo file tạm.');
        try {
            $encoded = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            if (file_put_contents($tmp, $encoded . "\n") === false) throw new RuntimeException('Lỗi ghi dữ liệu JSON.');
            if (PHP_OS_FAMILY === 'Windows' && file_exists($file)) @unlink($file);
            if (!@rename($tmp, $file)) throw new RuntimeException('Không thể thay thế dữ liệu JSON.');
        } finally {
            if (file_exists($tmp)) @unlink($tmp);
        }
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function ra_escape(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function ra_filename_ok(string $name): bool {
    return strlen($name) < 190 && (bool)preg_match('/\A[a-zA-Z0-9][a-zA-Z0-9._() -]*\z/D', $name)
        && $name !== '.' && $name !== '..' && !str_contains($name, '..');
}

function ra_id_ok(string $id): bool {
    if (!preg_match('/\A(arcade|nes):(.+)\z/D', $id, $matches)) return false;
    $name = $matches[2];
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return ra_filename_ok($name) && in_array($ext, $matches[1] === 'arcade' ? ['zip'] : ['nes','unf','unif','fds'], true);
}

function ra_file_for_id(string $id): ?string {
    if (!ra_id_ok($id)) return null;
    [$dir, $name] = explode(':', $id, 2);
    $base = realpath(RA_ROOT . '/games/' . $dir);
    $path = realpath(RA_ROOT . '/games/' . $dir . '/' . $name);
    if (!$base || !$path || dirname($path) !== $base || !is_file($path) || is_link(RA_ROOT . '/games/' . $dir . '/' . $name)) return null;
    return $path;
}

function ra_public_url(string $dir, string $file): string {
    return 'games/' . rawurlencode($dir) . '/' . rawurlencode($file);
}

function ra_bios_ok(string $file): bool {
    if (!ra_filename_ok($file) || !in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['zip', 'rom', 'bin'], true)) return false;
    $full = RA_ROOT . '/games/bios/' . $file;
    return is_file($full) && !is_link($full) && filesize($full) > 0;
}

function ra_filesystem_entries(): array {
    $results = [];
    foreach (['arcade','nes'] as $dir) {
        $base = RA_ROOT . '/games/' . $dir;
        if (!is_dir($base)) continue;
        $iterator = new DirectoryIterator($base);
        foreach ($iterator as $entry) {
            if (!$entry->isFile() || $entry->isLink()) continue;
            $filename = $entry->getFilename();
            $id = $dir . ':' . $filename;
            if (!ra_id_ok($id)) continue;
            if ($dir === 'arcade' && in_array(strtolower($filename), ['neogeo.zip', 'pgm.zip', 'isgsm.zip'], true)) continue;
            $results[$id] = ['id'=>$id, 'filename'=>$filename, 'folder'=>$dir, 'bytes'=>$entry->getSize(), 'mtime'=>$entry->getMTime()];
        }
    }
    ksort($results, SORT_STRING);
    return array_values($results);
}

function ra_rom_validation(array $raw): array {
    $path = ra_file_for_id($raw['id']);
    if ($path === null || $raw['bytes'] < 16) return [false, 'File quá nhỏ hoặc không truy cập được.'];
    $handle = @fopen($path, 'rb');
    if (!$handle) return [false, 'Không đọc được file ROM.'];
    $bytes = fread($handle, 16);
    fclose($handle);
    $ext = strtolower(pathinfo($raw['filename'], PATHINFO_EXTENSION));
    if ($raw['folder'] === 'arcade') {
        if (!str_starts_with($bytes, "PK\x03\x04") && !str_starts_with($bytes, "PK\x05\x06")) return [false, 'File ZIP không có chữ ký ZIP hợp lệ.'];
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            $result = $zip->open($path, ZipArchive::CHECKCONS);
            if ($result !== true) return [false, 'File ZIP hỏng hoặc không đọc được.'];
            $isEmpty = $zip->numFiles < 1;
            $zip->close();
            if ($isEmpty) return [false, 'File ZIP trống.'];
        }
    } elseif ($ext === 'nes') {
        if (substr($bytes, 0, 4) !== "NES\x1A") return [false, 'Thiếu iNES header (NES\\x1A).'];
    } elseif (in_array($ext, ['unf','unif'], true) && substr($bytes, 0, 4) !== 'UNIF') {
        return [false, 'File UNIF không đúng header.'];
    } elseif ($ext === 'fds' && !str_starts_with($bytes, 'FDS') && $raw['bytes'] % 65500 !== 0) {
        return [false, 'FDS header/kích thước không phù hợp.'];
    }
    return [true, null];
}

function ra_metadata(): array {
    return ra_json(RA_DATA . '/games.json');
}

function ra_core_requirements(string $core): array {
    $base = RA_ROOT . '/emulator/data/';
    // All files below are included by our installer; detect partial installations before launch.
    $paths = ['loader.js', 'emulator.min.js', 'emulator.min.css',
        'src/GameManager.js', 'src/compression.js', 'compression/extractzip.js',
        'cores/reports/' . $core . '.json',
        'cores/' . $core . '-wasm.data', 'cores/' . $core . '-legacy-wasm.data'];
    $missing = [];
    foreach ($paths as $path) {
        if (!is_file($base.$path) || filesize($base.$path) < 100) $missing[] = $path;
    }
    return $missing;
}

function ra_resolve_game(array $raw, array $metadata): array {
    $id = $raw['id'];
    $specific = isset($metadata[$id]) && is_array($metadata[$id]) ? $metadata[$id] : [];
    $custom = $specific !== [];
    $filename = $raw['filename'];
    $folder = $raw['folder'];
    $defaultTitle = ucwords(str_replace(['_', '-'], ' ', pathinfo($filename, PATHINFO_FILENAME)));
    $platform = $folder === 'nes' ? 'nes' : 'arcade';
    $core = $folder === 'nes' ? 'fceumm' : 'fbneo';
    if ($custom) {
        $platform = (string)($specific['platform'] ?? $platform);
        $core = (string)($specific['core'] ?? $core);
    }
    $allowPlatforms = $folder === 'nes' ? ['nes'] : ['arcade','neogeo','pgm'];
    if (!in_array($platform, $allowPlatforms, true)) $platform = $folder === 'nes' ? 'nes' : 'arcade';
    if (!in_array($core, RA_SUPPORTED_CORES, true) || ($folder === 'nes' && $core !== 'fceumm') || ($folder === 'arcade' && $core === 'fceumm')) {
        $core = $folder === 'nes' ? 'fceumm' : 'fbneo';
    }
    $bios = [];
    if (isset($specific['bios']) && is_array($specific['bios'])) {
        foreach ($specific['bios'] as $name) if (is_string($name) && ra_filename_ok($name)) $bios[] = $name;
    } elseif ($platform === 'neogeo') $bios = ['neogeo.zip'];
    elseif ($platform === 'pgm') $bios = ['pgm.zip'];
    elseif (strtolower(pathinfo($filename, PATHINFO_EXTENSION)) === 'fds') $bios = ['disksys.rom'];
    $bios = array_values(array_unique($bios));
    $multipleBios = count($bios) > 1;
    $parent = $folder === 'arcade' && is_string($specific['parent'] ?? null) ? trim($specific['parent']) : '';
    if ($parent !== '' && (!ra_filename_ok($parent) || !str_ends_with(strtolower($parent), '.zip'))) $parent = '';
    $cover = is_string($specific['cover'] ?? null) ? $specific['cover'] : '';
    if ($cover !== '' && (!ra_filename_ok($cover) || !preg_match('/\.(svg|webp|png|jpg|jpeg)$/iD', $cover))) $cover = '';
    if ($cover === '') {
        $stem = strtolower(pathinfo($filename, PATHINFO_FILENAME));
        $cover = match (true) {
            str_starts_with($stem,'mslug') => 'metal-slug.svg',
            str_starts_with($stem,'killbld') => 'killing-blade.svg',
            str_starts_with($stem,'contra') => 'contra.svg',
            str_starts_with($stem,'kof') => 'kof.svg',
            str_starts_with($stem,'samsho') => 'samurai.svg',
            default => 'default.svg',
        };
    }
    if (!is_file(RA_ROOT . '/assets/covers/' . $cover)) $cover = 'default.svg';
    $genre = (string)($specific['genre'] ?? 'other');
    if (!in_array($genre, ['action','fighting','shooter','other'], true)) $genre = 'other';
    [$valid, $issue] = ra_rom_validation($raw);
    $missingBios = array_values(array_filter($bios, fn($name) => !ra_bios_ok($name)));
    $parentId = $parent !== '' ? 'arcade:'.$parent : null;
    $missingParent = $parentId !== null && ra_file_for_id($parentId) === null;
    $missingAssets = ra_core_requirements($core);
    $problems = [];
    if (!$valid) $problems[] = $issue;
    if ($folder === 'arcade' && !$custom) $problems[] = 'ROM Arcade chưa có mapping core/BIOS. Hãy cấu hình trước khi chơi.';
    if ($missingBios !== []) $problems[] = 'Thiếu BIOS: '.implode(', ', $missingBios);
    if ($multipleBios) $problems[] = 'Mapping đang có nhiều BIOS; EmulatorJS chỉ nhận một EJS_biosUrl.';
    if ($missingParent) $problems[] = 'Thiếu parent ROM: ' . $parent;
    if ($missingAssets !== []) $problems[] = 'Chưa cài EmulatorJS: ' . implode(', ', $missingAssets);
    $readiness = !$valid ? 'invalid' : ($folder === 'arcade' && !$custom ? 'unconfigured' : ($missingBios || $missingParent || $multipleBios ? 'missing_dependencies' : ($missingAssets ? 'missing_emulator' : 'attempt_ready')));
    return [
        'id'=>$id, 'filename'=>$filename, 'title'=>(string)($specific['title'] ?? $defaultTitle),
        'platform'=>$platform, 'core'=>$core, 'genre'=>$genre, 'cover'=>'assets/covers/'.$cover,
        'folder'=>$folder, 'bytes'=>$raw['bytes'], 'mtime'=>$raw['mtime'],
        'bios'=>$bios, 'parent'=>$parent, 'parent_id'=>$parentId,
        'rom_url'=>ra_public_url($folder, $filename),
        'bios_url'=>count($bios) === 1 ? ra_public_url('bios', $bios[0]) : '',
        'parent_url'=>!$missingParent && $parent !== '' ? ra_public_url('arcade', $parent) : '',
        'missing_bios'=>$missingBios, 'missing_parent'=>$missingParent, 'missing_assets'=>$missingAssets, 'multiple_bios'=>$multipleBios,
        'readiness'=>$readiness, 'issues'=>array_values(array_filter($problems)),
        'mapped'=>$custom, 'game_id'=>sprintf('%u', crc32($id)),
    ];
}

function ra_library(bool $force = false): array {
    $entries = ra_filesystem_entries();
    $metadata = ra_metadata();
    $fingerprint = hash('sha256', json_encode([$entries, $metadata], JSON_UNESCAPED_UNICODE));
    $cacheFile = RA_DATA . '/library-cache.json';
    $cached = $force ? [] : ra_json($cacheFile);
    if (($cached['fingerprint'] ?? '') !== $fingerprint || !is_array($cached['games'] ?? null)) {
        $games = array_map(fn($entry) => ra_resolve_game($entry, $metadata), $entries);
        $cached = ['fingerprint'=>$fingerprint, 'scanned_at'=>date(DATE_ATOM), 'games'=>$games];
        try { ra_save_json($cacheFile, $cached); } catch (RuntimeException $e) { /* Read-only server: still show games. */ }
    } else {
        // BIOS/emulator assets may have changed independently of the ROM list.
        // Resolve current runtime availability without full ROM ZIP validation on every request.
        foreach ($cached['games'] as &$game) {
            $core = (string)$game['core'];
            $missingAssets = ra_core_requirements($core);
            $missingBios = array_values(array_filter($game['bios'], fn($b) => !ra_bios_ok($b)));
            $missingParent = ($game['parent_id'] ?? null) && ra_file_for_id($game['parent_id']) === null;
            $game['missing_assets'] = $missingAssets;
            $game['missing_bios'] = $missingBios;
            $game['missing_parent'] = (bool)$missingParent;
            $issues = [];
            if ($game['readiness'] === 'invalid') $issues[] = 'ROM không hợp lệ. Nhấn Refresh Library để kiểm tra lại.';
            if ($game['folder'] === 'arcade' && !$game['mapped']) $issues[] = 'Chưa cấu hình core/BIOS cho ROM Arcade.';
            if ($missingBios) $issues[] = 'Thiếu BIOS: '.implode(', ', $missingBios);
            if (!empty($game['multiple_bios'])) $issues[] = 'Mapping nhiều BIOS không được hỗ trợ; hãy sửa chỉ còn một.';
            if ($missingParent) $issues[] = 'Thiếu parent ROM: '.$game['parent'];
            if ($missingAssets) $issues[] = 'Chưa cài EmulatorJS: '.implode(', ', $missingAssets);
            $game['issues'] = $issues;
            if ($game['readiness'] !== 'invalid') {
                $game['readiness'] = ($game['folder'] === 'arcade' && !$game['mapped']) ? 'unconfigured'
                    : ($missingBios || $missingParent || !empty($game['multiple_bios']) ? 'missing_dependencies' : ($missingAssets ? 'missing_emulator' : 'attempt_ready'));
            }
        }
        unset($game);
    }
    return $cached;
}

function ra_get_game(string $id): ?array {
    if (!ra_id_ok($id)) return null;
    foreach (ra_library()['games'] as $game) if ($game['id'] === $id) return $game;
    return null;
}

function ra_user_data(): array {
    $data = ra_json(RA_DATA . '/user.json', ['favorites'=>[], 'recent'=>[]]);
    return ['favorites'=>is_array($data['favorites'] ?? null) ? $data['favorites'] : [],
            'recent'=>is_array($data['recent'] ?? null) ? $data['recent'] : []];
}

function ra_can_admin(): bool {
    return in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
}

function ra_require_post(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') ra_error('Method not allowed', 405);
    $given = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['csrf'] ?? '';
    if (!is_string($given) || !hash_equals($_SESSION['ra_csrf'], $given)) ra_error('Phiên đã hết hạn / CSRF token không hợp lệ.', 403);
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $originHost = parse_url($origin, PHP_URL_HOST);
        $host = strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? ''));
        if (strtolower((string)$originHost) !== $host) ra_error('Origin không hợp lệ.', 403);
    }
}

function ra_error(string $message, int $http = 400): never {
    http_response_code($http);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false, 'error'=>$message], JSON_UNESCAPED_UNICODE);
    exit;
}

function ra_respond(array $data): never {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function ra_read_post_json(): array {
    $body = file_get_contents('php://input');
    if ($body === false || strlen($body) > 16384) ra_error('Yêu cầu quá lớn.');
    $parsed = json_decode($body, true);
    if (!is_array($parsed)) ra_error('JSON không hợp lệ.');
    return $parsed;
}

function ra_head(string $title, string $page = ''): void {
    $token = ra_escape($_SESSION['ra_csrf']);
    $title = ra_escape($title);
    $page = ra_escape($page);
    echo <<<HTML
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0a0b12"><title>{$title} — RETRO ARCADE</title>
<link rel="icon" type="image/svg+xml" href="assets/covers/favicon.svg">
<link rel="stylesheet" href="assets/css/app.css"><meta name="ra-csrf" content="{$token}">
</head><body data-page="{$page}">
HTML;
}

function ra_sidebar(string $active = 'home'): void {
    $classes = fn($name) => $active === $name ? 'navlink active' : 'navlink';
    echo '<aside class="sidebar" id="sidebar"><a class="brand" href="index.php"><span class="brand-mark">▦</span><span><strong>RETRO<span>ARCADE</span></strong><small>THE CLASSIC COLLECTION</small></span></a>';
    echo '<div class="sidebar-label">THƯ VIỆN</div><nav class="nav">';
    echo '<a class="'. $classes('home') .'" href="index.php"><span>◫</span> Tất cả game</a>';
    echo '<a class="navlink" href="index.php?filter=arcade"><span>▣</span> Arcade</a>';
    echo '<a class="navlink" href="index.php?filter=neogeo"><span>◆</span> Neo Geo</a>';
    echo '<a class="navlink" href="index.php?filter=nes"><span>▤</span> NES / Famicom</a>';
    echo '<a class="navlink" href="index.php?filter=favorites"><span>♡</span> Yêu thích</a>';
    echo '</nav><div class="sidebar-label space-top">HỆ THỐNG</div><nav class="nav">';
    echo '<a class="'. $classes('settings') .'" href="settings.php"><span>⚙</span> Cài đặt & Phím</a>';
    echo '</nav><div class="sidebar-bottom"><span class="signal-dot"></span> LOCAL ARCADE <small>PHP 8.3 · NO DATABASE</small></div></aside>';
}
