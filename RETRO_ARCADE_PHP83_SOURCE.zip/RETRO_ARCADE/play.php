<?php
declare(strict_types=1);
require_once __DIR__ . '/lib/app.php';
$id = (string)($_GET['id'] ?? '');
$game = ra_get_game($id);
if ($game === null) {
    http_response_code(404);
    ra_head('Game không tìm thấy', 'play');
    echo '<div class="missing-page"><h1>404 — KHÔNG TÌM THẤY ROM</h1><p>Hãy quay lại thư viện và nhấn Refresh Library.</p><a href="index.php" class="btn btn-primary">← VỀ THƯ VIỆN</a></div></body></html>';
    exit;
}
ra_head($game['title'], 'play');
?>
<div class="app-shell player-layout">
<?php ra_sidebar('play'); ?>
<main class="main-content"><header class="topbar"><button class="icon-button mobile-menu" id="menu-toggle" aria-label="Menu">☰</button><div class="breadcrumbs"><a href="index.php">GAME LIBRARY</a> <span>/</span> <strong><?php echo ra_escape($game['title']); ?></strong></div><div class="top-actions"><span class="top-status"><i></i> EMULATORJS PLAYER</span><span class="avatar">RA</span></div></header>
<div class="page-inner play-inner">
  <div class="player-head"><div><a href="index.php" class="back-link">← QUAY LẠI THƯ VIỆN</a><h1><?php echo ra_escape($game['title']); ?></h1><div class="player-tags"><span><?php echo ra_escape(strtoupper($game['platform'])); ?></span><span>CORE: <?php echo ra_escape(strtoupper($game['core'])); ?></span><span><?php echo ra_escape($game['filename']); ?></span></div></div><div class="player-head-actions"><button class="btn btn-ghost btn-small" id="fullscreen-button">⛶ FULLSCREEN</button></div></div>
  <div class="game-stage" id="game-stage"><div id="game"></div>
    <?php if ($game['readiness'] !== 'attempt_ready'): ?>
      <div class="stage-blocked"><div class="blocked-icon">!</div><h2>Chưa thể khởi động game</h2><p>Trình kiểm tra đã phát hiện vấn đề cần xử lý trước khi nạp ROM:</p><ul><?php foreach ($game['issues'] as $issue): ?><li><?php echo ra_escape($issue); ?></li><?php endforeach; ?></ul><a class="btn btn-primary" href="settings.php?id=<?php echo rawurlencode($id); ?>">ĐẾN CÀI ĐẶT ↗</a></div>
    <?php else: ?>
      <div class="stage-loading" id="stage-loading"><span class="spinner"></span><strong>ĐANG CHUẨN BỊ GIẢ LẬP</strong><small>Khởi tạo EmulatorJS từ thư mục nội bộ…</small></div>
    <?php endif; ?>
  </div>
  <div class="player-toolbar"><div class="game-status"><i id="game-status-dot"></i><span id="game-status-text"><?php echo $game['readiness'] === 'attempt_ready' ? 'Đang nạp trình giả lập…' : 'Không thể chơi · Cần xử lý lỗi'; ?></span></div><div class="player-buttons"><button type="button" class="tool-btn" id="pause-button" <?php echo $game['readiness'] !== 'attempt_ready' ? 'disabled' : ''; ?>>Ⅱ <span>PAUSE</span></button><button type="button" class="tool-btn" id="resume-button" <?php echo $game['readiness'] !== 'attempt_ready' ? 'disabled' : ''; ?>>▶ <span>RESUME</span></button><button type="button" class="tool-btn" id="restart-button" <?php echo $game['readiness'] !== 'attempt_ready' ? 'disabled' : ''; ?>>↻ <span>RESTART</span></button><a class="tool-btn exit-button" href="index.php">↤ <span>EXIT</span></a></div></div>
  <div class="player-bottom-grid"><section class="info-panel"><div class="panel-title">⌨ &nbsp; ĐIỀU KHIỂN — PLAYER 1</div><div class="key-instructions"><div><div class="arrow-keys"><kbd>↑</kbd><section><kbd>←</kbd><kbd>↓</kbd><kbd>→</kbd></section></div><small>DI CHUYỂN</small></div><div><div class="action-keys"><kbd>Z</kbd><kbd>X</kbd><kbd>A</kbd><kbd>S</kbd></div><small>HÀNH ĐỘNG</small></div><div><div class="action-keys"><kbd>SHIFT</kbd><kbd>ENTER</kbd></div><small>COIN / START</small></div></div><p>Game Arcade: nhấn <b>Shift (Coin)</b> rồi <b>Enter (Start)</b>. Game NES: Enter để bắt đầu. Một số core có sơ đồ phím riêng.</p></section><section class="info-panel"><div class="panel-title">◈ &nbsp; MẸO & TRẠNG THÁI</div><div class="tips-list"><p><span>01</span> Lưu / tải Save State trên <b>thanh công cụ EmulatorJS</b> ngay dưới màn hình khi game đã chạy.</p><p><span>02</span> Sử dụng tay cầm USB/Bluetooth (Gamepad API) hoặc chỉnh phím trong Settings.</p><p><span>03</span> Lỗi ROM set hoặc BIOS có thể chỉ được core phát hiện khi khởi động.</p></div><a class="small-link" href="settings.php?tab=controls">CHỈNH PHÍM ĐIỀU KHIỂN ↗</a></section></div>
</div></main></div><div class="toast" id="toast" role="status" aria-live="polite"></div>
<script>window.RA_PLAY = <?php echo json_encode($game, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE); ?>;</script>
<script src="assets/js/controls.js" defer></script><script src="assets/js/play.js" defer></script></body></html>
