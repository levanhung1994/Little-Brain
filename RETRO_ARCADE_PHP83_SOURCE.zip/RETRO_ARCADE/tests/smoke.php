<?php
declare(strict_types=1);
// Run: php tests/smoke.php. Creates/removes its own dummy files; no commercial ROMs used.
require_once __DIR__ . '/../lib/app.php';
function check(bool $ok, string $what): void {
    if (!$ok) {fwrite(STDERR, "FAIL: $what\n"); exit(1);}
    echo "PASS: $what\n";
}
check(!ra_id_ok('arcade:../../index.php'), 'Reject traversal ID');
check(!ra_id_ok('nes:foo.exe'), 'Reject executable extension');
check(!ra_id_ok('arcade:foo/bar.zip'), 'Reject embedded path');
check(ra_id_ok('arcade:mslug.zip'), 'Accept arcade ID');
check(ra_id_ok('nes:contra.nes'), 'Accept NES ID');
$test='ra_smoketest_'.bin2hex(random_bytes(4)).'.nes';
$file=RA_ROOT.'/games/nes/'.$test;
try {
    check(file_put_contents($file, "NES\x1A".str_repeat("\x00", 16-4+16384)) !== false, 'Create temporary NES test header');
    $library=ra_library(true);
    $match=array_values(array_filter($library['games'],fn($g)=>$g['id']==='nes:'.$test));
    check(count($match)===1, 'Scan new NES ROM');
    check($match[0]['readiness']==='missing_emulator' || $match[0]['readiness']==='attempt_ready', 'Recognize valid NES file');
    check($match[0]['core']==='fceumm', 'Choose FCEUmm core for NES');
    check($match[0]['bios']===[], 'NES cartridge does not require BIOS');
    file_put_contents($file, 'NOT_NES_ROM'.str_repeat('x', 100));
    $library=ra_library(true);
    $match=array_values(array_filter($library['games'],fn($g)=>$g['id']==='nes:'.$test));
    check($match[0]['readiness']==='invalid', 'Reject invalid NES header');
} finally {
    @unlink($file);
    ra_library(true);
}
check(ra_get_game('arcade:../../foo.zip')===null, 'Safe game lookup');
check(ra_core_requirements('fceumm') !== [] || is_file(RA_ROOT.'/emulator/data/cores/fceumm-wasm.data'), 'Verify core asset location');
echo "All smoke tests passed. No real ROM gameplay was tested.\n";
