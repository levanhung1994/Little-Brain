<?php
// The built-in development server does NOT read .htaccess / web.config.
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
$root = realpath(__DIR__);
$path = str_replace('\\', '/', $path);
if (str_contains($path, "\0") || str_contains($path, '..') || preg_match('#^/(?:data|lib|tests|scripts)(?:/|$)#i', $path)
    || preg_match('#/(?:\.git|\.env|web\.config|\.htaccess)(?:/|$)#i', $path)
    || preg_match('#/games/(?!arcade/|nes/|bios/)#i', $path)) {
    http_response_code(403); echo 'Forbidden'; return true;
}
if (str_starts_with($path, '/games/')) {
    $parts = explode('/', ltrim($path, '/'));
    $file = end($parts);
    $dir = $parts[1] ?? '';
    if (count($parts) !== 3 || !in_array($dir, ['arcade','nes','bios'], true)
        || !preg_match('/\A[a-zA-Z0-9][a-zA-Z0-9._() -]*\z/D', $file)
        || str_contains($file, '..')
        || !in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), $dir === 'arcade' ? ['zip'] : ($dir === 'nes' ? ['nes','fds','unf','unif'] : ['zip','rom','bin']), true)) {
        http_response_code(403); echo 'Forbidden'; return true;
    }
    $candidate = realpath(__DIR__.'/games/'.$dir.'/'.$file);
    if (!$candidate || dirname($candidate) !== realpath(__DIR__.'/games/'.$dir) || is_link(__DIR__.'/games/'.$dir.'/'.$file)) {
        http_response_code(404); echo 'Not found'; return true;
    }
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, max-age=60');
    header('Content-Type: application/octet-stream');
    header('Accept-Ranges: bytes');
    $size = filesize($candidate);
    $start = 0; $end = $size - 1;
    if (isset($_SERVER['HTTP_RANGE'])) {
        if (!preg_match('/\Abytes=(\d*)-(\d*)\z/D', trim($_SERVER['HTTP_RANGE']), $m) || ($m[1] === '' && $m[2] === '')) {
            header('Content-Range: bytes */'.$size); http_response_code(416); return true;
        }
        if ($m[1] === '') { $start = max(0, $size - (int)$m[2]); }
        else { $start = (int)$m[1]; }
        if ($m[1] !== '' && $m[2] !== '') $end = min($end, (int)$m[2]);
        if ($start > $end || $start >= $size) { header('Content-Range: bytes */'.$size); http_response_code(416); return true; }
        http_response_code(206); header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
    }
    header('Content-Length: '.($end-$start+1));
    if ($_SERVER['REQUEST_METHOD'] === 'HEAD') return true;
    $fh = fopen($candidate, 'rb'); fseek($fh, $start);
    $remaining = $end-$start+1;
    while ($remaining > 0 && !feof($fh)) {
        $chunk = fread($fh, min(1048576, $remaining));
        if ($chunk === false || $chunk === '') break;
        echo $chunk;
        $remaining -= strlen($chunk);
        if (connection_aborted()) break;
    }
    fclose($fh);
    return true;
}
if ($path === '/') { require __DIR__ . '/index.php'; return true; }
if (is_file(__DIR__ . $path)) return false;
http_response_code(404); echo 'Not found'; return true;
