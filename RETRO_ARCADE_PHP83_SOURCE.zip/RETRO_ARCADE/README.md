# RETRO ARCADE – Kho Game Tuổi Thơ

Ứng dụng PHP 8.3+, HTML/CSS/JavaScript, JSON; **không dùng MySQL**. Quét và phân loại ROM Arcade/Neo Geo/IGS PGM và NES trong thư mục cục bộ. Trình chơi tích hợp **EmulatorJS thật**, không phải video, bản demo giả lập giao diện hay EXE.

## Trạng thái bàn giao

- Có đầy đủ source ứng dụng và bộ ảnh bìa SVG **tự thiết kế**; `index.php`, `play.php`, `settings.php`, JSON metadata mẫu, REST-like API, kiểm tra ROM/BIOS/parent, lưu yêu thích và danh sách gần đây.
- **ZIP chưa chứa mã nhị phân EmulatorJS/WASM.** Môi trường tạo gói này không truy cập được tệp tải về từ CDN, nên được cung cấp `scripts/install-emulator.ps1` để cài **chính các asset chính thức** vào dự án một lần khi máy tính có Internet. Sau khi cài đủ, khi chạy chơi game hệ thống **không dùng CDN**. Đây là một yêu cầu cài đặt bắt buộc trước lần chơi đầu tiên.
- **Không chứa ROM hoặc BIOS** game thương mại. Chưa có ROM thật để kiểm chứng Metal Slug, The Killing Blade, Contra; hệ thống không xác nhận game đã chơi được chỉ vì tìm thấy ZIP. Sự tương thích phụ thuộc vào bộ ROM phù hợp với phiên bản core, BIOS và parent.

## Cài nhanh trên Windows (PHP 8.3+)

1. Giải nén vào `C:\RetroArcade\` (hoặc thư mục tùy chọn).
2. Kết nối Internet **một lần**, chạy `scripts\install-emulator.bat` (hoặc lệnh PowerShell):
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\install-emulator.ps1
   ```
   Mặc định tải **EmulatorJS stable**, cùng các core **FBNeo, FCEUmm, MAME2003**, file report và **bản legacy WebGL1** từ CDN chính thức. Đã cài đủ sẽ chạy khi không có Internet. Chỉ khi muốn tiết kiệm dung lượng mới dùng tùy chọn `-SkipLegacyCores` (không khuyến nghị).
3. Chép **ROM/BIOS hợp pháp của chính bạn** vào thư mục:
   ```text
   games/
     arcade/
       mslug.zip                # Neo Geo - Metal Slug
       mslug2.zip               # Metal Slug 2, nếu có
       killbld.zip              # IGS PGM - The Killing Blade
       kof97.zip                # King of Fighters '97
       samsho.zip               # Samurai Shodown
       contra.zip               # Contra Arcade (khác với NES)
     nes/
       contra.nes               # Contra NES
     bios/
       neogeo.zip               # BIOS Neo Geo (cho Metal Slug/KOF/...)
       pgm.zip                  # BIOS IGS PGM (cho killbld.zip)
   ```
   **Không giải nén, đổi tên, gộp ROM ZIP Arcade.** Nếu là ROM clone/split set, điền đúng `parent` trong Settings và chép thêm parent ROM (ví dụ `parent.zip`) vào `games/arcade/`. ROM **non-merged** thường dễ sử dụng hơn. Không tải BIOS từ website này.
4. Mở `start-local.bat` hoặc trong Command Prompt:
   ```bat
   cd /d C:\RetroArcade
   php -S 127.0.0.1:8000 router.php
   ```
   Truy cập http://127.0.0.1:8000, nhấn **REFRESH LIBRARY**. Chọn PLAY (chỉ có thể khi bước kiểm tra cơ bản đạt).
5. Khi cần hoàn toàn offline: ngắt Internet. ROM và các file JS/WASM đã cài đều nằm trên máy. Dữ liệu Save State của EmulatorJS lưu trong bộ nhớ browser của từng game, theo `EJS_gameID` ổn định.

> Khuyến nghị Chrome / Edge với WebGL, WebAssembly, bộ nhớ RAM đủ lớn. Cần ít nhất các file `emulator/data/loader.js`, `emulator.min.js`, `emulator.min.css`, `cores/fbneo-wasm.data`, `cores/fbneo-legacy-wasm.data`, `cores/fceumm-wasm.data`, `cores/fceumm-legacy-wasm.data` và các file `cores/reports/*.json`. Core .data **chứa nội dung WASM được đóng gói**. Không đặt giả file rỗng vào đó.

## Chạy trên IIS / Windows Server

1. Site dùng **PHP 8.3+ qua FastCGI** và đặt Document Root vào thư mục dự án.
2. Cấp quyền **Modify cho identity của Application Pool** đối với thư mục `data/` (và chỉ thư mục này), để lưu JSON và cache. Các thư mục `games/` và `emulator/data/` chỉ cần quyền đọc.
3. Bảo đảm IIS Static Content bật, mapping MIME cho `.nes`, `.unf`, `.unif`, `.fds`, `.rom`, `.bin`, `.wasm` nếu cần; `games/web.config` chứa các mapping ROM thông dụng. Không cho IIS xử lý script trong `games/`.
4. Nên dùng trang web **chỉ trên localhost**: chức năng Refresh/Save metadata/favorites yêu cầu địa chỉ client `127.0.0.1` hoặc `::1`. Nếu triển khai cho mạng LAN, phải thêm xác thực trước khi thay đổi quy tắc đó.
5. File `.htaccess` dành cho Apache. Khi dùng PHP CLI server, **luôn chạy qua `router.php`** để bảo vệ các thư mục nội bộ và chỉ cho phép phục vụ ROM ở định dạng được duyệt.

## Cơ chế nhận diện và tính đúng đắn

- `api/library.php?action=refresh` → quét **file trực tiếp** trong `games/arcade` và `games/nes`; bỏ qua symlink, loại trừ BIOS, chỉ chấp nhận tên và phần mở rộng an toàn.
- `data/games.json` ánh xạ đúng ID (`arcade:mslug.zip`, `nes:contra.nes`) sang tên, nền tảng, core, BIOS, parent, cover, thể loại. Các file mới nếu không có metadata vẫn xuất hiện. **ZIP Arcade chưa cấu hình không được tự động coi là tương thích**, cần chọn core/BIOS trong Settings.
- ROM NES `.nes` yêu cầu header iNES `NES\x1A`. ZIP Arcade yêu cầu chữ ký ZIP; nếu extension `ZipArchive` có sẵn, còn kiểm tra ZIP có thể mở và có mục bên trong. Đây là *kiểm tra file cơ bản*; core mới có thể kiểm chứng đúng ROM set/CRC/BIOS thực tế.
- File BIOS/parent được **truyền riêng** qua `EJS_biosUrl` / `EJS_gameParentUrl`; mỗi game chỉ nhận **một BIOS URL** qua cấu hình hiện tại; không tự ghép/giải nén/repack ZIP. Các set clone/split phụ thuộc tính tương thích core EmulatorJS đang dùng.
- `EJS_core='fbneo'` cho các mẫu Metal Slug / KOF / Samurai / killbld; `EJS_core='fceumm'` cho Contra NES. Không gán duy nhất một core cho mọi game.
- Thư viện chỉ nạp metadata; **core và ROM chỉ nạp tại `play.php`**. `play.php` không chạy core nếu thiếu asset, BIOS, parent theo mapping. Các trạng thái: `invalid`, `unconfigured`, `missing_dependencies`, `missing_emulator`, `attempt_ready`.
- `attempt_ready` = **có thể thử khởi động**, KHÔNG phải đã kiểm tra gameplay thực tế. Các thông báo lỗi lúc core khởi động được hiển thị trong màn hình EmulatorJS.
- Lịch sử ghi khi EmulatorJS phát sự kiện `onGameStart` thay vì khi chỉ mở trang play. Các nút Pause/Resume dùng phương thức phiên bản hiện hành nhưng API này có thể thay đổi; toolbar mặc định EmulatorJS là lựa chọn dự phòng.
- Save/Load State, gamepad, fullscreen và mapping nâng cao: qua toolbar chính thức của EmulatorJS. Settings phím trên website lưu trong `localStorage` theo hệ máy và player; EmulatorJS có thể đã ghi đè phím qua cài đặt riêng của nó, khi đó reset trong emulator.

## Cấu trúc

```text
index.php                     Thư viện, lọc, tìm kiếm, yêu thích, gần đây
play.php                      Tải EmulatorJS thật khi mở trò chơi
settings.php                  Cấu hình trình giả lập / metadata / phím
router.php                    An toàn cho PHP built-in server
lib/app.php                   Quét ROM, cache, JSON, kiểm tra lỗi
api/library.php               Quét thư viện và yêu thích / gần đây
api/settings.php              Lưu metadata có kiểm tra dữ liệu
assets/css/                  Phong cách retro responsive
assets/js/                   Logic giao diện và giả lập
assets/covers/               Artwork SVG gốc, có thể thay ảnh
emulator/data/                Asset chính thức (tải bằng installer)
games/arcade,nes,bios/         **ROM/BIOS tự cung cấp**
data/games.json               Metadata mẫu, có thể chỉnh bằng UI
data/user.json                Yêu thích/lịch sử người chơi
scripts/install-emulator.ps1  Cài chính thức các file JS/WASM
start-local.bat               Chạy PHP localhost trên Windows
tests/smoke.php               Test tự động không dùng ROM có bản quyền
```

## Điều khiển mặc định

| Lệnh | Player 1 | Player 2 |
|---|---|---|
| Di chuyển | Mũi tên | I, J, K, L |
| 4 phím hành động | Z, X, A, S | U, O, H, P |
| Coin / Select | Shift | 9 |
| Start | Enter | 0 |

NES thực tế chủ yếu có A/B; các nút hành động còn lại phụ thuộc core. Người chơi có thể nhấn vào ô trong **Settings → Điều khiển** để đổi phím, rồi reload trang chơi. Tay cầm qua Gamepad API của trình duyệt và menu EmulatorJS.

## Sự cố thường gặp

- **No emulator assets**: chạy `install-emulator.bat`, không chỉ chép mỗi loader.js mà thiếu `*.data` / `src` / compression.
- **Thiếu BIOS**: thêm `neogeo.zip` hoặc `pgm.zip` phù hợp vào `games/bios/`, không đổi tên.
- **Màn hình đen hoặc “Missing ROMs”**: ROM set sai phiên bản, thiếu file trong ZIP, thiếu parent hoặc core chưa hỗ trợ board này. Kiểm tra log trong DevTools Console. Đặc biệt The Killing Blade **chưa được kiểm tra với ROM thật**.
- **IIS báo 404 cho ROM**: cài IIS Static Content, MIME mapping, kiểm tra request filtering và quyền file.
- **Save State không lưu**: bật lưu trữ trình duyệt, tránh private mode và không xóa IndexedDB/cache của trang. Lưu/trả trạng thái từ toolbar EmulatorJS.
- **Tay cầm không hoạt động**: kết nối tay cầm trước khi vào game, nhấn nút trên tay cầm, kiểm tra menu Gamepad/Controls.
- **ROM lớn / thiết bị yếu**: trình duyệt có giới hạn RAM/WebAssembly; nên thử NES trước để xác nhận setup.
- **Refresh chỉ cho localhost**: ứng dụng hướng đến vận hành cục bộ. Không mở API chỉnh sửa qua Internet nếu chưa bổ sung đăng nhập/authorization.

## Nguồn mở / giấy phép

- EmulatorJS: https://github.com/EmulatorJS/EmulatorJS (GPL-3.0). File tải về giữ nguyên từ CDN chính thức `https://cdn.emulatorjs.org/stable/data/`. Một số core áp dụng giấy phép tương ứng, cần tuân thủ thông tin từ các dự án nguồn / thông báo giấy phép của core.
- Tham khảo docs: https://emulatorjs.org/docs/getting-started/, https://emulatorjs.org/docs/options/, https://emulatorjs.org/docs/systems/arcade/, https://emulatorjs.org/docs/systems/nes-famicom/.
- Website RETRO ARCADE do dự án này tạo ra. Logo/ảnh bìa SVG là minh họa gốc, không phải artwork thương mại. Không phát tán ROM/BIOS game thương mại.
