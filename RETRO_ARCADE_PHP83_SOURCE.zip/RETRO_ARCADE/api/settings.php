<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib/app.php';
ra_require_post();
if (!ra_can_admin()) ra_error('Chỉ có thể chỉnh sửa thư viện từ localhost.', 403);
$data = ra_read_post_json();
$id = (string)($data['id'] ?? '');
if (!ra_get_game($id)) ra_error('ROM chưa tồn tại. Hãy Refresh Library trước.');
$folder = explode(':', $id, 2)[0];
$title = trim((string)($data['title'] ?? ''));
if ($title === '' || strlen($title) > 360 || preg_match_all('/./us', $title) > 90) ra_error('Tên game phải từ 1 đến 90 ký tự.');
$platform = (string)($data['platform'] ?? '');
$core = (string)($data['core'] ?? '');
$genre = (string)($data['genre'] ?? 'other');
$validPlatform = $folder === 'nes' ? ['nes'] : ['arcade','neogeo','pgm'];
$validCore = $folder === 'nes' ? ['fceumm'] : ['fbneo','mame2003'];
if (!in_array($platform, $validPlatform, true) || !in_array($core, $validCore, true)) ra_error('Core hoặc hệ máy không hợp lệ.');
if (!in_array($genre, ['action','fighting','shooter','other'], true)) ra_error('Thể loại không hợp lệ.');
$parent = trim((string)($data['parent'] ?? ''));
if ($parent !== '' && ($folder !== 'arcade' || !ra_filename_ok($parent) || !str_ends_with(strtolower($parent),'.zip'))) ra_error('Parent phải là tên file ZIP Arcade.');
if ($parent !== '' && $parent === explode(':', $id, 2)[1]) ra_error('Parent không thể là ROM hiện tại.');
$cover = trim((string)($data['cover'] ?? ''));
if ($cover !== '' && (!ra_filename_ok($cover) || !preg_match('/\.(svg|png|webp|jpg|jpeg)$/iD', $cover) || !is_file(RA_ROOT.'/assets/covers/'.$cover))) {
    ra_error('Ảnh bìa phải nằm trong assets/covers và là SVG, PNG, WEBP hoặc JPG.');
}
$bios = $data['bios'] ?? [];
if (!is_array($bios) || count($bios) > 1) ra_error('EmulatorJS chỉ hỗ trợ một đường dẫn BIOS chính cho mỗi game.');
foreach ($bios as $name) {
    if (!is_string($name) || !ra_filename_ok($name) || !in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), ['zip','rom','bin'], true)) ra_error('Tên BIOS không hợp lệ.');
}
$metadata = ra_metadata();
$metadata[$id] = ['title'=>$title,'platform'=>$platform,'core'=>$core,'genre'=>$genre,
    'bios'=>array_values(array_unique($bios)), 'parent'=>$parent, 'cover'=>$cover];
try { ra_save_json(RA_DATA . '/games.json', $metadata); } catch (Throwable $e) { ra_error($e->getMessage(), 500); }
$library = ra_library(true);
foreach ($library['games'] as $game) if ($game['id'] === $id) ra_respond(['ok'=>true,'game'=>$game]);
ra_error('Lưu metadata thành công nhưng ROM không tìm thấy.', 500);
