<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib/app.php';
$action = $_GET['action'] ?? 'list';
if ($action === 'list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $library = ra_library();
    ra_respond(['ok'=>true, 'games'=>$library['games'], 'scanned_at'=>$library['scanned_at'], 'user'=>ra_user_data(), 'can_admin'=>ra_can_admin()]);
}
if ($action === 'refresh') {
    ra_require_post();
    if (!ra_can_admin()) ra_error('Refresh Library chỉ cho phép tại localhost.', 403);
    $library = ra_library(true);
    ra_respond(['ok'=>true, 'games'=>$library['games'], 'scanned_at'=>$library['scanned_at'], 'user'=>ra_user_data()]);
}
if ($action === 'favorite') {
    ra_require_post();
    if (!ra_can_admin()) ra_error('Chỉ được cập nhật yêu thích từ localhost.', 403);
    $body = ra_read_post_json();
    $id = (string)($body['id'] ?? '');
    if (!ra_get_game($id)) ra_error('Không tìm thấy ROM.');
    $data = ra_user_data();
    $data['favorites'] = array_values(array_filter($data['favorites'], fn($v)=>$v !== $id));
    if (!empty($body['favorite'])) $data['favorites'][] = $id;
    $data['favorites'] = array_values(array_unique($data['favorites']));
    try { ra_save_json(RA_DATA . '/user.json', $data); } catch (Throwable $e) { ra_error($e->getMessage(), 500); }
    ra_respond(['ok'=>true,'favorites'=>$data['favorites']]);
}
if ($action === 'played') {
    ra_require_post();
    if (!ra_can_admin()) ra_error('Lịch sử chỉ được cập nhật từ localhost.', 403);
    $body = ra_read_post_json();
    $id = (string)($body['id'] ?? '');
    if (!ra_get_game($id)) ra_error('Game không tồn tại.');
    $data = ra_user_data();
    $data['recent'] = array_values(array_filter($data['recent'], fn($v)=>is_array($v) && ($v['id'] ?? '') !== $id));
    array_unshift($data['recent'], ['id'=>$id, 'at'=>date(DATE_ATOM)]);
    $data['recent'] = array_slice($data['recent'], 0, 12);
    try { ra_save_json(RA_DATA . '/user.json', $data); } catch (Throwable $e) { ra_error($e->getMessage(), 500); }
    ra_respond(['ok'=>true]);
}
ra_error('Không tìm thấy API.', 404);
