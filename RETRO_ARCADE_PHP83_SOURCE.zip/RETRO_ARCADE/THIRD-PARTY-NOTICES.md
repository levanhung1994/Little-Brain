# Third-party components

EmulatorJS is an independent open-source project (https://github.com/EmulatorJS/EmulatorJS), licensed GPL-3.0. The separate installer fetches official stable JavaScript, WebAssembly-bearing core `.data` packages and support files from https://cdn.emulatorjs.org/stable/data/. **Those binaries are not present in this source ZIP**, because external downloads were not available when it was built. Respect the specific core licenses and source availability obligations when redistributing an installed copy. See https://emulatorjs.org/docs/.

No game ROMs, BIOS files, copyrighted game screenshots, or publisher cover illustrations are supplied in this project. Site vector artwork is original and purely illustrative.
