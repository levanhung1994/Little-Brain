(() => {
  'use strict';
  const info=window.RA_SETTINGS||{games:[],initial_tab:'setup',selected_id:''};
  const $=s=>document.querySelector(s);
  const token=$('meta[name="ra-csrf"]')?.content||'';
  let selected=''; let system='arcade';let player='0';let values=[];let listening=-1;
  function toast(t,error=false){const a=$('#toast');a.textContent=t;a.className='toast show'+(error?' error':'');clearTimeout(toast.timer);toast.timer=setTimeout(()=>a.className='toast',3500);}
  async function post(path,obj={}){const res=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':token},body:JSON.stringify(obj)});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Error');return data;}
  function chooseTab(tab){if(!['setup','metadata','controls'].includes(tab))tab='setup';document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('hidden',p.id!==`panel-${tab}`));}
  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>chooseTab(b.dataset.tab)));
  const fields={id:'#meta-id',title:'#meta-title',platform:'#meta-platform',core:'#meta-core',genre:'#meta-genre',bios:'#meta-bios',parent:'#meta-parent',cover:'#meta-cover'};
  function selectedGame(){return info.games.find(g=>g.id===selected);}
  function updateOptions(){
    const nes=selected.startsWith('nes:');
    $('#meta-platform').querySelectorAll('option').forEach(op=>op.disabled=(nes?op.value!=='nes':op.value==='nes'));
    $('#meta-core').querySelectorAll('option').forEach(op=>op.disabled=(nes?op.value!=='fceumm':op.value==='fceumm'));
    if(nes){$('#meta-platform').value='nes';$('#meta-core').value='fceumm';}
  }
  function populate(){
    selected=$('#meta-id').value;const g=selectedGame(); if(!g)return;
    $('#meta-title').value=g.title;$('#meta-platform').value=g.platform;$('#meta-core').value=g.core;
    $('#meta-genre').value=g.genre;$('#meta-bios').value=(g.bios||[]).join(', ');
    $('#meta-parent').value=g.parent||'';$('#meta-cover').value=g.cover?.replace('assets/covers/','')||'';
    updateOptions();
    $('#metadata-msg').textContent='';
  }
  $('#meta-id').addEventListener('change',populate);
  $('#meta-platform').addEventListener('change',()=>{
    const p=$('#meta-platform').value;
    if(p==='neogeo')$('#meta-bios').value='neogeo.zip';
    if(p==='pgm')$('#meta-bios').value='pgm.zip';
    if(p==='arcade')$('#meta-bios').value='';
  });
  $('#metadata-form').addEventListener('submit',async e=>{
    e.preventDefault();if(!selected) return toast('Chọn một ROM trước khi lưu.',true);
    const bios=$('#meta-bios').value.split(',').map(x=>x.trim()).filter(Boolean);
    const payload={id:selected,title:$('#meta-title').value,platform:$('#meta-platform').value,
      core:$('#meta-core').value,genre:$('#meta-genre').value,bios,
      parent:$('#meta-parent').value.trim(),cover:$('#meta-cover').value.trim()};
    try{const result=await post('api/settings.php',payload);info.games=info.games.map(g=>g.id===selected?result.game:g);$('#metadata-msg').textContent='✓ Đã lưu';toast('Đã cập nhật metadata cho '+result.game.title);}
    catch(err){$('#metadata-msg').textContent='';toast(err.message,true);}
  });
  function drawMapping(){
    if(!window.RetroControls)return;
    values=RetroControls.current(system,player).slice();
    const root=$('#control-mapping');root.replaceChildren();
    RetroControls.labels.forEach((label,n)=>{
      const node=document.createElement('div');node.className='map-field';
      const name=document.createElement('span');name.textContent=label;
      const btn=document.createElement('button');btn.type='button';btn.dataset.index=n;
      btn.textContent=RetroControls.display(values[n]);btn.setAttribute('aria-label','Đổi phím '+label);
      node.append(name,btn);root.appendChild(node);
    });
  }
  function stopListening(){listening=-1;$('#control-mapping').querySelectorAll('button').forEach(x=>x.classList.remove('listening'));}
  $('#control-mapping').addEventListener('click',e=>{
    const btn=e.target.closest('button[data-index]');if(!btn)return;
    stopListening();listening=Number(btn.dataset.index);btn.classList.add('listening');btn.textContent='NHẤN PHÍM…';btn.focus();
  });
  document.addEventListener('keydown',e=>{
    if(listening<0)return;
    e.preventDefault();e.stopPropagation();const v=RetroControls.normalize(e);
    if(v===null){stopListening();drawMapping();return;}
    if(v===undefined)return;
    values[listening]=v;const previous=listening;stopListening();
    $('#control-mapping button[data-index="'+previous+'"]').textContent=RetroControls.display(v);
  },true);
  $('#control-system').addEventListener('change',e=>{stopListening();system=e.target.value;drawMapping();});
  $('#control-player').addEventListener('change',e=>{stopListening();player=e.target.value;drawMapping();});
  $('#save-controls').addEventListener('click',()=>{
    const duplicates=values.filter((v,i)=>values.indexOf(v)!==i);
    if(duplicates.length) return toast('Có phím bị trùng. Hãy sử dụng phím khác cho từng nút.',true);
    if(RetroControls.save(system,player,values))toast('Đã lưu phím Player '+(+player+1)+' vào trình duyệt.');
    else toast('Trình duyệt từ chối lưu localStorage.',true);
  });
  $('#reset-controls').addEventListener('click',()=>{RetroControls.reset(system,player);stopListening();drawMapping();toast('Đã khôi phục sơ đồ mặc định.');});
  $('#settings-refresh')?.addEventListener('click',async()=>{try{const data=await post('api/library.php?action=refresh');toast('Đã quét '+data.games.length+' ROM. Tải lại trang để sửa mapping mới.');}catch(e){toast(e.message,true);}});
  $('#menu-toggle')?.addEventListener('click',()=>$('#sidebar').classList.toggle('show'));
  const choose=info.games.some(g=>g.id===info.selected_id)?info.selected_id:info.games[0]?.id;
  if(choose){$('#meta-id').value=choose;populate();}
  chooseTab(choose && info.initial_tab==='setup'?'metadata':info.initial_tab);
  drawMapping();
})();
