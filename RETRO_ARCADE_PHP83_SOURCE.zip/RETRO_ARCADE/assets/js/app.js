(() => {
  'use strict';
  const init = window.RA_INIT || { games: [], user: { favorites: [], recent: [] }, filter: 'all' };
  const state = { games: init.games || [], favorites: init.user?.favorites || [], recent: init.user?.recent || [], filter: init.filter || 'all', text: '', genre: 'all' };
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
  const csrf = $('meta[name="ra-csrf"]')?.content || '';
  const genreName = {action:'HÀNH ĐỘNG',fighting:'ĐỐI KHÁNG',shooter:'BẮN SÚNG',other:'GAME RETRO'};
  const availability = {attempt_ready:'CÓ THỂ THỬ CHƠI',missing_emulator:'THIẾU EMULATOR',missing_dependencies:'THIẾU BIOS / PARENT',unconfigured:'CHƯA CẤU HÌNH',invalid:'ROM LỖI'};
  const candidates = [
    {title:'Metal Slug',file:'mslug.zip',platform:'NEO GEO',cover:'assets/covers/metal-slug.svg',genre:'HÀNH ĐỘNG'},
    {title:'The Killing Blade',file:'killbld.zip',platform:'IGS PGM',cover:'assets/covers/killing-blade.svg',genre:'ĐỐI KHÁNG'},
    {title:'Contra',file:'contra.nes',platform:'NES',cover:'assets/covers/contra.svg',genre:'BẮN SÚNG'},
  ];
  function toast(message, error=false) {
    const box = $('#toast'); if (!box) return;
    box.textContent = message; box.className = 'toast show' + (error ? ' error' : '');
    clearTimeout(toast.timer); toast.timer = setTimeout(() => box.className = 'toast', 3600);
  }
  async function post(path, data={}) {
    const res = await fetch(path, {method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(data),cache:'no-store'});
    const body = await res.json();
    if (!res.ok || !body.ok) throw new Error(body.error || `HTTP ${res.status}`);
    return body;
  }
  function validImage(url){ return /^assets\/covers\/[a-zA-Z0-9._-]+\.(svg|png|webp|jpg|jpeg)$/i.test(url) ? url : 'assets/covers/default.svg'; }
  function gameCard(g) {
    const ready = g.readiness === 'attempt_ready';
    const liked = state.favorites.includes(g.id);
    const link = ready ? `play.php?id=${encodeURIComponent(g.id)}` : `settings.php?id=${encodeURIComponent(g.id)}`;
    const label = ready ? '▶ &nbsp; PLAY GAME' : (g.readiness === 'unconfigured' ? '⚙ &nbsp; CẤU HÌNH' : 'ⓘ &nbsp; KIỂM TRA');
    return `<article class="game-card" title="${esc(g.issues?.join(' · ') || 'Core chưa được kiểm thử bằng ROM thực tế')}">
      <div class="cover"><img src="${esc(validImage(g.cover))}" loading="lazy" alt="Ảnh bìa ${esc(g.title)}">
      <span class="platform-badge">${esc(g.platform.toUpperCase())}</span><button type="button" class="heart-btn ${liked?'liked':''}" data-fav="${esc(g.id)}" title="Yêu thích" aria-label="Yêu thích ${esc(g.title)}">${liked?'♥':'♡'}</button></div>
      <div class="card-body"><div class="card-topline"><span class="card-genre">${esc(genreName[g.genre] || 'GAME RETRO')}</span><span class="card-status ${ready?'ready':''}">${esc(availability[g.readiness] || 'CHƯA XÁC MINH')}</span></div>
      <h3 class="card-title">${esc(g.title)}</h3><div class="card-file">${esc(g.filename)} · ${Math.max(.01,Number(g.bytes)/1048576).toFixed(1)} MB</div>
      <div class="card-actions"><a class="card-play ${ready?'':'secondary'}" href="${link}">${label}</a><a class="card-settings" href="settings.php?id=${encodeURIComponent(g.id)}" title="Chỉnh metadata">⚙</a></div></div></article>`;
  }
  function missingCard(g) {
    return `<article class="game-card"><div class="cover"><img src="${g.cover}" alt="Gợi ý ${esc(g.title)}" loading="lazy"><span class="platform-badge">${g.platform}</span></div><div class="card-body"><div class="card-topline"><span class="card-genre">${g.genre}</span><span class="card-status">CHƯA CÓ ROM</span></div><h3 class="card-title">${esc(g.title)}</h3><div class="card-file">${g.file} · USER SUPPLIED</div><div class="card-actions"><a class="card-play secondary" href="settings.php">＋ &nbsp; THÊM ROM</a><a class="card-settings" href="settings.php" title="Hướng dẫn">⚙</a></div></div></article>`;
  }
  function activeGame(g) {
    const q = state.text.toLocaleLowerCase('vi').trim();
    if (q && !(`${g.title} ${g.filename} ${g.platform} ${g.core}`).toLocaleLowerCase('vi').includes(q)) return false;
    if (state.genre !== 'all' && g.genre !== state.genre) return false;
    if (state.filter === 'favorites') return state.favorites.includes(g.id);
    if (state.filter === 'all') return true;
    if (state.filter === 'arcade') return g.folder === 'arcade';
    return g.platform === state.filter;
  }
  function draw() {
    $('#stat-total').textContent = state.games.length;
    $('#stat-arcade').textContent = state.games.filter(g=>g.folder==='arcade').length;
    $('#stat-ready').textContent = state.games.filter(g=>g.readiness==='attempt_ready').length;
    $('#stat-favorites').textContent = state.favorites.filter(id=>state.games.some(g=>g.id===id)).length;
    $('#filter-count').textContent = state.games.length;
    const found = state.games.filter(activeGame);
    const showCandidates = state.games.length === 0 && state.filter === 'all' && !state.text && state.genre === 'all';
    $('#games-grid').innerHTML = showCandidates ? candidates.map(missingCard).join('') : found.map(gameCard).join('');
    $('#empty-state').classList.toggle('hidden', found.length > 0 || showCandidates);
    $('#grid-note').textContent = showCandidates ? 'Chưa có ROM · Dưới đây là các game được gợi ý để thêm' : `${found.length} game trong danh sách · Chưa xác minh ROM thực tế`;
    document.querySelectorAll('.filter-pill').forEach(btn => btn.classList.toggle('active', btn.dataset.filter === state.filter));
    const recent = state.recent.map(x=>state.games.find(g=>g.id===x.id)).filter(Boolean).slice(0,6);
    $('#recent-section').classList.toggle('hidden', recent.length === 0);
    $('#recent-games').innerHTML = recent.map(g => `<a href="play.php?id=${encodeURIComponent(g.id)}" class="recent-item"><img src="${esc(validImage(g.cover))}" alt=""><span><b>${esc(g.title)}</b><small>${esc(g.platform.toUpperCase())} · Chơi tiếp →</small></span></a>`).join('');
  }
  async function refresh(){
    const buttons = [$('#refresh-library'),$('#hero-refresh'),$('#settings-refresh')].filter(Boolean);
    buttons.forEach(b=>b.disabled=true);
    try {
      const result=await post('api/library.php?action=refresh');
      state.games=result.games; state.recent=result.user?.recent || [];
      state.favorites=result.user?.favorites || [];
      draw(); toast(`Quét xong: ${state.games.length} ROM đã nhận diện.`);
    } catch(e) { toast(e.message, true); }
    finally { buttons.forEach(b=>b.disabled=false); }
  }
  $('#refresh-library').addEventListener('click',refresh);
  $('#hero-refresh').addEventListener('click',refresh);
  $('#filter-bar').addEventListener('click',e=>{
    const filter=e.target.closest('[data-filter]'); if (!filter) return;
    state.filter=filter.dataset.filter; draw();
    const url=new URL(location.href); state.filter==='all'? url.searchParams.delete('filter'):url.searchParams.set('filter',state.filter);
    history.replaceState(null,'',url);
  });
  $('#search-games').addEventListener('input',e=>{state.text=e.target.value;draw();});
  $('#genre-filter').addEventListener('change',e=>{state.genre=e.target.value;draw();});
  $('#games-grid').addEventListener('click',async e=>{
    const btn=e.target.closest('[data-fav]'); if (!btn) return;
    const id=btn.dataset.fav; const favorite=!state.favorites.includes(id);
    try { const result=await post('api/library.php?action=favorite',{id,favorite});state.favorites=result.favorites;draw(); }
    catch(ex){toast(ex.message,true);}
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='/' && !['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)){
      e.preventDefault();$('#search-games').focus();
    }
  });
  $('#menu-toggle')?.addEventListener('click',()=>$('#sidebar').classList.toggle('show'));
  if(!['all','arcade','neogeo','pgm','nes','favorites'].includes(state.filter)) state.filter='all';
  draw();
})();
