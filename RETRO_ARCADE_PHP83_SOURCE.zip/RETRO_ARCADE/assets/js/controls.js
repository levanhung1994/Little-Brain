(function () {
  'use strict';
  const key = 'ra_controls_v1';
  const buttonIndices = [4,5,6,7,0,8,1,9,2,3];
  const labels = ['↑ Lên','↓ Xuống','← Trái','→ Phải','Nút B','Nút A','Nút Y','Nút X','Coin / Select','Start'];
  const defaults = {
    arcade: {
      0: ['up arrow','down arrow','left arrow','right arrow','z','x','a','s','shift','enter'],
      1: ['i','k','j','l','u','o','h','p','9','0']
    },
    nes: {
      0: ['up arrow','down arrow','left arrow','right arrow','z','x','a','s','shift','enter'],
      1: ['i','k','j','l','u','o','h','p','9','0']
    }
  };
  function read() {
    try { const stored = JSON.parse(localStorage.getItem(key) || '{}'); return stored && typeof stored === 'object' ? stored : {}; }
    catch { return {}; }
  }
  function display(v) {
    return ({'up arrow':'↑','down arrow':'↓','left arrow':'←','right arrow':'→','shift':'SHIFT','enter':'ENTER','space':'SPACE','escape':'ESC'})[v] || String(v||'—').toUpperCase();
  }
  function normalize(e) {
    const arrows={ArrowUp:'up arrow',ArrowDown:'down arrow',ArrowLeft:'left arrow',ArrowRight:'right arrow'};
    if(arrows[e.key]) return arrows[e.key];
    if(e.key === ' ') return 'space';
    if(e.key === 'Escape') return null;
    if(e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta' || e.key === 'Tab') return undefined;
    const value=e.key.toLowerCase();
    return value.length<=14 ? value : undefined;
  }
  function current(system,player){
    const user=read();const saved=user?.[system]?.[player];
    return buttonIndices.map((_,n)=>typeof saved?.[n]==='string' ? saved[n] : defaults[system][player][n]);
  }
  function build(system) {
    const controls={};
    const gamepadMapping={0:'BUTTON_2',1:'BUTTON_4',2:'SELECT',3:'START',
      4:'DPAD_UP',5:'DPAD_DOWN',6:'DPAD_LEFT',7:'DPAD_RIGHT',8:'BUTTON_1',9:'BUTTON_3'};
    for(const player of ['0','1']) {
      const values=current(system,player); controls[player]={};
      buttonIndices.forEach((index,n)=>{
        controls[player][index]={value:values[n],value2:gamepadMapping[index]};
      });
    }
    // EJS combines these keyboard defaults with native Gamepad API mappings.
    return controls;
  }
  function save(system,player,values){
    const cfg=read();cfg[system] ||= {};cfg[system][player]=values;
    try { localStorage.setItem(key,JSON.stringify(cfg));return true; } catch { return false; }
  }
  function reset(system,player){
    const cfg=read(); if(cfg[system]) delete cfg[system][player];
    try {localStorage.setItem(key,JSON.stringify(cfg));return true;}catch{return false;}
  }
  window.RetroControls={labels,buttonIndices,current,display,normalize,build,save,reset};
})();
