(() => {
  'use strict';
  const g=window.RA_PLAY;
  const $=s=>document.querySelector(s);
  const csrf=$('meta[name="ra-csrf"]')?.content||'';
  const isReady=g?.readiness==='attempt_ready';
  let initialReady=false;
  function setStatus(text,status='wait'){
    $('#game-status-text').textContent=text;
    $('#game-status-dot').className=status==='ok'?'ok':status==='error'?'err':'';
  }
  function toast(text,error=false){const x=$('#toast');x.textContent=text;x.className='toast show'+(error?' error':'');clearTimeout(toast.timer);toast.timer=setTimeout(()=>x.className='toast',4000);}
  const stage=$('#game-stage');
  const ctrl=()=>window.EJS_emulator;
  const abs=relative=>relative?new URL(relative,document.baseURI).href:'';
  async function recordPlay(){
    try{await fetch('api/library.php?action=played',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({id:g.id})});}
    catch(_){/* History is optional; game continues even if disk is read-only. */}
  }
  function loadEmulator(){
    if(!isReady)return;
    if(typeof WebAssembly!=='object'){
      setStatus('Trình duyệt không hỗ trợ WebAssembly.','error');
      $('#stage-loading strong').textContent='TRÌNH DUYỆT KHÔNG HỖ TRỢ WEBASSEMBLY';return;
    }
    if(!document.createElement('canvas').getContext('webgl')){
      setStatus('WebGL không khả dụng. Hãy bật tăng tốc phần cứng trong trình duyệt.','error');
      $('#stage-loading strong').textContent='CẦN WEBGL';return;
    }
    // The official loader.js reads these globals. No mock game is ever loaded.
    window.EJS_player='#game';
    window.EJS_core=g.core;
    window.EJS_pathtodata=abs('emulator/data/');
    window.EJS_gameUrl=abs(g.rom_url);
    window.EJS_biosUrl=abs(g.bios_url||'');
    window.EJS_gameParentUrl=abs(g.parent_url||'');
    window.EJS_gameID=Number(g.game_id)||1;
    window.EJS_gameName=g.id.replace(/[^a-zA-Z0-9._-]/g,'_');
    window.EJS_language='en-US';
    window.EJS_disableAutoLang=true;
    window.EJS_startOnLoaded=false;
    window.EJS_backgroundColor='#0b0e19';
    window.EJS_color='#f44768';
    window.EJS_threads=false;
    window.EJS_controlScheme=g.folder==='nes'?'nes':'arcade';
    window.EJS_defaultOptions={'save-state-location':'browser'};
    window.EJS_defaultControls=window.RetroControls?RetroControls.build(g.folder==='nes'?'nes':'arcade'):undefined;
    window.EJS_Buttons={playPause:true,restart:true,settings:true,fullscreen:true,saveState:true,loadState:true,gamepad:true,exitEmulation:true};
    window.EJS_ready=()=>{
      initialReady=true;
      $('#stage-loading')?.remove();
      setStatus('Giả lập đã sẵn sàng. Bấm START GAME trong màn hình game.');
    };
    window.EJS_onGameStart=()=>{
      initialReady=true;
      $('#stage-loading')?.remove();
      setStatus('Core đã khởi động · Nếu game báo thiếu ROM, hãy kiểm tra phiên bản ROM set.','ok');
      recordPlay();
    };
    window.EJS_onExit=()=>{setStatus('Đã thoát giả lập.');};
    const script=document.createElement('script');
    script.src=abs('emulator/data/loader.js');
    script.onerror=()=>{
      setStatus('Không tải được loader.js trong emulator/data.','error');
      const box=$('#stage-loading');if(box){box.querySelector('strong').textContent='THIẾU LOADER.JS';box.querySelector('small').textContent='Chạy scripts/install-emulator.ps1';}
    };
    document.head.appendChild(script);
    // Timeout is diagnostic only: large games may take longer to boot.
    setTimeout(()=>{
      if(!initialReady && !ctrl()?.started){
        setStatus('Chưa nhận tín hiệu READY. Kiểm tra trình duyệt/Console và file EmulatorJS.','error');
        $('#stage-loading')?.querySelector('small')?.replaceChildren('Kiểm tra Core .data, loader.js hoặc lỗi JavaScript trong Console.');
      }
    },25000);
    const monitor=setInterval(()=>{
      const emulator=ctrl();
      if(emulator?.failedToStart){setStatus('Core báo lỗi khởi động. Xem thông báo trong màn hình giả lập.','error');clearInterval(monitor);}
      else if(emulator?.started)clearInterval(monitor);
    },1250);
    setTimeout(()=>clearInterval(monitor),120000);
  }
  $('#pause-button')?.addEventListener('click',()=>{
    try{const e=ctrl();if(!e?.started||typeof e.pause!=='function')return toast('Cần khởi động game trước.',true);e.pause();setStatus('Game đã tạm dừng.');}
    catch(_){toast('Không thể Pause trên core này. Dùng menu EmulatorJS.',true);}
  });
  $('#resume-button')?.addEventListener('click',()=>{
    try{const e=ctrl();if(!e?.started||typeof e.play!=='function')return toast('Cần khởi động game trước.',true);e.play();setStatus('Core đang chạy.','ok');}
    catch(_){toast('Không thể Resume. Dùng menu EmulatorJS.',true);}
  });
  $('#restart-button')?.addEventListener('click',()=>{if(confirm('Khởi động lại game? Hãy lưu Save State trước khi tiếp tục.'))location.reload();});
  $('#fullscreen-button')?.addEventListener('click',async()=>{
    try{if(!document.fullscreenElement)await stage.requestFullscreen();else await document.exitFullscreen();}
    catch(_){toast('Trình duyệt từ chối toàn màn hình.',true);}
  });
  $('#menu-toggle')?.addEventListener('click',()=>$('#sidebar').classList.toggle('show'));
  if(isReady)loadEmulator();else setStatus('Thiếu thành phần: mở trang cài đặt để xem chi tiết.','error');
})();
