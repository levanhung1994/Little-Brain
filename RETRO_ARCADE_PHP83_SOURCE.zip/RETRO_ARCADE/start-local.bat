@echo off
setlocal
cd /d "%~dp0"
where php >nul 2>nul
if errorlevel 1 (
 echo PHP not found in PATH. Install PHP 8.3+ and add php.exe to PATH.
 pause
 exit /b 1
)
echo RETRO ARCADE starting at http://127.0.0.1:8000
echo Keep this window open while playing. Press Ctrl+C to stop.
start "" "http://127.0.0.1:8000"
php -S 127.0.0.1:8000 router.php
pause
