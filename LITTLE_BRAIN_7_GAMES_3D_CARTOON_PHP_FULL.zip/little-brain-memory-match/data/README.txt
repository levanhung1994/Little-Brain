LITTLE BRAIN - THU MUC LUU DU LIEU (PRIVATE)

Cac file history.json, profiles.json, achievements.json va settings.json
se duoc PHP tu dong tao trong lan mo website dau tien.

Khong xoa cac file nay sau khi be da choi.
Khi sao luu hay chuyen may, hay copy cac file .json va .bak o day.

QUAN TRONG: Cai dat web root vao thu muc ../public de khong
cho phep trinh duyet truy cap truc tiep du lieu cua be.
