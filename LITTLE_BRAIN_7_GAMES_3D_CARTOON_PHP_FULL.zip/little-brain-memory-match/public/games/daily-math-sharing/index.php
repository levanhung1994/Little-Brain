<?php
declare(strict_types=1);
require dirname(__DIR__, 3) . '/app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
$csrf = htmlspecialchars((string) $_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="vi">
<head>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="theme-color" content="#f7f9ff">
 <meta name="csrf-token" content="<?= $csrf ?>">
 <title>Chia bánh cho bạn | Toán vui mỗi ngày · Little Brain</title>
 <link rel="icon" type="image/svg+xml" href="../../assets/images/brand/brain.svg">
 <link rel="stylesheet" href="../../assets/css/logic-games.css?v=1.0.0">
 <link rel="stylesheet" href="../../assets/css/daily-math.css?v=1.0.0">
 <script src="../../assets/js/daily-math.js?v=20261014.1" defer></script>
  <link rel="stylesheet" href="../../assets/css/3d-kids.css?v=20261014.1">
</head>
<body class="share-app">
<div class="share-shell">
 <header class="share-topbar">
  <a class="share-brand" href="../../index.php"><img src="../../assets/images/brand/brain.webp" alt=""><b>LITTLE <span>BRAIN</span></b></a>
  <nav class="share-nav"><a href="../../index.php">⌂ <span>Kho trò chơi</span></a></nav>
  <div class="share-profile"><label for="share-player">Bé đang học</label><select id="share-player" aria-label="Chọn hồ sơ của bé"><option>Đang tải...</option></select><button type="button" id="share-add-player" class="share-add-player" aria-label="Tạo hồ sơ bé" title="Thêm hồ sơ">+</button></div>
 </header>
 <main>
  <div class="share-page-title"><div><div class="share-eyebrow">TOÁN VUI MỖI NGÀY <span class="share-title-dot">✦</span></div><h1>Chia bánh cho bạn <span aria-hidden="true">🍪</span></h1></div><button type="button" id="share-level-toggle" aria-expanded="false" class="share-option-btn">⚙ Cấp độ</button></div>
  <div class="share-level-picker" id="share-level-picker" hidden aria-label="Chọn cấp độ"><button class="active" data-level="easy" type="button">Dễ</button><button data-level="normal" type="button">Vừa</button><button data-level="advanced" type="button">Khá</button><button data-level="hard" type="button">Khó</button></div>
  <div class="share-layout">
   <section class="share-game-panel" aria-label="Bài toán chia bánh">
    <div class="share-stage-strip"><span class="share-day-label"><span class="share-round-dot"></span> 5 bài toán hôm nay</span><div class="share-steps" id="share-steps" aria-label="Tiến độ 5 bài"></div><strong id="share-stage-count">Bài 1 / 5</strong></div>
    <div class="share-question"><div class="share-question-illustration"><img src="../../assets/images/daily-math/cookie.webp" alt=""></div><div><span>CHIA ĐỀU CHO CÁC BẠN</span><h2 id="share-task-title">Mình cùng chia bánh nhé!</h2><p id="share-task-hint">Bấm vào đĩa của bạn để cho bánh.</p></div></div>
    <div class="share-friends" id="share-friends" aria-live="polite" aria-label="Những người bạn nhận bánh"></div>
    <div class="share-tray"><div class="share-tray-head"><span><img src="../../assets/images/daily-math/cookie.webp" alt=""> <b>Giỏ bánh</b></span><strong id="share-cookies-left">0 chiếc còn lại</strong></div><div class="share-tray-cookies" id="share-cookie-tray" role="group" aria-label="Những chiếc bánh còn trong giỏ"></div></div>
    <div class="share-play-actions"><button type="button" id="share-reset" class="share-reset-btn">↺ &nbsp;Chia lại</button><button type="button" id="share-hint" class="share-hint-btn">✦ &nbsp;Gợi ý</button><button type="button" id="share-check" class="share-check-btn">✓ &nbsp;Kiểm tra kết quả</button></div>
    <div class="share-feedback" id="share-feedback" role="status" aria-live="polite">Bé chia cho mỗi bạn số bánh bằng nhau nhé!</div>
   </section>
   <aside class="share-flower-side" aria-label="Điểm danh bông hoa">
    <div class="share-flower-card"><div class="share-flower-title"><span>✿</span><div><h2>Bông hoa chăm chỉ</h2><p>5 ngày học · 1 phần thưởng</p></div></div>
     <div class="share-flower-art" id="share-flower-art" aria-label="Bông hoa điểm danh 5 cánh"></div>
     <div class="share-flower-progress"><strong id="share-flower-count">0 / 5 cánh</strong><span id="share-flower-status">Mỗi ngày học đủ 5 bài, bé có thêm 1 cánh hoa.</span></div>
     <div class="share-petal-dots" id="share-petal-dots" aria-label="Số cánh hoa đã điểm danh"></div>
     <div class="share-reward-note"><span>🎁</span><div>Đủ 5 cánh được thưởng <strong>10.000đ</strong><small>Bố mẹ trao phần thưởng cho bé</small></div></div>
    </div>
    <div class="share-calendar-card"><div class="share-calendar-heading">✦ Những ngày bé đã học <span id="share-total-days">0 ngày</span></div><div class="share-day-chips" id="share-day-chips">Chưa có ngày điểm danh.</div><div id="share-reward-actions"></div></div>
   </aside>
  </div>
 </main>
</div>
<div class="share-modal-layer" id="share-modal" hidden><div class="share-modal" role="dialog" aria-modal="true" aria-labelledby="share-modal-title"><button id="share-modal-close" type="button" class="share-modal-close" aria-label="Đóng hộp thoại">×</button><div id="share-modal-body"></div></div></div>
<div class="share-toast" id="share-toast" role="status" aria-live="polite" hidden></div>
</body>
</html>
