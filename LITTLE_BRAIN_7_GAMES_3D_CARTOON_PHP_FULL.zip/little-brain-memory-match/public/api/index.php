<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

try {
    $action = (string) ($_GET['action'] ?? 'bootstrap');
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $postActions = ['create_profile','select_profile','start','finish','start_challenge','finish_challenge','daily_math_start','daily_math_answer','daily_math_hint','daily_math_mark_reward'];
    if (in_array($action, $postActions, true)) {
        if ($method !== 'POST') respond(['ok'=>false,'error'=>'Yêu cầu phương thức POST.'],405);
        $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!is_string($sent) || !hash_equals((string) $_SESSION['csrf_token'], $sent)) {
            respond(['ok'=>false,'error'=>'Phiên bảo mật hết hạn. Hãy tải lại trang.'],403);
        }
        $raw = file_get_contents('php://input');
        if ($raw === false || strlen($raw) > 8192) respond(['ok'=>false,'error'=>'Dữ liệu yêu cầu quá lớn.'],413);
        $payload = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        if (!is_array($payload)) throw new InvalidArgumentException('Dữ liệu gửi lên không hợp lệ.');
    } else {
        if ($method !== 'GET') respond(['ok'=>false,'error'=>'Yêu cầu phương thức GET.'],405);
        $payload = [];
    }
    $data = match ($action) {
        'bootstrap' => service()->bootstrap(),
        'create_profile' => service()->createProfile((string) ($payload['name'] ?? '')),
        'select_profile' => service()->selectProfile((string) ($payload['player_id'] ?? '')),
        'start' => service()->start((string) ($payload['theme'] ?? ''), (string) ($payload['difficulty'] ?? ''), (string) ($payload['player_id'] ?? '')),
        'finish' => service()->finish($payload),
        'start_challenge' => service()->startChallenge((string) ($payload['game_key'] ?? ''), (string) ($payload['difficulty'] ?? ''), (string) ($payload['player_id'] ?? '')),
        'finish_challenge' => service()->finishChallenge($payload),
        'history' => service()->history((string) ($_GET['player_id'] ?? ''), (int) ($_GET['limit'] ?? 20), (int) ($_GET['offset'] ?? 0)),
        'achievements' => service()->achievements((string) ($_GET['player_id'] ?? '')),
        'daily_math_status' => daily_math()->status((string) ($_GET['player_id'] ?? '')),
        'daily_math_start' => daily_math()->start((string) ($payload['player_id'] ?? ''), (string) ($payload['difficulty'] ?? 'easy')),
        'daily_math_answer' => daily_math()->answer((string) ($payload['player_id'] ?? ''), (string) ($payload['token'] ?? ''), $payload['counts'] ?? null),
        'daily_math_hint' => daily_math()->hint((string) ($payload['player_id'] ?? ''), (string) ($payload['token'] ?? '')),
        'daily_math_mark_reward' => daily_math()->markReward((string) ($payload['player_id'] ?? ''), (string) ($payload['reward_id'] ?? '')),
        default => throw new InvalidArgumentException('Chức năng không tồn tại.'),
    };
    respond(['ok'=>true, 'data'=>$data]);
} catch (InvalidArgumentException | JsonException $e) {
    respond(['ok'=>false, 'error'=>$e->getMessage()], 422);
} catch (Throwable $e) {
    error_log('[Little Brain] ' . $e->getMessage());
    respond(['ok'=>false, 'error'=>'Không thể xử lý hoặc ghi dữ liệu. Hãy kiểm tra quyền thư mục data và file log PHP.'], 500);
}
