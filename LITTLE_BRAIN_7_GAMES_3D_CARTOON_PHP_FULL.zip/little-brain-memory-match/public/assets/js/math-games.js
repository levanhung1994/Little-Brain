'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const config = JSON.parse($('logic-config').textContent);
  const gameKey = config.gameKey;
  const isNumber = gameKey === 'missing-number';
  if (!['missing-number', 'little-shop'].includes(gameKey) || config.totalSteps !== 5) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const labels = { easy:'Dễ', normal:'Vừa', advanced:'Khá', hard:'Khó' };
  const names = {
    strawberry:{name:'Dâu tây',price:1}, apple:{name:'Táo',price:2},
    banana:{name:'Chuối',price:3}, orange:{name:'Cam',price:4},
    grapes:{name:'Nho',price:5}, pear:{name:'Lê',price:3},
    watermelon:{name:'Dưa hấu',price:6}, cherry:{name:'Anh đào',price:2},
  };
  const image = id => `../../assets/images/fruits/${id}.webp`;
  const escapeHTML = t => String(t ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pref = (name, fallback) => { try { const v=localStorage.getItem('lb-'+name); return v===null?fallback:JSON.parse(v); } catch { return fallback; } };
  const setPref = (name, val) => { try { localStorage.setItem('lb-'+name,JSON.stringify(val)); } catch {} };
  function shuffle(a) { for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a; }
  const state = {
    profiles:[],playerId:null,level:pref(gameKey+'-level','easy'),sound:pref('sound',true),
    reduceMotion:pref('reduced-motion',false),stage:0,attempts:0,mistakes:0,hints:0,elapsed:0,
    started:false,finished:false,saving:false,busy:false,successPending:false,switchingProfile:false,
    generation:0,startTime:0,startPromise:null,clock:null,timers:[],audio:null,
    round:[],puzzle:null,options:[],cart:{},phase:'cart',paid:0,changeOptions:[]
  };
  async function api(action, body=null) {
    const url = new URL('../../api/index.php', location.href);
    url.searchParams.set('action',action);
    const options = body===null ? {credentials:'same-origin',cache:'no-store'} : {
      method:'POST', credentials:'same-origin', cache:'no-store',
      headers:{'Content-Type':'application/json','X-CSRF-Token':csrf}, body:JSON.stringify(body)
    };
    let response;
    try { response=await fetch(url,options); } catch {throw new Error('Không kết nối được PHP. Hãy chạy máy chủ rồi thử lại.');}
    let result;
    try { result=await response.json(); } catch {throw new Error('Phản hồi từ PHP không hợp lệ.');}
    if(!response.ok || !result.ok) throw new Error(result.error || 'Có lỗi xảy ra.');
    return result.data;
  }
  function schedule(fn,ms){const id=setTimeout(()=>{state.timers=state.timers.filter(t=>t!==id);fn();},ms);state.timers.push(id);}
  function cancelTimers(){state.timers.forEach(clearTimeout);state.timers=[];clearInterval(state.clock);state.clock=null;}
  function timeText(seconds){return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}
  function notify(message){const el=$('logic-toast');el.textContent=message;el.hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>el.hidden=true,3200);}
  function feedback(message,tone='neutral'){$('logic-feedback').textContent=message;$('logic-feedback').dataset.tone=tone;}
  function gameMessage(message,tone='neutral'){const el=$(isNumber?'math-inline-feedback':'shop-message');el.textContent=message;el.dataset.tone=tone;}
  function sound(kind){
    if(!state.sound)return;
    try {
      const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
      state.audio ||= new C();if(state.audio.state==='suspended')state.audio.resume().catch(()=>{});
      const notes = kind==='win'?[523,659,784,988]:kind==='good'?[630,793]:kind==='bad'?[350,305]:[510];
      notes.forEach((hz,i)=>{const t=state.audio.currentTime+i*.09,osc=state.audio.createOscillator(),gain=state.audio.createGain();
        osc.type='sine';osc.frequency.value=hz;gain.gain.setValueAtTime(.0001,t);
        gain.gain.exponentialRampToValueAtTime(.055,t+.016);gain.gain.exponentialRampToValueAtTime(.0001,t+.20);
        osc.connect(gain);gain.connect(state.audio.destination);osc.start(t);osc.stop(t+.21);
      });
    } catch {}
  }
  function modal(html){$('logic-modal-body').innerHTML=html;$('logic-modal').hidden=false;$('logic-modal-close').focus();}
  function closeModal(){if($('logic-modal').hidden)return;$('logic-modal').hidden=true;if(state.successPending){state.successPending=false;advance();}}
  function setPanel(open){$('logic-workspace').classList.toggle('sidebar-collapsed',!open);$('logic-panel-toggle').setAttribute('aria-expanded',String(open));$('logic-panel-toggle').textContent=open?'✕ Đóng tùy chọn':'⚙ Tùy chọn';}
  function askChange(fn){
    if(state.saving||state.switchingProfile){notify('Vui lòng chờ một chút nhé!');return;}
    if(!state.started||state.finished){fn();return;}
    modal(`<div class="result-mark">↻</div><h2 id="logic-modal-title">Bắt đầu lại nhé?</h2><p>Ván đang chơi chưa được lưu.</p><div class="logic-modal-actions"><button class="logic-soft-button" id="math-stay" type="button">Chơi tiếp</button><button class="logic-main-button" id="math-change" type="button">Đổi ván</button></div>`);
    $('math-stay').onclick=closeModal;
    $('math-change').onclick=()=>{closeModal();fn();};
  }
  function makeProfiles(){$('logic-player').innerHTML=state.profiles.map(p=>`<option value="${escapeHTML(p.id)}" ${p.id===state.playerId?'selected':''}>${escapeHTML(p.name)}</option>`).join('');}
  function createProfile(){
    modal('<h2 id="logic-modal-title">Thêm hồ sơ bé</h2><form id="math-profile-form" class="logic-profile-form"><label for="math-profile-name">Tên bé</label><input id="math-profile-name" maxlength="24" required autocomplete="off"><div class="logic-modal-actions"><button id="math-profile-cancel" type="button" class="logic-soft-button">Hủy</button><button id="math-profile-save" class="logic-main-button" type="submit">Lưu hồ sơ</button></div></form>');
    $('math-profile-cancel').onclick=closeModal;$('math-profile-name').focus();
    $('math-profile-form').onsubmit=async e=>{e.preventDefault();const btn=$('math-profile-save');btn.disabled=true;try{const p=await api('create_profile',{name:$('math-profile-name').value});state.profiles.push(p);state.playerId=p.id;setPref('player-id',p.id);closeModal();makeProfiles();newRound();}catch(err){notify(err.message);btn.disabled=false;}};
  }
  function begin(){
    if(state.started || state.finished)return;
    state.started=true;state.startTime=performance.now();const gen=state.generation;
    state.startPromise=api('start_challenge',{game_key:gameKey,difficulty:state.level,player_id:state.playerId});
    state.startPromise.catch(err=>{if(gen===state.generation)notify(`Không mở được ván: ${err.message}`);});
    state.clock=setInterval(()=>{if(gen!==state.generation)return;state.elapsed=Math.min(86400,Math.floor((performance.now()-state.startTime)/1000));updateStats();},1000);
  }
  function updateStats(){
    $('logic-progress-stat').textContent=`${state.stage}/5`;
    $('logic-attempts').textContent=String(state.attempts);
    $('logic-time').textContent=timeText(state.elapsed);
    $('logic-step-dots').innerHTML=Array.from({length:5},(_,i)=>`<i class="${i<state.stage?'done':i===state.stage?'current':''}"></i>`).join('');
    $('logic-stage-label').textContent=state.finished?'Hoàn thành 5 / 5':`${isNumber?'Câu':'Đơn'} ${Math.min(state.stage+1,5)} / 5`;
    $('logic-level-tag').textContent='✦ '+labels[state.level];
    $('logic-restart').disabled=state.saving||state.switchingProfile;
    $('logic-hint').disabled=state.busy||state.finished||state.saving||!state.playerId||state.switchingProfile;
    document.querySelectorAll('[data-level]').forEach(b=>{const active=b.dataset.level===state.level;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
  }
  function newRound(){
    state.generation++;cancelTimers();state.stage=0;state.attempts=0;state.mistakes=0;state.hints=0;state.elapsed=0;
    state.started=false;state.finished=false;state.saving=false;state.busy=false;state.successPending=false;state.startPromise=null;
    state.round=isNumber?makeNumberRound(state.level):makeShopRound(state.level);
    $('logic-stars').textContent='☆☆☆';renderStage();updateStats();
  }
  function showSuccess(message){
    if(state.successPending||state.finished)return;
    state.successPending=true;const last=state.stage===4;
    sound('good');
    modal(`<div class="result-mark math-win-mark">🌟</div><h2 id="logic-modal-title">${last?'Xuất sắc quá!':'Chúc mừng bé!'}</h2><p>${escapeHTML(message)}</p><div class="math-success-progress">✓ ${isNumber?'Câu':'Đơn'} ${state.stage+1} / 5</div><div class="logic-modal-actions"><button id="math-next" class="logic-main-button" type="button">${last?'Xem thành tích':'Bài tiếp theo →'}</button></div>`);
    $('math-next').onclick=closeModal;$('math-next').focus();
  }
  function advance(){
    if(state.finished||state.saving)return;
    state.stage++;
    if(state.stage===5){updateStats();finish();}else{renderStage();updateStats();}
  }
  async function finish(){
    if(state.finished||state.saving||state.stage!==5)return;
    state.finished=true;state.saving=true;state.busy=true;
    state.elapsed=Math.min(86400,Math.floor((performance.now()-state.startTime)/1000));
    clearInterval(state.clock);state.clock=null;updateStats();
    const gen=state.generation;
    try {
      const start=await state.startPromise;
      if(gen!==state.generation)return;
      const result=await api('finish_challenge',{round_token:start.round_token,attempts:state.attempts,
        mistakes:state.mistakes,hints_used:state.hints,duration_seconds:state.elapsed});
      if(gen!==state.generation)return;
      state.saving=false;updateStats();$('logic-stars').textContent='★'.repeat(result.stars)+'☆'.repeat(3-result.stars);
      feedback('Hoan hô! Bé hoàn thành cả 5 bài rồi!', 'good');sound('win');
      modal(`<div class="result-mark math-win-mark">🏆</div><h2 id="logic-modal-title">Bé thật tuyệt vời!</h2><p>Đã hoàn thành 5 ${isNumber?'câu đố toán học':'đơn mua sắm'}.</p><div class="result-big-stars">${'★'.repeat(result.stars)}<span>${'☆'.repeat(3-result.stars)}</span></div><div class="result-overview"><div><b>${result.attempts}</b><small>Lượt trả lời</small></div><div><b>${timeText(result.duration_seconds)}</b><small>Thời gian</small></div><div><b>${Number(result.accuracy).toFixed(1)}%</b><small>Chính xác</small></div></div><p class="result-saved">✓ Đã lưu vào lịch sử của bé</p><div class="logic-modal-actions"><a class="logic-soft-button" href="../../index.php#history">Lịch sử</a><button id="math-play-again" class="logic-main-button" type="button">Chơi tiếp →</button></div>`);
      $('math-play-again').onclick=()=>{closeModal();newRound();};
    } catch(err) {
      if(gen!==state.generation)return;
      state.saving=false;updateStats();
      modal(`<div class="result-mark">💛</div><h2 id="logic-modal-title">Bé đã làm xong!</h2><p>Chưa lưu được: ${escapeHTML(err.message)}</p><div class="logic-modal-actions"><button id="math-retry-save" class="logic-main-button" type="button">Thử lưu lại</button></div>`);
      $('math-retry-save').onclick=()=>{closeModal();state.finished=false;finish();};
    }
  }
  function hint(){
    if(state.busy||state.finished||state.saving||!state.playerId)return;
    begin();state.hints++;sound('tap');
    if(isNumber){
      const p=state.puzzle;
      gameMessage(p.hint,'hint');
    } else {
      const p=state.puzzle;
      if(state.phase==='cart'){
        gameMessage('Nhìn danh sách phía trên: thêm đúng loại và đúng số lượng trái cây nhé!','hint');
      } else if(p.tender===null){
        gameMessage(`Tổng tiền là ${totalPrice(p.items)} xu. Bé dùng tiền xu để cộng đúng số này nhé!`,'hint');
      } else {
        gameMessage(`Tiền thừa = ${p.tender} xu tiền đưa − ${totalPrice(p.items)} xu tiền hàng.`,'hint');
      }
    }
    updateStats();
  }

  // -------------------- Missing Number --------------------
  function makeNumberRound(level){
    const bank=[];
    const add=(parts,answer,hint,type)=>{
      if(answer<0||answer>20)return;
      bank.push({parts:parts.map(String),answer,hint,type});
    };
    if(level==='easy'){
      for(let a=1;a<=4;a++)for(let b=1;b<=4;b++)if(a+b<=5){
        add(['?', '+', b, '=', a+b],a,`Lấy tổng ${a+b} trừ ${b} để tìm dấu hỏi.`, 'plus');
        add([a,'+','?','=',a+b],b,`Lấy tổng ${a+b} trừ ${a} để tìm dấu hỏi.`, 'plus');
      }
    } else if(level==='normal'){
      for(let a=2;a<=8;a++)for(let b=1;b<=8;b++)if(a+b<=10){
        add([a,'+','?','=',a+b],b,`Lấy ${a+b} trừ ${a}.`,'plus');
        add(['?', '-',b,'=',a],a+b,`Có một số, bớt ${b} còn ${a}. Hãy cộng ${a} với ${b}.`,'minus');
        add([a+b,'-','?','=',a],b,`Lấy ${a+b} trừ ${a} để biết số đã bớt.`,'minus');
      }
    } else if(level==='advanced'){
      for(let a=4;a<=13;a++)for(let b=2;b<=9;b++)if(a+b<=20){
        add([a,'+','?','=',a+b],b,`Lấy ${a+b} trừ ${a}.`,'plus');
        add(['?','+',b,'=',a+b],a,`Lấy ${a+b} trừ ${b}.`,'plus');
        add([a+b,'-','?','=',a],b,`Lấy ${a+b} trừ ${a}.`,'minus');
        add(['?','-',b,'=',a],a+b,`Lấy ${a} cộng ${b}.`,'minus');
      }
    } else {
      for(let a=5;a<=15;a++)for(let b=1;b<=6;b++)for(let c=1;c<=5;c++){
        const r1=a+b-c, r2=a-b+c;
        if(r1>=1&&r1<=20){
          add(['?','+',b,'-',c,'=',r1],a,`Làm ngược: lấy ${r1} cộng ${c}, rồi trừ ${b}.`,'mixed');
          add([a,'+','?','-',c,'=',r1],b,`Lấy ${r1} cộng ${c}, rồi trừ ${a}.`,'mixed');
        }
        if(a>=b&&r2>=1&&r2<=20){
          add([a,'-','?','+',c,'=',r2],b,`Lấy ${a} cộng ${c}, rồi trừ ${r2}.`,'mixed');
          add(['?','-',b,'+',c,'=',r2],a,`Lấy ${r2} trừ ${c}, rồi cộng ${b}.`,'mixed');
        }
      }
    }
    const selected=shuffle(bank).slice(0,5);
    // Every puzzle has exactly one missing value and five stages never repeat an identical equation.
    if(selected.length!==5||new Set(selected.map(p=>p.parts.join(''))).size!==5)throw new Error('Không đủ câu đố duy nhất.');
    return selected;
  }
  function numberChoices(answer,level){
    const top=level==='easy'?6:level==='normal'?11:21;
    const choices=new Set([answer]);
    const neighbors=shuffle([-3,-2,-1,1,2,3,4,-4,5,-5]);
    for(const d of neighbors){const n=answer+d;if(n>=0&&n<top)choices.add(n);if(choices.size>=4)break;}
    for(let n=0;n<top&&choices.size<4;n++)choices.add(n);
    return shuffle([...choices].slice(0,4));
  }
  function beadRow(n){return `<div class="math-count-strip" aria-label="${n} chấm tròn">${Array.from({length:n},()=>'<i></i>').join('')}</div>`;}
  function renderNumber(){
    const p=state.puzzle;
    $('math-number-index').textContent=String(state.stage+1);
    $('math-equation').innerHTML=p.parts.map(t=>{
      const op=['+','-','=','−'].includes(t);
      return `<span class="math-token ${t==='?'?'math-unknown':op?'math-operator':'math-value'}">${t==='-'?'−':t}</span>`;
    }).join('');
    const rhs=Number(p.parts[p.parts.length-1]);
    $('math-visual').innerHTML=rhs<=12?`<span>${rhs} chấm:</span>${beadRow(rhs)}`:`<span>Gợi ý: thử tính từ dấu bằng</span>`;
    state.options=numberChoices(p.answer,state.level);
    $('math-answers').innerHTML=state.options.map((n,i)=>`<button type="button" class="math-answer" data-answer="${n}" aria-label="Chọn số ${n}"><span class="math-answer-symbol">${n}</span><span class="math-answer-letter">${String.fromCharCode(65+i)}</span></button>`).join('');
    gameMessage('');feedback('Chọn số còn thiếu nhé!');
  }
  function selectNumber(n){
    if(state.busy||state.finished||state.saving||!state.playerId||!state.puzzle||!state.options.includes(n))return;
    begin();state.attempts++;state.busy=true;
    const correct=n===state.puzzle.answer;
    const button=$('math-answers').querySelector(`[data-answer="${n}"]`);
    $('math-answers').querySelectorAll('button').forEach(b=>b.disabled=true);
    button?.classList.add(correct?'answer-good':'answer-bad');
    updateStats();
    if(correct){
      gameMessage('Đúng rồi! Bé tìm được số bí mật! ⭐','good');feedback('Chính xác!','good');
      schedule(()=>showSuccess('Bé đã tìm đúng con số còn thiếu!'),state.reduceMotion?70:550);
    } else {
      state.mistakes++;sound('bad');gameMessage('Chưa đúng rồi. Bé thử một số khác nhé!','try');feedback('Cùng thử lại nhé!','try');
      schedule(()=>{if(state.finished)return;state.busy=false;button?.classList.remove('answer-bad');$('math-answers').querySelectorAll('button').forEach(b=>b.disabled=false);updateStats();},state.reduceMotion?90:650);
    }
  }

  // -------------------- Little Shop --------------------
  const presets = {
    easy: [
      {apple:1},{banana:1},{strawberry:1},{orange:1},{grapes:1},{pear:1},{cherry:1}
    ],
    normal: [
      {apple:1,banana:1},{apple:1,strawberry:1},{orange:1,banana:1},
      {grapes:1,apple:1},{pear:1,strawberry:2},{banana:1,cherry:2},
      {orange:1,grapes:1},{apple:2,banana:1},{orange:2,strawberry:1}
    ],
    advanced: [
      {apple:1,banana:1,orange:1},{grapes:1,strawberry:2},{pear:1,banana:2},
      {orange:2,apple:1},{banana:1,cherry:2,strawberry:1},{apple:2,grapes:1},
      {orange:1,pear:1,apple:1},{grapes:2,strawberry:1},{banana:2,orange:1}
    ],
    hard: [
      {apple:2,banana:1,orange:1},{grapes:2,strawberry:3},{pear:2,banana:2},
      {watermelon:1,orange:2,apple:1},{apple:2,grapes:2,strawberry:1},
      {banana:3,orange:1,pear:1},{watermelon:2,banana:1,strawberry:2},
      {pear:2,grapes:1,cherry:2},{orange:3,apple:2,strawberry:1}
    ]
  };
  const totalPrice = items => Object.entries(items).reduce((sum,[id,count])=>sum+names[id].price*count,0);
  function makeShopRound(level){
    return shuffle(presets[level].filter(p=>totalPrice(p)<=20).map(items=>{
      const total=totalPrice(items);
      const tender=(level==='easy'||level==='normal')?null:
        level==='advanced'?(total<=10?10:total<=15?15:20):20;
      return {items:{...items},tender};
    })).slice(0,5);
  }
  function cartMatches(task,cart){
    const entries=Object.entries(cart).filter(([,n])=>n>0);
    return entries.length===Object.keys(task).length&&Object.entries(task).every(([id,n])=>cart[id]===n);
  }
  function changeChoices(correct){
    const values=new Set([correct]);
    for(const offset of shuffle([1,-1,2,-2,3,-3,4,-4,5,-5])){
      const n=correct+offset;if(n>=0&&n<=20)values.add(n);if(values.size===4)break;
    }
    for(let n=0;values.size<4&&n<=20;n++)values.add(n);
    return shuffle([...values].slice(0,4));
  }
  function renderShop(){
    const p=state.puzzle;
    state.cart={};state.phase='cart';state.paid=0;state.changeOptions=[];
    $('math-shop-index').textContent=String(state.stage+1);
    $('shop-list').innerHTML=Object.entries(p.items).map(([id,n])=>`<div class="shop-list-item"><img src="${image(id)}" alt=""><span>${escapeHTML(names[id].name)}</span><strong>× ${n}</strong></div>`).join('');
    const stock=(state.level==='hard')?['apple','banana','strawberry','orange','grapes','pear','watermelon','cherry']:
      ['apple','banana','strawberry','orange','grapes','pear','cherry'];
    $('shop-products').innerHTML=stock.map(id=>`<article class="shop-product" data-product="${id}"><img src="${image(id)}" alt="${escapeHTML(names[id].name)}" draggable="false"><b>${escapeHTML(names[id].name)}</b><span class="shop-price">${names[id].price} xu</span><div class="shop-quantity"><button class="shop-minus" type="button" data-minus="${id}" aria-label="Bớt một ${escapeHTML(names[id].name)}">−</button><output data-qty="${id}">0</output><button class="shop-plus" type="button" data-plus="${id}" aria-label="Thêm một ${escapeHTML(names[id].name)}">＋</button></div></article>`).join('');
    $('shop-check').hidden=false;$('shop-check').textContent='Kiểm tra giỏ →';
    $('shop-cart-reset').disabled=false;
    renderCart();gameMessage('');feedback('Chọn đúng trái cây theo danh sách nhé!');
  }
  function renderCart(){
    const entries=Object.entries(state.cart).filter(([,n])=>n>0);
    $('shop-cart-lines').innerHTML=entries.length?entries.map(([id,n])=>`<div class="shop-cart-line"><img src="${image(id)}" alt=""><span>${escapeHTML(names[id].name)} × ${n}</span><b>${n*names[id].price} xu</b></div>`).join(''):'<div class="shop-cart-empty">🛒<span>Giỏ hàng còn trống</span></div>';
    $('shop-total').textContent=totalPrice(state.cart)+' xu';
    $('shop-products').querySelectorAll('[data-qty]').forEach(out=>out.textContent=String(state.cart[out.dataset.qty]||0));
    $('shop-products').querySelectorAll('.shop-plus,.shop-minus').forEach(b=>b.disabled=state.phase!=='cart'||state.busy||state.saving);
    $('shop-cart-reset').disabled=state.phase!=='cart'||state.busy||state.saving;
    renderPayment();
  }
  function renderPayment(){
    const el=$('shop-payment'),p=state.puzzle;
    if(state.phase==='cart'){el.innerHTML='<div class="shop-pay-placeholder">Chọn hàng xong, bé nhấn <b>Kiểm tra giỏ</b> nhé!</div>';return;}
    if(p.tender===null){
      el.innerHTML=`<div class="shop-pay-caption">💰 Bé đưa đúng <b>${totalPrice(p.items)} xu</b> nhé!</div><div class="shop-coins" role="group" aria-label="Chọn tiền xu">${[1,2,5,10].filter(n=>state.level==='easy'?n<=5:true).map(n=>`<button class="shop-coin coin-${n}" data-coin="${n}" type="button" ${state.busy?'disabled':''}>${n}<small>xu</small></button>`).join('')}</div><div class="shop-paid-row"><span>Đã đưa: <b>${state.paid} xu</b></span><button id="shop-reset-money" type="button" ${state.busy?'disabled':''}>Đặt lại</button></div>`;
      $('shop-check').hidden=false;$('shop-check').textContent='Thanh toán ✓';
    } else {
      el.innerHTML=`<div class="shop-change-banner"><span>💵 Tiền đưa: <b>${p.tender} xu</b></span><span>🧾 Tiền hàng: <b>${totalPrice(p.items)} xu</b></span></div><div class="shop-change-question">Bé nhận lại bao nhiêu xu?</div><div class="shop-change-answers">${state.changeOptions.map(n=>`<button class="shop-change-answer" data-change="${n}" type="button" ${state.busy?'disabled':''}>${n} <small>xu</small></button>`).join('')}</div>`;
      $('shop-check').hidden=true;
    }
  }
  function changeQuantity(id,delta){
    if(state.phase!=='cart'||state.busy||state.finished||state.saving||!names[id]||!state.playerId)return;
    const current=state.cart[id]||0;
    const next=Math.max(0,Math.min(5,current+delta));
    if(next===current)return;
    begin();if(next===0)delete state.cart[id];else state.cart[id]=next;
    sound('tap');gameMessage('');renderCart();
  }
  function failShop(message){
    state.attempts++;state.mistakes++;sound('bad');gameMessage(message,'try');feedback('Bé thử lại nhé!','try');updateStats();
  }
  function checkShop(){
    if(state.busy||state.finished||state.saving||!state.playerId)return;
    const p=state.puzzle;
    if(state.phase==='cart'){
      begin();
      if(!cartMatches(p.items,state.cart)){
        failShop('Giỏ hàng chưa đúng danh sách. Bé xem lại loại quả và số lượng nhé!');return;
      }
      state.phase='pay';state.paid=0;
      state.changeOptions=p.tender===null?[]:changeChoices(p.tender-totalPrice(p.items));
      $('shop-products').querySelectorAll('.shop-plus,.shop-minus').forEach(b=>b.disabled=true);
      renderCart();gameMessage('Giỏ hàng đúng rồi! Giờ mình thanh toán nhé!','good');sound('good');
      return;
    }
    if(p.tender===null){
      begin();
      if(state.paid!==totalPrice(p.items)){
        failShop('Tiền chưa đủ hoặc chưa đúng. Bé chọn lại các đồng xu nhé!');return;
      }
      state.attempts++;stageComplete('Bé mua hàng và trả tiền chính xác rồi!');
    }
  }
  function giveCoin(n){if(state.phase!=='pay'||state.puzzle.tender!==null||state.busy||state.saving||state.finished)return;
    begin();if(state.paid+n>30){gameMessage('Bé đã chọn nhiều tiền quá, hãy đặt lại nhé!','try');return;}
    state.paid+=n;sound('tap');renderPayment();gameMessage('');
  }
  function giveChange(n){
    if(state.phase!=='pay'||state.puzzle.tender===null||state.busy||state.saving||state.finished||!state.changeOptions.includes(n))return;
    begin();const due=state.puzzle.tender-totalPrice(state.puzzle.items);
    if(n!==due){failShop('Chưa đúng tiền thừa. Bé lấy tiền đưa trừ tiền hàng nhé!');return;}
    state.attempts++;stageComplete('Bé tính đúng cả tiền hàng và tiền thừa!');
  }
  function stageComplete(message){
    if(state.busy||state.finished)return;
    state.busy=true;updateStats();gameMessage('Thanh toán thành công! ✨','good');feedback('Giỏi quá!','good');
    renderCart();schedule(()=>showSuccess(message),state.reduceMotion?80:650);
  }
  function renderStage(){
    state.puzzle=state.round[state.stage];state.busy=false;
    if(isNumber)renderNumber();else renderShop();
  }
  function bind(){
    $('logic-panel-toggle').onclick=()=>setPanel($('logic-workspace').classList.contains('sidebar-collapsed'));
    $('logic-sidebar-close').onclick=()=>setPanel(false);
    $('logic-add-profile').onclick=()=>askChange(createProfile);
    $('logic-restart').onclick=()=>askChange(newRound);
    $('logic-hint').onclick=hint;
    $('logic-levels').addEventListener('click',e=>{
      const b=e.target.closest('[data-level]');if(!b||b.dataset.level===state.level||!labels[b.dataset.level])return;
      askChange(()=>{state.level=b.dataset.level;setPref(gameKey+'-level',state.level);newRound();});
    });
    $('logic-player').onchange=e=>{
      const id=e.target.value;e.target.value=state.playerId;if(id===state.playerId)return;
      askChange(async()=>{state.switchingProfile=true;updateStats();try{
        await api('select_profile',{player_id:id});state.playerId=id;setPref('player-id',id);makeProfiles();newRound();notify('Đã chọn hồ sơ bé.');
      }catch(err){notify(err.message);makeProfiles();}finally{state.switchingProfile=false;updateStats();}});
    };
    $('logic-sound').onclick=()=>{state.sound=!state.sound;setPref('sound',state.sound);soundIcon();if(state.sound)sound('tap');};
    $('logic-fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{notify('Không bật được toàn màn hình.');}};
    $('logic-modal-close').onclick=closeModal;
    $('logic-modal').onclick=e=>{if(e.target===$('logic-modal'))closeModal();};
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('logic-modal').hidden)closeModal();});
    if(isNumber){
      $('math-answers').addEventListener('click',e=>{const b=e.target.closest('[data-answer]');if(b)selectNumber(Number(b.dataset.answer));});
    } else {
      $('shop-products').addEventListener('click',e=>{
        const plus=e.target.closest('[data-plus]'),minus=e.target.closest('[data-minus]');
        if(plus)changeQuantity(plus.dataset.plus,1);else if(minus)changeQuantity(minus.dataset.minus,-1);
      });
      $('shop-check').onclick=checkShop;
      $('shop-cart-reset').onclick=()=>{if(state.phase!=='cart'||state.busy)return;state.cart={};renderCart();gameMessage('');};
      $('shop-payment').addEventListener('click',e=>{
        const coin=e.target.closest('[data-coin]'),answer=e.target.closest('[data-change]');
        if(coin)giveCoin(Number(coin.dataset.coin));
        else if(answer)giveChange(Number(answer.dataset.change));
        else if(e.target.closest('#shop-reset-money')&&state.phase==='pay'&&!state.busy){state.paid=0;renderPayment();gameMessage('');}
      });
    }
  }
  function soundIcon(){$('logic-sound').textContent=state.sound?'♫':'♪̸';$('logic-sound').setAttribute('aria-pressed',String(state.sound));}
  async function init(){
    bind();soundIcon();if(!labels[state.level])state.level='easy';
    try {
      const data=await api('bootstrap');state.profiles=data.players;state.playerId=data.player_id;
      const saved=pref('player-id',state.playerId);
      if(saved!==state.playerId&&state.profiles.some(p=>p.id===saved)){
        try{await api('select_profile',{player_id:saved});state.playerId=saved;}catch{}
      }
      makeProfiles();newRound();
    } catch(err) {feedback('Chưa tải được trò chơi. Kiểm tra PHP nhé!','try');notify(err.message);}
  }
  init();
})();
