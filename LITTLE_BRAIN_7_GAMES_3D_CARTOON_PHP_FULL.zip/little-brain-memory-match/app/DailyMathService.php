<?php
declare(strict_types=1);

/**
 * Chia banh cho ban: server-validated five-puzzle daily lessons and flower rewards.
 * The server's calendar uses Asia/Ho_Chi_Minh (set by bootstrap.php).
 * The daily_math JSON document is authoritative; no database required.
 */
final class DailyMathService
{
    private const LESSON_STEPS = 5;
    private const REWARD_DAYS = 5;
    private const REWARD_VND = 10000;
    private const LEVELS = ['easy', 'normal', 'advanced', 'hard'];

    public function __construct(private Storage $storage) {}

    public function status(string $playerId): array
    {
        $this->activePlayer($playerId);
        return $this->storage->transaction(function (Storage $db) use ($playerId): array {
            $this->verifyProfile($db, $playerId);
            $document = $db->read('daily_math');
            return $this->stateFromDocument($document, $playerId);
        });
    }

    public function start(string $playerId, string $level): array
    {
        $this->activePlayer($playerId);
        if (!in_array($level, self::LEVELS, true)) {
            throw new InvalidArgumentException('Cấp độ không hợp lệ.');
        }
        $status = $this->status($playerId);
        if ($status['done_today']) {
            return ['already_done'=>true, 'attendance'=>$status];
        }
        $today = date('Y-m-d');
        $round = $_SESSION['daily_math_round'] ?? null;
        // Preserve a started lesson on refresh. Starting another level resets only this lesson.
        if (!is_array($round) || ($round['player_id'] ?? null) !== $playerId ||
            ($round['date'] ?? null) !== $today || ($round['level'] ?? null) !== $level ||
            ($round['complete'] ?? false) === true) {
            $round = [
                'token'=>bin2hex(random_bytes(16)),
                'player_id'=>$playerId,
                'date'=>$today,
                'level'=>$level,
                'started_at'=>date('c'),
                'index'=>0,
                'attempts'=>0,
                'mistakes'=>0,
                'hints'=>0,
                'tasks'=>$this->makeTasks($level),
                'complete'=>false,
            ];
            $_SESSION['daily_math_round'] = $round;
        }
        return [
            'already_done'=>false,
            'token'=>$round['token'],
            'difficulty'=>$round['level'],
            'step'=>($round['index'] + 1),
            'total_steps'=>self::LESSON_STEPS,
            'attempts'=>$round['attempts'],
            'mistakes'=>$round['mistakes'],
            'hints_used'=>$round['hints'],
            'task'=>$round['tasks'][$round['index']],
            'attendance'=>$status,
        ];
    }

    public function hint(string $playerId, string $token): array
    {
        $round = $this->round($playerId, $token);
        $round['hints'] = min(10000, $round['hints'] + 1);
        $_SESSION['daily_math_round'] = $round;
        return [
            'hints_used'=>$round['hints'],
            'message'=>'Bé hãy chia lần lượt cho từng bạn, mỗi bạn một chiếc. Khi tất cả đều bằng nhau là đúng rồi!',
        ];
    }

    /** The server checks all plate counts, not an answer/correct flag from the browser. */
    public function answer(string $playerId, string $token, mixed $counts): array
    {
        $round = $this->round($playerId, $token);
        $task = $round['tasks'][$round['index']];
        if (!is_array($counts) || !array_is_list($counts) || count($counts) !== $task['friends']) {
            throw new InvalidArgumentException('Số đĩa chưa đúng.');
        }
        $sum = 0;
        foreach ($counts as $c) {
            if (!is_int($c) || $c < 0 || $c > $task['cookies']) {
                throw new InvalidArgumentException('Số bánh trên đĩa không hợp lệ.');
            }
            $sum += $c;
        }
        if ($sum > $task['cookies']) {
            throw new InvalidArgumentException('Bé đang dùng nhiều bánh hơn trong giỏ.');
        }

        $round['attempts']++;
        $each = intdiv($task['cookies'], $task['friends']);
        $correct = $sum === $task['cookies'] && count(array_filter($counts, static fn(int $n): bool => $n === $each)) === $task['friends'];
        if (!$correct) {
            $round['mistakes']++;
            $_SESSION['daily_math_round'] = $round;
            return [
                'correct'=>false,
                'attempts'=>$round['attempts'],
                'mistakes'=>$round['mistakes'],
                'message'=>$sum < $task['cookies'] ? 'Còn bánh trong giỏ, bé chia tiếp cho các bạn nhé!' : 'Hai bên chưa đều nhau. Bé thử chuyển bánh cho bạn đang có ít hơn nhé!',
            ];
        }
        $round['index']++;
        if ($round['index'] < self::LESSON_STEPS) {
            $_SESSION['daily_math_round'] = $round;
            return [
                'correct'=>true,
                'finished'=>false,
                'finished_step'=>$round['index'],
                'attempts'=>$round['attempts'],
                'mistakes'=>$round['mistakes'],
                'step'=>$round['index'] + 1,
                'task'=>$round['tasks'][$round['index']],
            ];
        }

        // The cookie/session only grants access to the lesson; attendance is checked and
        // awarded under Storage's cross-process flock so concurrent requests cannot double-count.
        $done = $this->storage->transaction(function (Storage $db) use ($round): array {
            $playerId = $round['player_id'];
            $this->verifyProfile($db, $playerId);
            $daily = $db->read('daily_math');
            $entry = $daily['players'][$playerId] ?? ['days'=>[], 'rewards'=>[]];
            if (!isset($entry['days'], $entry['rewards']) || !is_array($entry['days']) || !is_array($entry['rewards'])) {
                throw new RuntimeException('Dữ liệu điểm danh của bé không hợp lệ.');
            }
            foreach ($entry['days'] as $day) {
                if (($day['date'] ?? null) === $round['date']) {
                    return ['attendance'=>$this->stateFromDocument($daily, $playerId), 'already_awarded'=>true];
                }
            }
            $history = $db->read('history');
            $saved = null;
            foreach ($history['records'] as $row) {
                if (($row['round_token'] ?? null) === $round['token']) {
                    $saved = $row;
                    break;
                }
            }
            $attempts = $round['attempts'];
            $accuracy = round(self::LESSON_STEPS * 100 / $attempts, 1);
            $stars = $accuracy >= 80 ? 3 : ($accuracy >= 60 ? 2 : 1);
            if ($saved === null) {
                $prefix = 'GAME-' . date('Ymd') . '-';
                $max = 0;
                foreach ($history['records'] as $old) {
                    $gameId = (string) ($old['game_id'] ?? '');
                    if (str_starts_with($gameId, $prefix)) {
                        $suffix = substr($gameId, strlen($prefix));
                        if (ctype_digit($suffix)) $max = max($max, (int) $suffix);
                    }
                }
                $saved = [
                    'game_id'=>sprintf('%s%04d', $prefix, $max + 1),
                    'game_key'=>'daily-math-sharing',
                    'round_token'=>$round['token'],
                    'player_id'=>$playerId,
                    'date'=>$round['date'],
                    'started_at'=>$round['started_at'],
                    'finished_at'=>date('c'),
                    'theme'=>'daily-math-sharing',
                    'difficulty'=>$round['level'],
                    'total_pairs'=>0,
                    'total_steps'=>self::LESSON_STEPS,
                    'attempts'=>$attempts,
                    'mistakes'=>$round['mistakes'],
                    'hints_used'=>$round['hints'],
                    'duration_seconds'=>min(86400, max(0, time()-strtotime($round['started_at']))),
                    'accuracy'=>$accuracy,
                    'stars'=>$stars,
                    'completed'=>true,
                ];
                $history['records'][] = $saved;
                $db->write('history', $history);
            }
            $entry['days'][] = [
                'date'=>$round['date'],
                'completed_at'=>date('c'),
                'round_token'=>$round['token'],
                'level'=>$round['level'],
                'stars'=>$saved['stars'],
            ];
            $dayCount = count($entry['days']);
            if ($dayCount % self::REWARD_DAYS === 0) {
                $cycle = intdiv($dayCount, self::REWARD_DAYS);
                $entry['rewards'][] = [
                    'id'=>sprintf('FLOWER-%s-%03d', $playerId, $cycle),
                    'cycle'=>$cycle,
                    'amount_vnd'=>self::REWARD_VND,
                    'earned_at'=>date('c'),
                    'claimed_at'=>null,
                ];
            }
            $daily['players'][$playerId] = $entry;
            $db->write('daily_math', $daily);
            return ['attendance'=>$this->stateFromDocument($daily, $playerId), 'already_awarded'=>false];
        });
        $round['complete'] = true;
        $_SESSION['daily_math_round'] = $round;
        return [
            'correct'=>true,
            'finished'=>true,
            'finished_step'=>self::LESSON_STEPS,
            'attempts'=>$round['attempts'],
            'mistakes'=>$round['mistakes'],
            'attendance'=>$done['attendance'],
            'already_awarded'=>$done['already_awarded'],
        ];
    }

    /** Parental acknowledgement only; no cash or electronic payment is sent. */
    public function markReward(string $playerId, string $rewardId): array
    {
        $this->activePlayer($playerId);
        if (!preg_match('/^FLOWER-PLAYER\d{3}-\d{3}$/D', $rewardId)) {
            throw new InvalidArgumentException('Mã phần thưởng không hợp lệ.');
        }
        return $this->storage->transaction(function (Storage $db) use ($playerId, $rewardId): array {
            $this->verifyProfile($db, $playerId);
            $doc = $db->read('daily_math');
            $entry = $doc['players'][$playerId] ?? null;
            if (!is_array($entry)) throw new InvalidArgumentException('Không tìm thấy phần thưởng.');
            $found = false;
            foreach ($entry['rewards'] as &$reward) {
                if (($reward['id'] ?? null) === $rewardId) {
                    $found = true;
                    if ($reward['claimed_at'] === null) $reward['claimed_at'] = date('c');
                    break;
                }
            }
            unset($reward);
            if (!$found) throw new InvalidArgumentException('Phần thưởng không tồn tại.');
            $doc['players'][$playerId] = $entry;
            $db->write('daily_math', $doc);
            return $this->stateFromDocument($doc, $playerId);
        });
    }

    private function round(string $playerId, string $token): array
    {
        $this->activePlayer($playerId);
        if (!preg_match('/^[a-f0-9]{32}$/D', $token)) throw new InvalidArgumentException('Phiên học không hợp lệ.');
        $r = $_SESSION['daily_math_round'] ?? null;
        if (!is_array($r) || ($r['token'] ?? null) !== $token || ($r['player_id'] ?? null) !== $playerId ||
            ($r['date'] ?? null) !== date('Y-m-d') || ($r['complete'] ?? false) === true || ($r['index'] ?? 5) >= 5) {
            throw new InvalidArgumentException('Buổi học đã kết thúc hoặc hết hạn. Hãy tải lại trang.');
        }
        return $r;
    }

    private function activePlayer(string $playerId): void
    {
        if ($playerId === '' || $playerId !== ($_SESSION['player_id'] ?? 'PLAYER001')) {
            throw new InvalidArgumentException('Hồ sơ bé không khớp.');
        }
    }

    private function verifyProfile(Storage $db, string $playerId): void
    {
        foreach ($db->read('profiles')['players'] as $player) {
            if (($player['id'] ?? null) === $playerId) return;
        }
        throw new InvalidArgumentException('Không tìm thấy hồ sơ bé.');
    }

    private function stateFromDocument(array $doc, string $playerId): array
    {
        $entry = $doc['players'][$playerId] ?? ['days'=>[], 'rewards'=>[]];
        $days = $entry['days'] ?? [];
        $rewards = $entry['rewards'] ?? [];
        $total = count($days);
        $today = date('Y-m-d');
        $todayDone = false;
        foreach ($days as $day) {
            if (($day['date'] ?? null) === $today) { $todayDone = true; break; }
        }
        $petals = $total % self::REWARD_DAYS;
        if ($petals === 0 && $total > 0) $petals = self::REWARD_DAYS;
        $unclaimed = array_values(array_filter($rewards, static fn(array $r): bool => ($r['claimed_at'] ?? null) === null));
        return [
            'date'=>$today,
            'done_today'=>$todayDone,
            'total_days'=>$total,
            'petals'=>$petals,
            'flower_number'=>intdiv(max(0, $total - 1), self::REWARD_DAYS) + 1,
            'flowers_completed'=>intdiv($total, self::REWARD_DAYS),
            'last_days'=>array_slice($days, -15),
            'rewards'=>$rewards,
            'pending_rewards'=>$unclaimed,
            'reward_vnd'=>self::REWARD_VND,
        ];
    }

    private function makeTasks(string $level): array
    {
        // [number of animal friends, cookie count]; every exercise is solvable.
        $pool = match ($level) {
            'easy'=>[[2,2],[2,4],[2,6],[2,8],[2,10]],
            'normal'=>[[2,6],[3,6],[2,8],[3,9],[2,10],[3,12],[2,12]],
            'advanced'=>[[3,6],[4,8],[3,9],[4,12],[3,12],[4,16],[3,15]],
            'hard'=>[[3,12],[4,12],[3,15],[4,16],[3,18],[4,20],[3,21]],
            default=>throw new InvalidArgumentException('Cấp độ không hợp lệ.'),
        };
        for ($i = count($pool) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$pool[$i], $pool[$j]] = [$pool[$j], $pool[$i]];
        }
        return array_map(static fn(array $task): array => [
            'friends'=>$task[0],
            'cookies'=>$task[1],
        ], array_slice($pool, 0, self::LESSON_STEPS));
    }
}
