<?php
declare(strict_types=1);

final class GameService
{
    private const DIFFICULTIES = ['easy'=>3, 'normal'=>6, 'advanced'=>10, 'hard'=>15];
    private const CHALLENGE_GAMES = ['pattern-logic'=>6, 'robot-coder'=>5, 'balance-puzzle'=>5, 'missing-number'=>5, 'little-shop'=>5];

    public function __construct(private Storage $db, private array $catalog) {}

    public function bootstrap(): array
    {
        $result = $this->db->transaction(function (Storage $db): array {
            $profiles = $db->read('profiles');
            $db->read('history');
            $db->read('achievements');
            $db->read('settings');
            $selected = $_SESSION['player_id'] ?? 'PLAYER001';
            if (!$this->hasPlayer($profiles['players'], $selected)) {
                $selected = $profiles['players'][0]['id'];
                $_SESSION['player_id'] = $selected;
            }
            $themes = [];
            foreach ($this->catalog as $key => $theme) {
                $items = [];
                foreach ($theme['items'] as $slug => $label) {
                    $items[] = [
                        'id'=>$slug,
                        'label'=>$label,
                        'src'=>'assets/images/' . $key . '/' . $slug . '.webp',
                    ];
                }
                $themes[$key] = [
                    'label'=>$theme['label'], 'subtitle'=>$theme['subtitle'],
                    'icon'=>$theme['icon'], 'items'=>$items,
                ];
            }
            return [
                'players'=>$profiles['players'],
                'player_id'=>$selected,
                'themes'=>$themes,
                'difficulties'=>self::DIFFICULTIES,
            ];
        });
        $result['storage_alerts'] = $_SESSION['storage_alerts'] ?? [];
        unset($_SESSION['storage_alerts']);
        return $result;
    }

    public function createProfile(string $name): array
    {
        $name = trim(preg_replace('/\s+/u', ' ', $name) ?? '');
        if ($name === '' || preg_match_all('/./us', $name) > 24) {
            throw new InvalidArgumentException('Tên bé phải từ 1 đến 24 ký tự.');
        }
        if (preg_match('/[<>\x00-\x1F\x7F]/u', $name)) {
            throw new InvalidArgumentException('Tên có ký tự không được phép.');
        }
        $result = $this->db->transaction(function (Storage $db) use ($name): array {
            $doc = $db->read('profiles');
            if (count($doc['players']) >= 15) {
                throw new InvalidArgumentException('Tối đa 15 hồ sơ trên máy này.');
            }
            $max = 0;
            foreach ($doc['players'] as $row) {
                $max = max($max, (int) substr((string) ($row['id'] ?? ''), 6));
            }
            $row = ['id'=>sprintf('PLAYER%03d', $max + 1), 'name'=>$name, 'created_at'=>date('c')];
            $doc['players'][] = $row;
            $db->write('profiles', $doc);
            return $row;
        });
        $_SESSION['player_id'] = $result['id'];
        return $result;
    }

    public function selectProfile(string $playerId): array
    {
        $player = $this->db->transaction(function (Storage $db) use ($playerId): array {
            foreach ($db->read('profiles')['players'] as $row) {
                if ($row['id'] === $playerId) return $row;
            }
            throw new InvalidArgumentException('Không tìm thấy hồ sơ người chơi.');
        });
        $_SESSION['player_id'] = $player['id'];
        unset($_SESSION['round'], $_SESSION['challenge_round']);
        return $player;
    }

    public function start(string $theme, string $difficulty, string $playerId): array
    {
        $this->validateOptions($theme, $difficulty);
        $active = $_SESSION['player_id'] ?? 'PLAYER001';
        if ($playerId !== $active) {
            throw new InvalidArgumentException('Hồ sơ đã thay đổi; vui lòng làm mới trang.');
        }
        $exists = $this->db->transaction(fn(Storage $db): bool => $this->hasPlayer($db->read('profiles')['players'], $active));
        if (!$exists) throw new InvalidArgumentException('Hồ sơ người chơi không hợp lệ.');
        $round = [
            'token'=>bin2hex(random_bytes(16)),
            'player_id'=>$active,
            'theme'=>$theme,
            'difficulty'=>$difficulty,
            'started_at'=>date('c'),
            'started_unix'=>time(),
            'completed'=>false,
        ];
        $_SESSION['round'] = $round;
        return ['round_token'=>$round['token'], 'started_at'=>$round['started_at']];
    }

    public function finish(array $payload): array
    {
        $token = $payload['round_token'] ?? '';
        if (!is_string($token) || !preg_match('/^[a-f0-9]{32}$/', $token)) {
            throw new InvalidArgumentException('Mã ván chơi không hợp lệ.');
        }
        $round = $_SESSION['round'] ?? null;
        if (!is_array($round) || !hash_equals((string) ($round['token'] ?? ''), $token)) {
            throw new InvalidArgumentException('Không có phiên chơi hợp lệ. Hãy bấm Chơi lại.');
        }

        // Values are validated and all ranking fields are recalculated by PHP.
        $pairs = self::DIFFICULTIES[$round['difficulty']];
        $attempts = filter_var($payload['attempts'] ?? null, FILTER_VALIDATE_INT);
        $mistakes = filter_var($payload['mistakes'] ?? null, FILTER_VALIDATE_INT);
        $hints = filter_var($payload['hints_used'] ?? null, FILTER_VALIDATE_INT);
        $duration = filter_var($payload['duration_seconds'] ?? null, FILTER_VALIDATE_INT);
        if ($attempts === false || $mistakes === false || $hints === false || $duration === false ||
            $attempts < $pairs || $attempts > 100000 || $mistakes !== $attempts - $pairs ||
            $hints < 0 || $hints > 10000 || $duration < 0 || $duration > 86400) {
            throw new InvalidArgumentException('Kết quả ván chơi không hợp lệ.');
        }
        $accuracy = round($pairs / $attempts * 100, 1);
        $stars = $accuracy >= 80 ? 3 : ($accuracy >= 60 ? 2 : 1);
        $record = $this->db->transaction(function (Storage $db) use ($round, $token, $pairs, $attempts, $mistakes, $hints, $duration, $accuracy, $stars): array {
            $history = $db->read('history');
            foreach ($history['records'] as $saved) {
                if (($saved['round_token'] ?? '') === $token) return $saved;
            }
            $today = date('Ymd');
            $max = 0;
            foreach ($history['records'] as $old) {
                $id = (string) ($old['game_id'] ?? '');
                if (preg_match('/^GAME-' . $today . '-(\d+)$/', $id, $match)) {
                    $max = max($max, (int) $match[1]);
                }
            }
            $finished = date('c');
            $saved = [
                'game_id'=>sprintf('GAME-%s-%04d', $today, $max + 1),
                'game_key'=>'memory-match',
                'round_token'=>$token, // Kept to make retries idempotent.
                'player_id'=>$round['player_id'],
                'date'=>date('Y-m-d'),
                'started_at'=>$round['started_at'],
                'finished_at'=>$finished,
                'theme'=>$round['theme'],
                'difficulty'=>$round['difficulty'],
                'total_pairs'=>$pairs,
                'attempts'=>$attempts,
                'mistakes'=>$mistakes,
                'hints_used'=>$hints,
                'duration_seconds'=>$duration,
                'accuracy'=>$accuracy,
                'stars'=>$stars,
                'completed'=>true,
            ];
            $history['records'][] = $saved;
            $db->write('history', $history);
            $this->updateAchievements($db, $history['records'], $round['player_id']);
            return $saved;
        });
        $_SESSION['round']['completed'] = true;
        return $record;
    }


    /** A separate token namespace keeps Memory Match's original round protocol intact. */
    public function startChallenge(string $gameKey, string $difficulty, string $playerId): array
    {
        if (!isset(self::CHALLENGE_GAMES[$gameKey], self::DIFFICULTIES[$difficulty])) {
            throw new InvalidArgumentException('Trò chơi hoặc cấp độ không hợp lệ.');
        }
        $this->assertActivePlayer($playerId);
        $exists = $this->db->transaction(fn(Storage $db): bool =>
            $this->hasPlayer($db->read('profiles')['players'], $playerId));
        if (!$exists) throw new InvalidArgumentException('Hồ sơ người chơi không hợp lệ.');

        $round = [
            'token'=>bin2hex(random_bytes(16)),
            'player_id'=>$playerId,
            'game_key'=>$gameKey,
            'difficulty'=>$difficulty,
            'total_steps'=>self::CHALLENGE_GAMES[$gameKey],
            'started_at'=>date('c'),
            'completed'=>false,
        ];
        $_SESSION['challenge_round'] = $round;
        return [
            'round_token'=>$round['token'],
            'started_at'=>$round['started_at'],
            'total_steps'=>$round['total_steps'],
        ];
    }

    /** Score is independently computed by PHP; retries with the same token never duplicate history. */
    public function finishChallenge(array $payload): array
    {
        $token = $payload['round_token'] ?? null;
        if (!is_string($token) || !preg_match('/^[a-f0-9]{32}$/D', $token)) {
            throw new InvalidArgumentException('Mã phiên chơi không hợp lệ.');
        }
        $round = $_SESSION['challenge_round'] ?? null;
        if (!is_array($round) || !is_string($round['token'] ?? null) ||
            !hash_equals($round['token'], $token)) {
            throw new InvalidArgumentException('Phiên chơi đã thay đổi. Hãy bắt đầu ván mới.');
        }
        $steps = self::CHALLENGE_GAMES[$round['game_key']];
        $attempts = filter_var($payload['attempts'] ?? null, FILTER_VALIDATE_INT);
        $mistakes = filter_var($payload['mistakes'] ?? null, FILTER_VALIDATE_INT);
        $hints = filter_var($payload['hints_used'] ?? null, FILTER_VALIDATE_INT);
        $duration = filter_var($payload['duration_seconds'] ?? null, FILTER_VALIDATE_INT);
        if ($attempts === false || $mistakes === false || $hints === false || $duration === false ||
            $attempts < $steps || $attempts > 100000 || $mistakes !== $attempts - $steps ||
            $hints < 0 || $hints > 10000 || $duration < 0 || $duration > 86400) {
            throw new InvalidArgumentException('Kết quả không hợp lệ.');
        }
        $accuracy = round(100 * $steps / $attempts, 1);
        $stars = $accuracy >= 80 ? 3 : ($accuracy >= 60 ? 2 : 1);
        $record = $this->db->transaction(function(Storage $db) use (
            $round, $token, $steps, $attempts, $mistakes, $hints, $duration, $accuracy, $stars
        ): array {
            $history = $db->read('history');
            foreach ($history['records'] as $saved) {
                if (($saved['round_token'] ?? '') === $token) return $saved;
            }
            $today = date('Ymd');
            $sequence = 0;
            foreach ($history['records'] as $saved) {
                if (preg_match('/^GAME-' . $today . '-(\d+)$/D', (string) ($saved['game_id'] ?? ''), $m)) {
                    $sequence = max($sequence, (int) $m[1]);
                }
            }
            $saved = [
                'game_id'=>sprintf('GAME-%s-%04d', $today, $sequence + 1),
                'game_key'=>$round['game_key'],
                'round_token'=>$token,
                'player_id'=>$round['player_id'],
                'date'=>date('Y-m-d'),
                'started_at'=>$round['started_at'],
                'finished_at'=>date('c'),
                'theme'=>$round['game_key'],
                'difficulty'=>$round['difficulty'],
                'total_pairs'=>0,
                'total_steps'=>$steps,
                'attempts'=>$attempts,
                'mistakes'=>$mistakes,
                'hints_used'=>$hints,
                'duration_seconds'=>$duration,
                'accuracy'=>$accuracy,
                'stars'=>$stars,
                'completed'=>true,
            ];
            $history['records'][] = $saved;
            $db->write('history', $history);
            $this->updateAchievements($db, $history['records'], $round['player_id']);
            return $saved;
        });
        $_SESSION['challenge_round']['completed'] = true;
        return $record;
    }

    public function history(string $playerId, int $limit, int $offset): array
    {
        $this->assertActivePlayer($playerId);
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        return $this->db->transaction(function (Storage $db) use ($playerId, $limit, $offset): array {
            $rows = array_values(array_filter($db->read('history')['records'], fn(array $row): bool => ($row['player_id'] ?? '') === $playerId));
            $rows = array_reverse($rows);
            return ['total'=>count($rows), 'records'=>array_slice($rows, $offset, $limit)];
        });
    }

    public function achievements(string $playerId): array
    {
        $this->assertActivePlayer($playerId);
        return $this->db->transaction(function (Storage $db) use ($playerId): array {
            $history = $db->read('history');
            $achievementDoc = $db->read('achievements');
            // Recompute from the source of truth to heal an interrupted previous update.
            $fresh = $this->summarize($history['records'], $playerId);
            if (($achievementDoc['players'][$playerId] ?? null) !== $fresh) {
                $achievementDoc['players'][$playerId] = $fresh;
                $db->write('achievements', $achievementDoc);
            }
            return $fresh;
        });
    }

    private function updateAchievements(Storage $db, array $records, string $playerId): void
    {
        $doc = $db->read('achievements');
        $doc['players'][$playerId] = $this->summarize($records, $playerId);
        $db->write('achievements', $doc);
    }

    private function summarize(array $records, string $playerId): array
    {
        $mine = array_values(array_filter($records, fn(array $r): bool =>
            ($r['player_id'] ?? null) === $playerId && ($r['completed'] ?? false) === true));
        $best = [];
        $logicBest = ['pattern-logic'=>[], 'robot-coder'=>[], 'balance-puzzle'=>[], 'missing-number'=>[], 'little-shop'=>[], 'daily-math-sharing'=>[]];
        $themes = [];
        $levels = [];
        $played = [];
        $stars = 0;
        $accuracyTotal = 0.0;
        foreach ($mine as $r) {
            $stars += (int) ($r['stars'] ?? 0);
            $accuracyTotal += (float) ($r['accuracy'] ?? 0);
            $gameKey = (string) ($r['game_key'] ?? 'memory-match');
            $played[$gameKey] = true;
            $level = (string) ($r['difficulty'] ?? 'normal');
            if ($gameKey === 'memory-match') {
                $themes[$r['theme']] = true;
                $levels[$level] = true;
                $target =& $best;
            } elseif (isset($logicBest[$gameKey])) {
                $target =& $logicBest[$gameKey];
            } else {
                continue;
            }
            if (!isset($target[$level]) || (int) $r['stars'] > (int) $target[$level]['stars'] ||
                ((int) $r['stars'] === (int) $target[$level]['stars'] && (int) $r['attempts'] < (int) $target[$level]['attempts']) ||
                ((int) $r['stars'] === (int) $target[$level]['stars'] && (int) $r['attempts'] === (int) $target[$level]['attempts'] && (int) $r['duration_seconds'] < (int) $target[$level]['duration_seconds'])) {
                $target[$level] = [
                    'stars'=>$r['stars'], 'attempts'=>$r['attempts'],
                    'duration_seconds'=>$r['duration_seconds'], 'accuracy'=>$r['accuracy'],
                    'theme'=>$r['theme'], 'date'=>$r['date'],
                ];
            }
            unset($target);
        }
        $n = count($mine);
        $badges = [];
        if ($n >= 1) $badges[] = 'first_game';
        if ($n >= 5) $badges[] = 'five_games';
        if ($n >= 10) $badges[] = 'ten_games';
        if (array_filter($mine, fn(array $r): bool => (int) ($r['stars'] ?? 0) === 3)) $badges[] = 'three_stars';
        if (count($themes) === count($this->catalog)) $badges[] = 'all_themes';
        if (count($levels) === count(self::DIFFICULTIES)) $badges[] = 'all_levels';
        if (isset($played['pattern-logic'])) $badges[] = 'logic_explorer';
        if (isset($played['robot-coder'])) $badges[] = 'robot_pilot';
        if (isset($played['memory-match'], $played['pattern-logic'], $played['robot-coder'])) $badges[] = 'three_worlds';
        return [
            'total_games'=>$n, 'total_stars'=>$stars,
            'average_accuracy'=>$n ? round($accuracyTotal / $n, 1) : 0,
            'best_by_level'=>(object) $best,
            'best_by_game'=>(object) array_map(static fn(array $levels): object => (object) $levels, $logicBest),
            'badges'=>$badges,
            'last_played'=>$n ? $mine[$n - 1]['date'] : null,
        ];
    }

    private function assertActivePlayer(string $id): void
    {
        if ($id === '' || $id !== ($_SESSION['player_id'] ?? 'PLAYER001')) {
            throw new InvalidArgumentException('Hồ sơ người chơi không khớp.');
        }
    }

    private function validateOptions(string $theme, string $difficulty): void
    {
        if (!isset($this->catalog[$theme], self::DIFFICULTIES[$difficulty])) {
            throw new InvalidArgumentException('Chủ đề hoặc cấp độ không hợp lệ.');
        }
        if (count($this->catalog[$theme]['items']) < self::DIFFICULTIES[$difficulty]) {
            throw new InvalidArgumentException('Không đủ hình cho cấp độ đã chọn.');
        }
    }

    private function hasPlayer(array $players, string $id): bool
    {
        foreach ($players as $p) {
            if ($p['id'] === $id) return true;
        }
        return false;
    }
}
