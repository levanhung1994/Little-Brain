# LITTLE BRAIN – PC EDITION · 7 trò chơi, đồ họa 3D mềm mại (PHP 8.3)

Website giáo dục offline cho trẻ 4–6 tuổi. Chạy bằng PHP 8.3+ / JavaScript / CSS / 3D WebP (SVG được giữ lại làm tài nguyên cũ); **không cần MySQL, SQLite, Internet hoặc EXE**. Tối ưu cho máy tính Windows, màn hình 1024 px trở lên.

## Nâng cấp đồ họa 3D – 14/10/2026

- **Toàn bộ 7 game:** Dùng chung phong cách **3D Cartoon mềm mại**, màu pastel, nút có hiệu ứng nổi khối và bóng đổ nhẹ. Đây là **hình 3D dựng sẵn** chứ không cần engine 3D.
- **Memory Match:** Đổi đủ **75 thẻ của 5 chủ đề** sang WebP chất lượng cao có nền trong suốt. Hình hiển thị lớn, khi ghép đúng hai thẻ vẫn biến mất như phiên bản đang dùng.
- **Robot:** Robot, ngôi sao và đá là 3D; nút điều hướng được làm mới. Giữ nguyên 5 bản đồ / cấp và chức năng xóa từng lệnh.
- **Pattern Logic:** Hình minh họa, các hình khối và các ô đáp án có chiều sâu; quy luật và cách kiểm tra đáp án không đổi.
- **Balance:** Trái cây 3D và cân vàng bóng nổi khối; cân vẫn nghiêng theo trọng lượng.
- **Missing Number:** Khối số, nút đáp án 3D mềm mại; công thức và độ khó không đổi.
- **Little Shop:** Sản phẩm, giỏ, xu và nút thanh toán 3D; cách tính tiền và tiền thừa giữ nguyên.
- **Chia bánh:** Nhân vật và bánh 3D; bông hoa năm cánh có hiệu ứng nổi và vẫn **tô cánh theo dữ liệu điểm danh thực tế** (không biến thành ảnh tĩnh).
- **Kho trò chơi:** 12 ảnh preview WebP riêng biệt phản ánh rõ cách chơi, 7 game đang mở + 5 game dự kiến.
- **Offline hoàn toàn:** Tất cả tài nguyên ở `public/assets/images/`; không dùng CDN hay tài khoản bên ngoài. Các đường dẫn hình cũ SVG vẫn có thể còn nằm trong `assets` để tương thích.
- **Logic không đổi:** Không can thiệp cơ chế tính điểm, màn chơi, lưu JSON, lịch sử hoặc thưởng 10.000đ.

### Nâng cấp từ bản LITTLE BRAIN PHP 7 game hiện tại (khuyên dùng)

1. **Sao lưu thư mục `data/` trước**; dừng cửa sổ đang chạy PHP (`Ctrl + C`).
2. Giải nén `LITTLE_BRAIN_7_GAMES_3D_CARTOON_UPDATE.zip` **ngay trong thư mục gốc dự án hiện tại** (thư mục đang chứa `app/` và `public/`). ZIP UPDATE có các thư mục `app/`, `public/` và README tại cấp đầu, không có lớp thư mục lồng thêm. Chấp nhận ghi đè các file mã nguồn trùng tên.
3. Bản UPDATE **không chứa `data/`**, nên dữ liệu lịch sử và điểm danh hiện tại không bị ghi đè.
4. Khởi động lại PHP và nhấn `Ctrl + F5` để tải CSS, hình mới. Nếu còn dùng ảnh cũ, đóng hẳn tab và mở lại.

**Lưu ý:** Bản UPDATE này xây dựng dựa trên `LITTLE_BRAIN_7_GAMES_MEMORY_MATCH_AN_THE_DUNG_FULL.zip` (đã có 7 game và tính năng ẩn cặp đúng). Không áp lên các phiên bản cũ hơn nếu chưa nâng lên bản 7 game.

## Kho trò chơi

1. **Memory Match** – Tìm hai hình giống nhau (5 chủ đề, 4 cấp độ).
2. **Pattern Logic** – Tìm quy luật (6 câu / ván).
3. **Little Coder** – Bé lập trình Robot (5 bản đồ / cấp độ).
4. **Balance Puzzle** – Cân bằng thông minh (5 bài / ván).
5. **Missing Number** – Tìm số bí mật (cộng trừ trực quan).
6. **Little Shop** – Siêu thị của bé (đếm tiền xu, mua sắm).
7. **Chia bánh cho bạn** – **MỚI:** Bài toán chia đều, bông hoa điểm danh, thưởng 10.000đ khi đủ 5 ngày.

5 game khác đang ở trạng thái **Sắp ra mắt**.

## Chia bánh cho bạn – Toán vui mỗi ngày

- Bé chia bánh cho 2–4 bạn gấu/thỏ/gấu trúc/cáo. Sử dụng **kéo bánh vào đĩa**, hoặc **nhấn vào đĩa** để cho bánh; có thể **lấy lại bánh**, **chia lại** và **xin gợi ý**.
- Có 4 cấp độ Dễ / Vừa / Khá / Khó; mỗi ngày làm **5 bài** với số bánh và số bạn khác nhau. Bài toán ở mức Khó có thể dùng đến 20–21 chiếc bánh.
- Bé có thể trả lời sai rồi thử lại, không bị trừ cánh hoa vì sai. PHP xác minh số bánh đã chia trên từng đĩa.
- **Hoàn thành đủ 5 bài trong một ngày (theo giờ Việt Nam) = 1 cánh hoa**. Không cộng thêm cánh khi làm lại cùng ngày, ngay cả khi gửi request trùng hoặc tải lại trang.
- Bông hoa có 5 cánh pastel, theo dõi riêng cho mỗi hồ sơ bé. **Đủ 5 ngày học khác nhau = thưởng 10.000đ** và xuất hiện thông báo chúc mừng.
- Không yêu cầu 5 ngày liên tiếp. Sau ngày thứ 5, một chu kỳ hoa mới bắt đầu ở ngày học tiếp theo. Phụ huynh có nút **Đã trao 10.000đ** để ghi nhận việc tặng thưởng.
- **Quan trọng:** Đây là ghi nhận phần thưởng từ gia đình, không phải chuyển tiền thật / thanh toán tự động. Nút xác nhận dành cho phụ huynh, chưa có mã PIN riêng.
- Bài đã làm được lưu vào lịch sử chơi chung. Ngày điểm danh và lịch sử thưởng được lưu riêng trong **`data/daily_math.json`** (PHP tự tạo; có khóa ghi và sao lưu `.bak`).
- Các game cũ, công thức tính sao của chúng và dữ liệu trong `data/` được giữ nguyên.

## Cài đặt mới trên Windows

Giải nén ZIP FULL, mở CMD **trong thư mục có `app` và `public`**, rồi chạy:

```bat
php -S 127.0.0.1:8080 -t public public/router.php
```

Mở **http://127.0.0.1:8080** bằng Edge hoặc Chrome. Nếu máy đã thêm PHP 8.3+ vào PATH, có thể nhấp đúp `start-windows.bat`.

Lưu ý: Không chạy lệnh ở `C:\Users\...>` nếu tại đó không có thư mục `public/`.

## Bảo vệ dữ liệu

- Trên Apache/IIS, cấu hình web root **chỉ trỏ đến `public/`**. Thư mục `data/` nằm ngoài web root và phải có quyền ghi cho PHP.
- Kiểm tra `http://127.0.0.1:8080/data/daily_math.json` phải trả **404**.
- Dữ liệu JSON dùng khóa file xuyên tiến trình, ghi tệp tạm và sao lưu trước khi ghi đè.
- Điểm danh mỗi ngày được xác định bởi PHP theo múi giờ `Asia/Ho_Chi_Minh`.
- Người chơi thuộc từng hồ sơ có ngày điểm danh và phần thưởng độc lập.

## Kiểm tra

```bat
php tests/test_game_library.php
php tests/test_daily_math.php
```

Mã nguồn chính cho game Chia bánh:

```text
app/DailyMathService.php
app/Storage.php
app/games.php
public/api/index.php
public/games/daily-math-sharing/index.php
public/assets/js/daily-math.js
public/assets/css/daily-math.css
public/assets/images/daily-math/cookie.webp
public/assets/images/daily-math/flower.webp
public/assets/images/game-previews/daily-math-sharing.webp
```
