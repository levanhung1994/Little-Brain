<?php
declare(strict_types=1);
/** Offline regression tests. Uses ONLY a disposable temporary directory. */
date_default_timezone_set('Asia/Ho_Chi_Minh');
require dirname(__DIR__) . '/app/Storage.php';
require dirname(__DIR__) . '/app/DailyMathService.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function check(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }
$dir = sys_get_temp_dir() . '/little-brain-math-test-' . bin2hex(random_bytes(6));
$store = new Storage($dir);
try {
    $store->transaction(function(Storage $db): void {
        $db->read('daily_math');
        $profiles = $db->read('profiles');
        for ($i=2; $i<=4; $i++) $profiles['players'][] = ['id'=>sprintf('PLAYER%03d',$i),'name'=>'Tester ' . $i,'created_at'=>date('c')];
        $db->write('profiles',$profiles);
        $daily = $db->read('daily_math');
        $prior = [];
        for ($i=4; $i>=1; $i--) $prior[]=['date'=>date('Y-m-d',strtotime("-$i days")),'completed_at'=>date('c'), 'level'=>'easy','stars'=>3];
        $daily['players']=['PLAYER001'=>['days'=>$prior,'rewards'=>[]]];
        $db->write('daily_math',$daily);
    });
    $service = new DailyMathService($store);
    foreach (['easy','normal','advanced','hard'] as $i=>$level) {
        $player = sprintf('PLAYER%03d',$i+1);
        $_SESSION['player_id'] = $player;
        unset($_SESSION['daily_math_round']);
        $start = $service->start($player, $level);
        check(!$start['already_done'] && $start['total_steps']===5,"Invalid start for $level");
        $token = $start['token'];
        $wrong = $service->answer($player,$token,array_fill(0,$start['task']['friends'],0));
        check($wrong['correct']===false && $wrong['mistakes']===1, "Incorrect answer accepted for $level");
        $resume = $service->start($player,$level);
        check($resume['token']===$token && $resume['step']===1,"Lesson did not resume for $level");
        $task = $start['task'];
        for ($n=1; $n<=5; $n++) {
            check($task['cookies'] % $task['friends']===0,"Unfair exercise for $level");
            $each = intdiv($task['cookies'],$task['friends']);
            $result = $service->answer($player,$token,array_fill(0,$task['friends'],$each));
            check($result['correct']===true,"Correct answer rejected for $level");
            if ($n<5) {check($result['finished']===false,"Premature completion $level");$task=$result['task'];}
            else check($result['finished']===true,"Missing completion $level");
        }
        $daily = $service->status($player);
        check($daily['done_today']===true,"No daily attendance for $level");
        check($service->start($player,$level)['already_done']===true,"Duplicate day allowed for $level");
        if ($i===0) {
            check($daily['petals']===5 && $daily['flowers_completed']===1,"Fifth petal failed");
            check(count($daily['pending_rewards'])===1,"No 10k reward");
            check($daily['pending_rewards'][0]['amount_vnd']===10000,"Wrong amount");
            $id = $daily['pending_rewards'][0]['id'];
            $claimed = $service->markReward($player,$id);
            check(count($claimed['pending_rewards'])===0,"Claim failed");
            check(count($service->markReward($player,$id)['pending_rewards'])===0,"Duplicate claim failed");
        } else {
            check($daily['petals']===1 && count($daily['rewards'])===0,"Isolation or reward error $level");
        }
    }
    $records = $store->transaction(fn(Storage $db): array => $db->read('history')['records']);
    check(count($records)===4,"Expected four separate history records");
    echo "PASS: four difficulties, safe lessons, daily petal, five-day reward, parent claim, history and profile isolation.\n";
} finally {
    foreach (glob($dir . '/*') ?: [] as $file) @unlink($file);
    foreach (glob($dir . '/.*') ?: [] as $file) if (is_file($file)) @unlink($file);
    @rmdir($dir);
}
