<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$games = require $root . '/app/games.php';
if (!is_array($games) || count($games) < 2) {
    throw new RuntimeException('Expected the full game library.');
}
$ids = [];
$readyCount = 0;
foreach ($games as $game) {
    $id = $game['id'] ?? '';
    if (!is_string($id) || !preg_match('/^[a-z][a-z0-9-]*$/D', $id) || isset($ids[$id])) {
        throw new RuntimeException('Duplicate or invalid game ID: ' . (string) $id);
    }
    $ids[$id] = true;
    if (!in_array($game['status'] ?? null, ['available', 'coming_soon'], true)) {
        throw new RuntimeException('Unsupported availability state for: ' . $id);
    }
    if (!is_array($game['art'] ?? null) || count($game['art']) !== 2) {
        throw new RuntimeException('Two cover images required for: ' . $id);
    }
    foreach ($game['art'] as $image) {
        if (!is_string($image) || !str_starts_with($image, 'assets/images/') || !is_file($root . '/public/' . $image)) {
            throw new RuntimeException('Missing local cover asset for: ' . $id);
        }
    }
    if ($game['status'] === 'available') {
        $readyCount++;
        if (($game['view'] ?? '') !== 'game' && !preg_match('~^games/[a-z0-9-]+/index\.php$~D', $game['url'] ?? '')) {
            throw new RuntimeException('No safe route for active game: ' . $id);
        }
    }
}
if (!isset($ids['memory-match'], $ids['pattern-logic'], $ids['robot-coder'], $ids['balance-puzzle'], $ids['missing-number'], $ids['little-shop'], $ids['daily-math-sharing']) || $readyCount !== 7) {
    throw new RuntimeException('Expected 7 published games including daily sharing lessons.');
}
echo 'PASS: ' . count($games) . ' games / ' . $readyCount . ' published / all local art and routes valid.' . PHP_EOL;
