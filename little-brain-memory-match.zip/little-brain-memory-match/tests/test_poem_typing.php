<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';
$poems = require dirname(__DIR__) . '/app/poems.php';
if (count($poems) !== 4) throw new RuntimeException('Expected 4 levels.');
$seen = [];
foreach ($poems as $level=>$items) {
    if (count($items) !== 5) throw new RuntimeException('Need 5 unique poems at '.$level);
    foreach ($items as $poem) {
        if (isset($seen[$poem['id']])) throw new RuntimeException('Duplicated poem id.');
        $seen[$poem['id']] = true;
        if (!preg_match('/[\p{L}]/u', $poem['text'])) throw new RuntimeException('Poem text missing.');
        $asset=dirname(__DIR__) . '/public/assets/images/' . $poem['art'];
        if (!is_file($asset)) throw new RuntimeException('Missing poem illustration: '.$asset);
    }
}
$ref = "Bé yêu mẹ.\nMẹ cười rất xinh!";
$extra = "   Bé    yêu   mẹ.   \n\nMẹ    cười rất xinh!   ";
if (PoemTypingService::compareText($ref) !== PoemTypingService::compareText($extra)) throw new RuntimeException('Extra whitespace not ignored.');
foreach (["Bé yêu me.\nMẹ cười rất xinh!", "Bé yêu mẹ\nMẹ cười rất xinh!", "bé yêu mẹ.\nMẹ cười rất xinh!", "Bé yêu mẹ.Mẹ cười rất xinh!"] as $bad) {
    if (PoemTypingService::compareText($ref) === PoemTypingService::compareText($bad)) throw new RuntimeException('Incorrect text accepted.');
}
echo "PASS: 20 unique Vietnamese poems, 4 levels, flexible whitespace, strict accents and punctuation.\n";
