<?php
declare(strict_types=1);
/** Isolated daily mission / reward test; NEVER touches the website's data directory. */
date_default_timezone_set('Asia/Ho_Chi_Minh');
require dirname(__DIR__) . '/app/Storage.php';
require dirname(__DIR__) . '/app/DailyChallengeService.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function ok(bool $b, string $message): void { if (!$b) throw new RuntimeException($message); }
$dir=sys_get_temp_dir().'/lb-challenge-test-'.bin2hex(random_bytes(5));
$db=new Storage($dir);
try {
    $_SESSION['player_id']='PLAYER001';
    $service=new DailyChallengeService($db);
    $today=date('Y-m-d');
    $math=DailyChallengeService::gameForDay($today);
    ok(in_array($math,['missing-number','balance-puzzle','little-shop','daily-math-sharing'],true),'Incorrect rotation');
    ok($math!==DailyChallengeService::gameForDay(date('Y-m-d',strtotime('+1 day'))),'No rotation tomorrow');
    $db->transaction(function(Storage $s) use ($today): void {
        $legacy=$s->read('daily_math');
        $legacy['players']['PLAYER001']=['days'=>[['date'=>'2026-10-01']],
            'rewards'=>[['id'=>'FLOWER-PLAYER001-001','amount_vnd'=>10000,'claimed_at'=>null]]];
        $s->write('daily_math',$legacy);
        $s->read('daily_challenge');
    });
    $first=$service->status('PLAYER001');
    ok($first['petals']===0 && $first['legacy_total_days']===1,'Old attendance was incorrectly imported');
    ok(count($first['legacy_pending_rewards'])===1,'Old reward was lost');
    // Poem only must not count; easy math must not count.
    $db->transaction(function(Storage $s) use ($today,$math): void {
        $history=$s->read('history');
        $history['records'][]=['game_id'=>'GAME-TEST-001','game_key'=>'poem-typing','player_id'=>'PLAYER001',
            'date'=>$today,'finished_at'=>date('c'),'completed'=>true,'difficulty'=>'advanced'];
        $history['records'][]=['game_id'=>'GAME-TEST-002','game_key'=>$math,'player_id'=>'PLAYER001',
            'date'=>$today,'finished_at'=>date('c'),'completed'=>true,'difficulty'=>'easy'];
        $s->write('history',$history);
    });
    $poemOnly=$service->status('PLAYER001');
    ok($poemOnly['poem_done'] && !$poemOnly['math_done'] && !$poemOnly['done_today'],'Easy math counted');
    $db->transaction(function(Storage $s) use ($today): void {
        $doc=$s->read('daily_challenge');
        $prior=[];
        for($i=4;$i>=1;$i--) $prior[]=['date'=>date('Y-m-d',strtotime("-$i days")),'math_game'=>'missing-number',
            'math_game_id'=>'TEST','poem_game_id'=>'TEST','completed_at'=>date('c')];
        $doc['players']['PLAYER001']=['days'=>$prior,'rewards'=>[]];
        $s->write('daily_challenge',$doc);
    });
    $db->transaction(function(Storage $s) use ($today,$math): void {
        $history=$s->read('history');
        $history['records'][]=['game_id'=>'GAME-TEST-003','game_key'=>$math,'player_id'=>'PLAYER001',
            'date'=>$today,'finished_at'=>date('c'),'completed'=>true,'difficulty'=>'advanced'];
        $s->write('history',$history);
    });
    $award=$service->status('PLAYER001');
    ok($award['just_awarded'] && $award['just_reward_earned'] && $award['done_today'] &&
        $award['petals']===5 && $award['flowers_completed']===1,'Fifth petal not issued');
    ok(count($award['pending_rewards'])===1 && $award['pending_rewards'][0]['amount_vnd']===10000,'Reward not issued');
    $again=$service->status('PLAYER001');
    ok(!$again['just_awarded'] && count($again['rewards'])===1 && $again['total_days']===5,'Duplicate attendance / reward');
    $claimed=$service->confirmReward('PLAYER001',$award['pending_rewards'][0]['id']);
    ok(count($claimed['pending_rewards'])===0,'Parent claim failed');
    ok(count($service->confirmReward('PLAYER001',$award['pending_rewards'][0]['id'])['pending_rewards'])===0,'Claim retry not idempotent');
    $_SESSION['player_id']='PLAYER002';
    $db->transaction(function(Storage $s):void{
        $d=$s->read('profiles');$d['players'][]=['id'=>'PLAYER002','name'=>'Bé thứ 2','created_at'=>date('c')];$s->write('profiles',$d);
    });
    $other=$service->status('PLAYER002');
    ok($other['total_days']===0 && !$other['done_today'],'Player progress leaked');
    ok($db->transaction(fn(Storage $s):array=>$s->read('daily_math'))['players']['PLAYER001']['days'][0]['date']==='2026-10-01','Old data modified');
    echo "PASS: rotating math, 2 tasks advanced, no duplicate petals, 5-day reward, claim, old history preserved, player isolation.\n";
} finally {
    foreach (glob($dir.'/*') ?: [] as $f) @unlink($f);
    foreach (glob($dir.'/.*') ?: [] as $f) if(is_file($f))@unlink($f);
    @rmdir($dir);
}
