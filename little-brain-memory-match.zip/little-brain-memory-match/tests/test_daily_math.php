<?php
declare(strict_types=1);
/** Sharing-game unit tests: five puzzles remain replayable, no legacy petal is issued. */
date_default_timezone_set('Asia/Ho_Chi_Minh');
require dirname(__DIR__).'/app/Storage.php';
require dirname(__DIR__).'/app/DailyChallengeService.php';
require dirname(__DIR__).'/app/DailyMathService.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function check(bool $yes, string $message):void {if (!$yes)throw new RuntimeException($message);}
$dir=sys_get_temp_dir().'/lb-sharing-test-'.bin2hex(random_bytes(6));
$db=new Storage($dir);
try {
  $db->transaction(function(Storage $s):void {
    $p=$s->read('profiles');
    for($i=2;$i<=4;$i++)$p['players'][]=['id'=>sprintf('PLAYER%03d',$i),'name'=>'Tester','created_at'=>date('c')];
    $s->write('profiles',$p);
  });
  $svc=new DailyMathService($db);
  foreach(['easy','normal','advanced','hard'] as $n=>$level) {
    $player=sprintf('PLAYER%03d',$n+1);
    $_SESSION['player_id']=$player;
    unset($_SESSION['daily_math_round']);
    $round=$svc->start($player,$level);
    check($round['total_steps']===5 && !$round['already_done'],"Cannot start $level");
    $token=$round['token'];$task=$round['task'];
    check(!$svc->answer($player,$token,array_fill(0,$task['friends'],0))['correct'],'Bad answer accepted');
    check($svc->start($player,$level)['token']===$token,'In-progress lesson lost');
    for($i=1;$i<=5;$i++){
      check($task['cookies']%$task['friends']===0,'Unsolvable puzzle');
      $each=intdiv($task['cookies'],$task['friends']);
      $result=$svc->answer($player,$token,array_fill(0,$task['friends'],$each));
      check($result['correct']===true,'Correct count rejected');
      if($i<5)$task=$result['task'];
      else check($result['finished']===true,'Not finished');
    }
    $attendance=(new DailyChallengeService($db))->status($player);
    check(!$attendance['done_today'] && $attendance['total_days']===0,'Sharing game incorrectly awarded a petal');
    $next=$svc->start($player,$level);
    check($next['token']!==$token,'Replaying the lesson is blocked');
  }
  $history=$db->transaction(fn(Storage $s):array=>$s->read('history')['records']);
  check(count($history)===4,'Expected four saved independent lessons');
  $legacy=$db->transaction(fn(Storage $s):array=>$s->read('daily_math'));
  check(($legacy['players']??[])===[],'Legacy attendance was modified');
  echo "PASS: sharing game 4 difficulties, 5 valid puzzles, replays, history, no obsolete petal, player isolation.\n";
} finally {
  foreach(glob($dir.'/*')?:[] as $f)@unlink($f);
  foreach(glob($dir.'/.*')?:[] as $f)if(is_file($f))@unlink($f);
  @rmdir($dir);
}
