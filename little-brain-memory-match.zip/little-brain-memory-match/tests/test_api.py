"""Simple optional integration test for the PHP JSON API. Run against a disposable install."""
import sys, json, urllib.parse, urllib.request, http.cookiejar, re
BASE = (sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8080').rstrip('/')
jar = http.cookiejar.CookieJar()
client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), urllib.request.ProxyHandler({}))
page = client.open(BASE + '/').read().decode('utf-8')
csrf = re.search(r'name="csrf-token" content="([a-f0-9]+)"',page).group(1)

def api(action, method='GET', body=None, **params):
    url = BASE + '/api/index.php?' + urllib.parse.urlencode({'action':action,**params})
    headers={}
    if body is not None:
        headers={'Content-Type':'application/json','X-CSRF-Token':csrf}
        body=json.dumps(body).encode('utf-8')
    req=urllib.request.Request(url,body,headers,method=method)
    with client.open(req,timeout=5) as response:
        data=json.load(response)
    assert data['ok'],data
    return data['data']

config=api('bootstrap')
assert len(config['themes'])==5
assert all(len(c['items'])>=15 for c in config['themes'].values())
assert config['difficulties']=={'easy':3,'normal':6,'advanced':10,'hard':15}
profile=api('create_profile','POST',{'name':'Bé kiểm thử'})
assert profile['name']=='Bé kiểm thử',profile
selected=api('select_profile','POST',{'player_id':profile['id']})
assert selected['id']==profile['id']
round_data=api('start','POST',{'theme':'animals','difficulty':'normal','player_id':profile['id']})
result={ 'round_token':round_data['round_token'], 'attempts':9, 'mistakes':3, 'hints_used':1, 'duration_seconds':85 }
first=api('finish','POST',result)
second=api('finish','POST',result)
assert first['game_id']==second['game_id'], 'Duplicate submission inserted multiple records.'
assert first['total_pairs']==6 and first['accuracy']==66.7 and first['stars']==2
assert first['started_at'] and first['finished_at']
my_history=api('history',player_id=profile['id'],limit=20,offset=0)
assert my_history['total']==1
ach=api('achievements',player_id=profile['id'])
assert ach['total_games']==1 and ach['total_stars']==2 and 'first_game' in ach['badges']
print('PASS: 5 themes / 75 3D WebP images, 4 levels, profile, saved results, idempotence, history, achievements.')
