<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/Storage.php';
$folder = getenv('LB_TEST_DIR');
if (!$folder || !str_starts_with($folder, sys_get_temp_dir())) {
    fwrite(STDERR, "Set LB_TEST_DIR to a disposable directory under the system temp folder.\n");
    exit(2);
}
$store = new Storage($folder);
$store->transaction(function(Storage $db): void {
    $document = $db->read('history');
    $document['records'][] = ['test_process_id'=>getmypid()];
    usleep(5000);
    $db->write('history', $document);
});
