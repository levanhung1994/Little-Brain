# LITTLE BRAIN · KIDS MODE — Điểm danh 2 nhiệm vụ & chữ lớn (17/10/2026)

**Website PHP 8.3+ với 8 game, ảnh 3D, không MySQL, chạy offline trên PC.**

## Điểm danh mới: 2 nhiệm vụ mức Khá mỗi ngày

1. Vào **Kho game** → **Nhiệm vụ hôm nay**. Một trong bốn game Toán được giao luân phiên theo ngày: **Tìm số bí mật, Cân bằng, Siêu thị, Chia bánh**. Nhấn **Làm toán** sẽ mở thẳng cấp **Khá**.
2. Hoàn thành một ván của đúng game Toán được giao hôm đó ở **cấp Khá** (không phải chỉ đạt nhiều sao).
3. Nhấn **Chép thơ** → gõ đúng một bài thơ **cấp Khá**. Chữ có dấu và dấu câu phải đúng; các dấu cách thừa vẫn được bỏ qua.
4. Hai nhiệm vụ đều hoàn thành **trong cùng ngày theo giờ Việt Nam** → **1 cánh hoa**; tối đa **1 cánh/ngày**. Không bắt buộc 5 ngày liên tiếp. Ngày mới hệ thống tự chọn game Toán tiếp theo.
5. Đủ **5 cánh từ 5 ngày** → thông báo phần thưởng **10.000đ từ mẹ Xoài**. Phụ huynh nhấn **Đã trao thưởng** để ghi nhận (website **không chuyển tiền**). Mỗi chu kỳ 5 ngày tạo tối đa một phần thưởng.

Kết quả được đối chiếu từ lịch sử game đã hoàn thành do PHP lưu. Việc mở game hoặc chọn Khá mà chưa thắng **không được cộng cánh**. Trình duyệt không tự tạo điểm danh hoặc thay đổi số cánh. Khi trang đang mở, tải lại trang để xem tiến độ mới nhất.

### Giữ nguyên dữ liệu cũ

- Lịch sử bông hoa theo quy tắc **Chia bánh** trước đây được **giữ trong `data/daily_math.json`**, nhưng từ bản này không cộng cánh mới theo quy tắc đó nữa. Thưởng trước đây chưa nhận vẫn có thể xem/xác nhận trong **Kho game → Nhiệm vụ hôm nay → Phần thưởng cũ**.
- Điểm danh hai nhiệm vụ mới ghi vào **`data/daily_challenge.json`**; file được PHP tự tạo, có khóa `flock` và bản sao `.bak`, riêng cho từng hồ sơ bé.
- Lịch sử 8 game hiện có (`history.json`), hồ sơ, thành tích không bị chuyển đổi hoặc xoá bỏ.

### Giao diện chữ lớn

Tăng nhẹ kích thước chữ trên thẻ game, tên game, nút chơi, gợi ý, phản hồi đúng/sai, thông báo và phần chép thơ; vẫn tối ưu cho màn hình **1024–1920 px**.

### Cập nhật từ bản 8 game Kids Mode

1. Dừng PHP (`Ctrl + C`) và **sao lưu cả thư mục `data/`**.
2. Giải nén ZIP **UPDATE** vào thư mục website hiện có (thư mục chứa `app/` và `public/`); ghi đè file mã nguồn. **UPDATE không chứa `data/`**.
3. Khởi động lại PHP: `php -S 127.0.0.1:8080 -t public public/router.php`.
4. Mở `http://127.0.0.1:8080` và nhấn `Ctrl + F5` để tải CSS/JavaScript mới.

**Lưu ý:** Nếu trước đây bé đã có 2/5 cánh theo quy tắc chỉ cần chơi Chia bánh, những cánh đó vẫn ở lịch sử cũ nhưng **không tự chuyển sang** chương trình 2 nhiệm vụ mới. Điều này tránh nhận thưởng mới nhầm bằng các ván không đáp ứng điều kiện hiện tại.

### Kiểm thử offline

```bat
php tests/test_daily_challenge.php
php tests/test_daily_math.php
php tests/test_game_library.php
php tests/test_poem_typing.php
```

---

# LITTLE BRAIN – 8 GAMES · TYPING POETRY & VICTORY EFFECTS

**PHP 8.3, Offline, không MySQL.** Phiên bản mới bổ sung **Bé chép thơ** và nâng cấp giao diện chúc mừng cho toàn bộ 8 game. Những phần còn lại kế thừa đúng mã nguồn LITTLE_BRAIN_7_GAMES_3D_CARTOON_PHP_FULL.

## Bé chép thơ – Poem Typing

- Trong **Kho trò chơi**, chọn **Bé chép thơ**. Bé nhìn bài thơ mẫu và gõ lại trong ô bên cạnh bằng bàn phím thật.
- **4 cấp độ**, mỗi cấp độ có **5 đoạn thơ do Little Brain biên soạn** (tổng 20 đoạn), đổi bài không lặp cho đến khi dùng hết 5 bài của cấp độ.
- Khi nhấn **Kiểm tra bài**, PHP tự so sánh nội dung (không tin mỗi JavaScript). **Chỉ thắng khi khớp hoàn toàn chữ, dấu tiếng Việt, chữ hoa/thường và dấu câu.** Các khoảng trắng thừa, xuống dòng khác nhau và khoảng trắng đầu/cuối được bỏ qua.
- **Telex hoặc VNI:** Bé dùng phương pháp gõ tiếng Việt đã cài trên Windows; website nhận chữ có dấu đã gõ, không tự đổi chế độ nhập.
- Có thanh tiến độ các ký tự đúng theo thứ tự, thời gian, lựa chọn cấp độ, hồ sơ người chơi, thông báo khi sai và popup chúc mừng khi đúng.
- Kết quả sau khi PHP xác nhận được lưu một lần duy nhất vào lịch sử JSON. Lịch sử và kỷ lục game mới tách biệt với Memory Match, Robot, Cân bằng, các game cũ.
- Đây là game luyện tập thân thiện cho trẻ 5 tuổi; không đặt giới hạn thời gian và không phạt bé nếu cần sửa nhiều lần.

## Hiệu ứng chiến thắng đồng bộ toàn bộ game

- Chữ chúc mừng **lớn và rõ**, nền pastel, nút lớn, sao lấp lánh, biểu tượng nảy nhẹ và pháo giấy rơi.
- Áp dụng tại màn thắng của Memory Match, Tìm quy luật, Robot, Cân bằng, Tìm số bí mật, Siêu thị, Chia bánh, Bé chép thơ.
- Có hỗ trợ **Reduce Motion** trong Windows / trình duyệt để tắt hiệu ứng chuyển động mạnh.
- Hiệu ứng chỉ là giao diện; **không sửa điểm, luật chơi, số map, điểm danh 5 cánh hoặc logic thưởng 10.000đ** của 7 game cũ.

## Cập nhật bản đang sử dụng (nên dùng)

1. Đang dùng bản **7 game 3D Cartoon PHP**: Dừng máy chủ PHP (`Ctrl + C`).
2. Sao lưu nguyên thư mục `data/` (gồm cả file `daily_math.json`, nếu có).
3. Giải nén **LITTLE_BRAIN_8_GAMES_TYPING_VICTORY_UPDATE.zip** vào thư mục gốc website (nơi có `app/` và `public/`); chấp nhận ghi đè file mã nguồn.
4. **UPDATE không chứa `data/`**, nên lịch sử, hồ sơ và điểm danh hiện có không bị ghi đè.
5. Khởi động lại PHP, mở Edge/Chrome, nhấn `Ctrl + F5`.

## Cài mới bằng bản FULL

```bat
cd /d "C:\Users\TVH00767\Desktop\little-brain-memory-match"
php -S 127.0.0.1:8080 -t public public/router.php
```

Mở `http://127.0.0.1:8080` trên máy tính. Không yêu cầu MySQL / Internet. `data/` nằm ngoài `public/` để không bị đọc trực tiếp qua HTTP.

## File mới / đã thay đổi

- `app/poems.php`, `app/PoemTypingService.php`: Bộ 20 bài thơ và kiểm tra/lưu kết quả ở PHP.
- `app/GameService.php`, `app/bootstrap.php`, `app/games.php`, `public/api/index.php`: Tích hợp hồ sơ, kho game và lịch sử.
- `public/games/poem-typing/index.php`, `public/assets/js/poem-typing.js`, `public/assets/css/poem-typing.css`: Game gõ thơ.
- `public/assets/images/game-previews/poem-typing.webp`: Hình đại diện game.
- `public/assets/css/victory-celebration.css`, `public/assets/js/victory-celebration.js`: Hiệu ứng chiến thắng dùng chung.
- Templates PHP 7 game cũ: chỉ thêm tham chiếu 2 file hiệu ứng chiến thắng.

## Kiểm tra sau khi cập nhật

```bat
php tests/test_game_library.php
php tests/test_daily_math.php
php tests/test_poem_typing.php
```

Các bài kiểm thử mới kiểm tra số bài thơ, quy tắc bỏ qua khoảng trắng thừa, chữ có dấu và dấu câu.

---

# LITTLE BRAIN – PC EDITION · 7 trò chơi, đồ họa 3D mềm mại (PHP 8.3)

Website giáo dục offline cho trẻ 4–6 tuổi. Chạy bằng PHP 8.3+ / JavaScript / CSS / 3D WebP (SVG được giữ lại làm tài nguyên cũ); **không cần MySQL, SQLite, Internet hoặc EXE**. Tối ưu cho máy tính Windows, màn hình 1024 px trở lên.

## Nâng cấp đồ họa 3D – 14/10/2026

- **Toàn bộ 7 game:** Dùng chung phong cách **3D Cartoon mềm mại**, màu pastel, nút có hiệu ứng nổi khối và bóng đổ nhẹ. Đây là **hình 3D dựng sẵn** chứ không cần engine 3D.
- **Memory Match:** Đổi đủ **75 thẻ của 5 chủ đề** sang WebP chất lượng cao có nền trong suốt. Hình hiển thị lớn, khi ghép đúng hai thẻ vẫn biến mất như phiên bản đang dùng.
- **Robot:** Robot, ngôi sao và đá là 3D; nút điều hướng được làm mới. Giữ nguyên 5 bản đồ / cấp và chức năng xóa từng lệnh.
- **Pattern Logic:** Hình minh họa, các hình khối và các ô đáp án có chiều sâu; quy luật và cách kiểm tra đáp án không đổi.
- **Balance:** Trái cây 3D và cân vàng bóng nổi khối; cân vẫn nghiêng theo trọng lượng.
- **Missing Number:** Khối số, nút đáp án 3D mềm mại; công thức và độ khó không đổi.
- **Little Shop:** Sản phẩm, giỏ, xu và nút thanh toán 3D; cách tính tiền và tiền thừa giữ nguyên.
- **Chia bánh:** Nhân vật và bánh 3D; bông hoa năm cánh có hiệu ứng nổi và vẫn **tô cánh theo dữ liệu điểm danh thực tế** (không biến thành ảnh tĩnh).
- **Kho trò chơi:** 12 ảnh preview WebP riêng biệt phản ánh rõ cách chơi, 7 game đang mở + 5 game dự kiến.
- **Offline hoàn toàn:** Tất cả tài nguyên ở `public/assets/images/`; không dùng CDN hay tài khoản bên ngoài. Các đường dẫn hình cũ SVG vẫn có thể còn nằm trong `assets` để tương thích.
- **Logic không đổi:** Không can thiệp cơ chế tính điểm, màn chơi, lưu JSON, lịch sử hoặc thưởng 10.000đ.

### Nâng cấp từ bản LITTLE BRAIN PHP 7 game hiện tại (khuyên dùng)

1. **Sao lưu thư mục `data/` trước**; dừng cửa sổ đang chạy PHP (`Ctrl + C`).
2. Giải nén `LITTLE_BRAIN_7_GAMES_3D_CARTOON_UPDATE.zip` **ngay trong thư mục gốc dự án hiện tại** (thư mục đang chứa `app/` và `public/`). ZIP UPDATE có các thư mục `app/`, `public/` và README tại cấp đầu, không có lớp thư mục lồng thêm. Chấp nhận ghi đè các file mã nguồn trùng tên.
3. Bản UPDATE **không chứa `data/`**, nên dữ liệu lịch sử và điểm danh hiện tại không bị ghi đè.
4. Khởi động lại PHP và nhấn `Ctrl + F5` để tải CSS, hình mới. Nếu còn dùng ảnh cũ, đóng hẳn tab và mở lại.

**Lưu ý:** Bản UPDATE này xây dựng dựa trên `LITTLE_BRAIN_7_GAMES_MEMORY_MATCH_AN_THE_DUNG_FULL.zip` (đã có 7 game và tính năng ẩn cặp đúng). Không áp lên các phiên bản cũ hơn nếu chưa nâng lên bản 7 game.

## Kho trò chơi

1. **Memory Match** – Tìm hai hình giống nhau (5 chủ đề, 4 cấp độ).
2. **Pattern Logic** – Tìm quy luật (6 câu / ván).
3. **Little Coder** – Bé lập trình Robot (5 bản đồ / cấp độ).
4. **Balance Puzzle** – Cân bằng thông minh (5 bài / ván).
5. **Missing Number** – Tìm số bí mật (cộng trừ trực quan).
6. **Little Shop** – Siêu thị của bé (đếm tiền xu, mua sắm).
7. **Chia bánh cho bạn** – **MỚI:** Bài toán chia đều, bông hoa điểm danh, thưởng 10.000đ khi đủ 5 ngày.

5 game khác đang ở trạng thái **Sắp ra mắt**.

## Chia bánh cho bạn – Toán vui mỗi ngày

- Bé chia bánh cho 2–4 bạn gấu/thỏ/gấu trúc/cáo. Sử dụng **kéo bánh vào đĩa**, hoặc **nhấn vào đĩa** để cho bánh; có thể **lấy lại bánh**, **chia lại** và **xin gợi ý**.
- Có 4 cấp độ Dễ / Vừa / Khá / Khó; mỗi ngày làm **5 bài** với số bánh và số bạn khác nhau. Bài toán ở mức Khó có thể dùng đến 20–21 chiếc bánh.
- Bé có thể trả lời sai rồi thử lại, không bị trừ cánh hoa vì sai. PHP xác minh số bánh đã chia trên từng đĩa.
- **Quy tắc cũ (lưu trong lịch sử):** Trước đây 5 bài Chia bánh = 1 cánh hoa; từ 17/10/2026, chương trình mới chỉ cộng cánh sau cả **Toán Khá + Chép thơ Khá** đúng ngày.
- Bông hoa chương trình mới có 5 cánh pastel, theo dõi riêng từng hồ sơ; đủ 5 ngày hoàn thành cả hai nhiệm vụ sẽ có quà từ mẹ Xoài.
- Không yêu cầu 5 ngày liên tiếp. Sau ngày thứ 5, một chu kỳ hoa mới bắt đầu ở ngày học tiếp theo. Phụ huynh có nút **Đã trao 10.000đ** để ghi nhận việc tặng thưởng.
- **Quan trọng:** Đây là ghi nhận phần thưởng từ gia đình, không phải chuyển tiền thật / thanh toán tự động. Nút xác nhận dành cho phụ huynh, chưa có mã PIN riêng.
- Bài đã làm được lưu vào lịch sử chơi chung. `daily_math.json` giữ **điểm danh cũ**; `daily_challenge.json` chứa **điểm danh theo 2 nhiệm vụ** mới (PHP tự tạo và sao lưu).
- Các game cũ, công thức tính sao của chúng và dữ liệu trong `data/` được giữ nguyên.

## Cài đặt mới trên Windows

Giải nén ZIP FULL, mở CMD **trong thư mục có `app` và `public`**, rồi chạy:

```bat
php -S 127.0.0.1:8080 -t public public/router.php
```

Mở **http://127.0.0.1:8080** bằng Edge hoặc Chrome. Nếu máy đã thêm PHP 8.3+ vào PATH, có thể nhấp đúp `start-windows.bat`.

Lưu ý: Không chạy lệnh ở `C:\Users\...>` nếu tại đó không có thư mục `public/`.

## Bảo vệ dữ liệu

- Trên Apache/IIS, cấu hình web root **chỉ trỏ đến `public/`**. Thư mục `data/` nằm ngoài web root và phải có quyền ghi cho PHP.
- Kiểm tra `http://127.0.0.1:8080/data/daily_math.json` phải trả **404**.
- Dữ liệu JSON dùng khóa file xuyên tiến trình, ghi tệp tạm và sao lưu trước khi ghi đè.
- Điểm danh mỗi ngày được xác định bởi PHP theo múi giờ `Asia/Ho_Chi_Minh`.
- Người chơi thuộc từng hồ sơ có ngày điểm danh và phần thưởng độc lập.

## Kiểm tra

```bat
php tests/test_game_library.php
php tests/test_daily_math.php
```

Mã nguồn chính cho game Chia bánh:

```text
app/DailyMathService.php
app/Storage.php
app/games.php
public/api/index.php
public/games/daily-math-sharing/index.php
public/assets/js/daily-math.js
public/assets/css/daily-math.css
public/assets/images/daily-math/cookie.webp
public/assets/images/daily-math/flower.webp
public/assets/images/game-previews/daily-math-sharing.webp
```


## Kids Mode – giao diện PC (17/10/2026)

- Kho game hiển thị ảnh 3D lớn và có bộ lọc **Tất cả / Tư duy / Toán học / Tiếng Việt**; danh sách game sắp ra mắt được thu gọn.
- Giao diện các game thống nhất: quay lại Kho game, xem bàn chơi lớn, mở **Tùy chọn** khi cần.
- Màn chiến thắng dùng phong cách nổi khối, chữ to và hiệu ứng nhẹ; tôn trọng cài đặt giảm chuyển động của hệ điều hành.
- Đây là thay đổi giao diện. Hệ thống lưu JSON, điểm danh, thưởng 10.000đ, và logic 8 game giữ nguyên.
