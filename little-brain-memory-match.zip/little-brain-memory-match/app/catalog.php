<?php
declare(strict_types=1);

return [
    'animals' => [
        'label' => 'Động vật', 'subtitle' => 'Bạn thú dễ thương', 'icon' => 'paw-print',
        'items' => [
            'cat'=>'Mèo','dog'=>'Chó','rabbit'=>'Thỏ','bear'=>'Gấu','panda'=>'Gấu trúc',
            'fox'=>'Cáo','lion'=>'Sư tử','elephant'=>'Voi','monkey'=>'Khỉ','frog'=>'Ếch',
            'pig'=>'Heo','cow'=>'Bò','penguin'=>'Chim cánh cụt','turtle'=>'Rùa','fish'=>'Cá',
        ],
    ],
    'fruits' => [
        'label' => 'Trái cây', 'subtitle' => 'Khu vườn sắc màu', 'icon' => 'apple',
        'items' => [
            'apple'=>'Táo','banana'=>'Chuối','pear'=>'Lê','strawberry'=>'Dâu tây','watermelon'=>'Dưa hấu',
            'orange'=>'Cam','grapes'=>'Nho','pineapple'=>'Dứa','cherry'=>'Anh đào','peach'=>'Đào',
            'mango'=>'Xoài','lemon'=>'Chanh','kiwi'=>'Kiwi','coconut'=>'Dừa','blueberry'=>'Việt quất',
        ],
    ],
    'vehicles' => [
        'label' => 'Phương tiện', 'subtitle' => 'Cùng đi khám phá', 'icon' => 'car-front',
        'items' => [
            'car'=>'Ô tô','bus'=>'Xe buýt','truck'=>'Xe tải','bicycle'=>'Xe đạp','train'=>'Tàu hỏa',
            'airplane'=>'Máy bay','ship'=>'Tàu thủy','rocket'=>'Tên lửa','motorbike'=>'Xe máy','firetruck'=>'Xe cứu hỏa',
            'ambulance'=>'Xe cứu thương','tractor'=>'Máy kéo','helicopter'=>'Trực thăng','submarine'=>'Tàu ngầm','taxi'=>'Taxi',
        ],
    ],
    'objects' => [
        'label' => 'Đồ vật', 'subtitle' => 'Thế giới quanh bé', 'icon' => 'backpack',
        'items' => [
            'book'=>'Quyển sách','pencil'=>'Bút chì','backpack'=>'Ba lô','ball'=>'Quả bóng','umbrella'=>'Ô che mưa',
            'clock'=>'Đồng hồ','cup'=>'Chiếc cốc','chair'=>'Ghế','lamp'=>'Đèn bàn','toothbrush'=>'Bàn chải',
            'hat'=>'Chiếc mũ','key'=>'Chìa khóa','scissors'=>'Cái kéo','shoe'=>'Giày','camera'=>'Máy ảnh',
        ],
    ],
    'shapes' => [
        'label' => 'Hình & màu', 'subtitle' => 'Khám phá hình dạng', 'icon' => 'shapes',
        'items' => [
            'circle'=>'Hình tròn','square'=>'Hình vuông','triangle'=>'Tam giác','star'=>'Ngôi sao','heart'=>'Trái tim',
            'diamond'=>'Hình thoi','oval'=>'Hình bầu dục','rectangle'=>'Chữ nhật','pentagon'=>'Ngũ giác','hexagon'=>'Lục giác',
            'moon'=>'Mặt trăng','sun'=>'Mặt trời','cloud'=>'Đám mây','rainbow'=>'Cầu vồng','flower'=>'Bông hoa',
        ],
    ],
];
