<?php
declare(strict_types=1);
/** Original short poems written for the Little Brain typing game. */
return [
    'easy' => [
        ['id'=>'e01','title'=>'Mèo con','text'=>"Mèo con lim dim\nNgủ bên cửa sổ.",'art'=>'animals/cat.webp'],
        ['id'=>'e02','title'=>'Bé và mẹ','text'=>"Bé yêu mẹ lắm\nMẹ cười thật xinh.",'art'=>'animals/bear.webp'],
        ['id'=>'e03','title'=>'Trăng sáng','text'=>"Trăng tròn trên cao\nSoi vào sân nhỏ.",'art'=>'shapes/moon.webp'],
        ['id'=>'e04','title'=>'Vườn hoa','text'=>"Hoa hồng đang nở\nBướm vàng bay qua.",'art'=>'shapes/flower.webp'],
        ['id'=>'e05','title'=>'Cá nhỏ','text'=>"Cá vàng bơi lội\nTrong hồ nước xanh.",'art'=>'animals/fish.webp'],
    ],
    'normal' => [
        ['id'=>'n01','title'=>'Buổi sáng','text'=>"Mặt trời thức dậy\nNắng ghé vào sân\nChim non ríu rít.",'art'=>'shapes/sun.webp'],
        ['id'=>'n02','title'=>'Bạn thỏ','text'=>"Thỏ con tai trắng\nNhảy giữa vườn hoa\nMời bạn cùng chơi.",'art'=>'animals/rabbit.webp'],
        ['id'=>'n03','title'=>'Đám mây','text'=>"Đám mây trắng muốt\nLững lờ trên cao\nChe nắng cho bé.",'art'=>'shapes/cloud.webp'],
        ['id'=>'n04','title'=>'Chiếc lá','text'=>"Một chiếc lá nhỏ\nTheo gió bay xa\nĐậu bên thềm nhà.",'art'=>'shapes/flower.webp'],
        ['id'=>'n05','title'=>'Vườn quả','text'=>"Quả cam tròn trịa\nQuả táo đỏ tươi\nBé cười vui quá!",'art'=>'fruits/apple.webp'],
    ],
    'advanced' => [
        ['id'=>'a01','title'=>'Ngày vui','text'=>"Sáng nay trời thật đẹp,\nBé bước ra vườn hoa.\nBướm vàng bay theo gió,\nChim hót một bài ca.",'art'=>'shapes/flower.webp'],
        ['id'=>'a02','title'=>'Bạn mèo','text'=>"Mèo con đi rất khẽ,\nQua chiếc ghế màu xanh.\nThấy quả bóng lăn tới,\nMèo chạy nhanh, thật nhanh.",'art'=>'animals/cat.webp'],
        ['id'=>'a03','title'=>'Mưa nhỏ','text'=>"Mưa rơi trên mái ngói,\nTí tách suốt buổi trưa.\nBé ngồi bên cửa sổ,\nĐếm từng hạt mưa rơi.",'art'=>'objects/umbrella.webp'],
        ['id'=>'a04','title'=>'Cầu vồng','text'=>"Sau cơn mưa mùa hạ,\nBầu trời lại trong xanh.\nCầu vồng khoe bảy sắc,\nBé ngắm mãi không rời.",'art'=>'shapes/rainbow.webp'],
        ['id'=>'a05','title'=>'Đi học','text'=>"Ba lô nằm trên ghế,\nBút chì ở trong ngăn.\nBé vui đi đến lớp,\nChào cô với nụ cười.",'art'=>'objects/backpack.webp'],
    ],
    'hard' => [
        ['id'=>'h01','title'=>'Khu vườn của bé','text'=>"Trong khu vườn bé nhỏ,\nCó chú bướm xinh xinh.\nHoa rung rinh trước gió,\nNắng vàng nhảy lung linh.\nBé tưới từng khóm lá,\nMong cây lớn thật nhanh.",'art'=>'shapes/flower.webp'],
        ['id'=>'h02','title'=>'Chuyến tàu vui vẻ','text'=>"Đoàn tàu đi qua núi,\nMang theo tiếng cười giòn.\nQua đồng xanh, suối biếc,\nĐến ga lúc trăng tròn.\nBé vẫy tay chào bạn,\nHẹn gặp lại ngày mai!",'art'=>'vehicles/train.webp'],
        ['id'=>'h03','title'=>'Ngôi nhà yêu thương','text'=>"Nhà em có cửa nhỏ,\nCó giàn hoa trước sân.\nMẹ kể chuyện buổi tối,\nBa hát khúc nhạc ngân.\nEm chúc nhà luôn ấm,\nNhững ngày vui thật gần.",'art'=>'animals/bear.webp'],
        ['id'=>'h04','title'=>'Chú thỏ chăm chỉ','text'=>"Thỏ mang bình tưới nước,\nRa thăm luống cà rốt.\nLá xanh reo khe khẽ,\nĐất thơm sau cơn mưa.\nThỏ cười: Mình cố gắng,\nMai sẽ có mùa vui!",'art'=>'animals/rabbit.webp'],
        ['id'=>'h05','title'=>'Biển xanh','text'=>"Biển xanh như tấm lụa,\nSóng vỗ nhẹ bờ cát.\nChiếc thuyền đi thong thả,\nNghe gió hát ngân nga.\nBé gom từng vỏ ốc,\nMang về tặng cả nhà.",'art'=>'vehicles/ship.webp'],
    ],
];
