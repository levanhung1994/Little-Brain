<?php
declare(strict_types=1);
/** Math modules share the site's original PHP profiles, session and JSON API. */
if (!isset($mathGameKey) || !in_array($mathGameKey, ['missing-number', 'little-shop'], true)) {
    http_response_code(404);
    exit;
}
require_once __DIR__ . '/bootstrap.php';
$isNumber = $mathGameKey === 'missing-number';
$title = $isNumber ? 'Tìm số bí mật' : 'Siêu thị của bé';
$subtitle = $isNumber ? 'Tìm số còn thiếu' : 'Đi chợ cùng bé';
$csrf = htmlspecialchars((string) $_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
$config = json_encode(['gameKey'=>$mathGameKey, 'totalSteps'=>5], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#f6f8ff">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <meta name="description" content="<?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?>, trò chơi toán học Little Brain cho trẻ từ 4 đến 6 tuổi">
  <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?> | LITTLE BRAIN PC</title>
  <link rel="icon" type="image/svg+xml" href="../../assets/images/brand/brain.svg">
  <link rel="stylesheet" href="../../assets/css/logic-games.css?v=1.0.0">
  <link rel="stylesheet" href="../../assets/css/logic-simple.css?v=4.2.0">
  <link rel="stylesheet" href="../../assets/css/math-games.css?v=1.0.0">
  <script id="logic-config" type="application/json"><?= $config ?></script>
  <script src="../../assets/js/math-games.js?v=20261014.1" defer></script>
  <link rel="stylesheet" href="../../assets/css/3d-kids.css?v=20261014.1">
  <link rel="stylesheet" href="../../assets/css/victory-celebration.css?v=1.0.0">
  <script src="../../assets/js/victory-celebration.js?v=1.0.0" defer></script>
  <link rel="stylesheet" href="../../assets/css/kids-mode.css?v=20261017.1">
<link rel="stylesheet" href="../../assets/css/daily-challenge.css?v=20261017.2">
<link rel="stylesheet" href="../../assets/css/kids-readable.css?v=20261017.2">
<script src="../../assets/js/daily-challenge.js?v=20261017.2" defer></script>
</head>
<body class="kids-mode" data-game="<?= $mathGameKey ?>">
<div class="logic-shell">
  <header class="logic-topbar">
    <a href="../../index.php" class="logic-brand" aria-label="Trở về Kho trò chơi">
      <span class="logic-logo"><img src="../../assets/images/brand/brain.webp" alt=""></span>
      <span><b>LITTLE <em>BRAIN</em></b></span>
    </a>
    <nav class="logic-nav"><a href="../../index.php">⌂ &nbsp;Kho trò chơi</a></nav>
    <div class="logic-header-actions">
      <button class="round-action" id="logic-sound" type="button" title="Bật hoặc tắt âm thanh" aria-label="Bật hoặc tắt âm thanh">♫</button>
      <button class="round-action" id="logic-fullscreen" type="button" title="Toàn màn hình" aria-label="Toàn màn hình">⛶</button>
    </div>
  </header>
  <main>
    <div class="logic-page-head"><h1><?= $title ?></h1><button type="button" class="logic-panel-toggle" id="logic-panel-toggle" aria-controls="logic-sidebar" aria-expanded="false">⚙ &nbsp; Tùy chọn</button></div>
    <div class="logic-workspace sidebar-collapsed" id="logic-workspace">
      <aside class="logic-sidebar logic-panel" id="logic-sidebar">
        <div class="panel-head"><span class="head-mark">⚙</span><h2>Tùy chọn</h2><button type="button" class="logic-sidebar-close" id="logic-sidebar-close" aria-label="Đóng bảng tùy chọn">×</button></div>
        <label class="logic-field-label" for="logic-player">BÉ ĐANG CHƠI</label>
        <div class="logic-profile-control"><span class="profile-emoji">☺</span><select id="logic-player"><option>Đang tải...</option></select><button type="button" id="logic-add-profile" title="Tạo hồ sơ mới" aria-label="Thêm hồ sơ bé">＋</button></div>
        <div class="logic-section-label">◈ &nbsp; Chọn cấp độ</div>
        <div class="logic-levels" id="logic-levels">
          <button data-level="easy" type="button" class="active"><b>Dễ</b><small>★</small></button>
          <button data-level="normal" type="button"><b>Vừa</b><small>★★</small></button>
          <button data-level="advanced" type="button"><b>Khá</b><small>★★★</small></button>
          <button data-level="hard" type="button"><b>Khó</b><small>★★★★</small></button>
        </div>
        <button class="logic-main-button" id="logic-restart" type="button">↻ &nbsp; Chơi ván mới</button>
        <button class="logic-soft-button" id="logic-hint" type="button">☀ &nbsp; Gợi ý cho bé</button>
      </aside>
      <section class="logic-playarea logic-panel" aria-label="Bàn chơi <?= $title ?>">
        <div class="logic-play-header"><h2><?= $subtitle ?></h2><span class="logic-level-tag" id="logic-level-tag">✦ Dễ</span></div>
        <div class="logic-stats" aria-live="off">
          <div class="logic-stat stat-sky"><span class="stat-graphic">✦</span><div><strong id="logic-progress-stat">0/5</strong><small><?= $isNumber?'Câu đúng':'Đơn đã mua' ?></small></div></div>
          <div class="logic-stat stat-lilac"><span class="stat-graphic">◎</span><div><strong id="logic-attempts">0</strong><small>Lượt trả lời</small></div></div>
          <div class="logic-stat stat-peach"><span class="stat-graphic">◷</span><div><strong id="logic-time">00:00</strong><small>Thời gian</small></div></div>
          <div class="logic-stat stat-lemon"><span class="stat-graphic">★</span><div><strong id="logic-stars">☆☆☆</strong><small>Ngôi sao</small></div></div>
        </div>
        <div class="logic-progress-line"><div id="logic-step-dots" class="logic-step-dots"></div><span id="logic-stage-label">Bài 1 / 5</span></div>
        <?php if ($isNumber): ?>
          <div class="math-number-area" id="number-area">
            <div class="math-task-heading"><span class="math-task-pill">Bài <b id="math-number-index">1</b> / 5</span><span>Tìm số đang ẩn nhé!</span></div>
            <div class="math-number-board">
              <div class="math-board-decoration math-decoration-left" aria-hidden="true">✦</div>
              <div class="math-board-decoration math-decoration-right" aria-hidden="true">✧</div>
              <div class="math-board-caption">SỐ NÀO THAY DẤU HỎI?</div>
              <div id="math-equation" class="math-equation" aria-live="polite"></div>
              <div id="math-visual" class="math-visual" aria-label="Hình minh họa con số"></div>
            </div>
            <div class="math-answer-heading">Chọn đáp án đúng</div>
            <div class="math-answer-grid" id="math-answers" role="group" aria-label="Chọn một số"></div>
            <div class="math-inline-feedback" id="math-inline-feedback" role="status" aria-live="polite"></div>
          </div>
        <?php else: ?>
          <div class="shop-game-area" id="shop-area">
            <div class="shop-task-banner"><div class="shop-task-head"><span class="math-task-pill">Đơn <b id="math-shop-index">1</b> / 5</span><b>Hôm nay bé mua gì?</b></div><div id="shop-list" class="shop-shopping-list" aria-label="Danh sách cần mua"></div></div>
            <div class="shop-workspace">
              <section class="shop-shelf" aria-label="Quầy trái cây"><div class="shop-area-heading"><span>🍎 &nbsp;Quầy trái cây</span><small>Bấm + để cho vào giỏ</small></div><div class="shop-products" id="shop-products"></div></section>
              <section class="shop-cart" aria-label="Giỏ hàng và thanh toán"><div class="shop-area-heading"><span>🛒 &nbsp;Giỏ hàng</span><button class="shop-cart-reset" id="shop-cart-reset" type="button">Xóa giỏ</button></div><div id="shop-cart-lines" class="shop-cart-lines"></div><div class="shop-total"><span>Tổng tiền</span><strong id="shop-total">0 xu</strong></div><div id="shop-payment" class="shop-payment"></div><button class="shop-primary-button" type="button" id="shop-check">Kiểm tra giỏ →</button><div class="shop-message" id="shop-message" role="status" aria-live="polite"></div></section>
            </div>
          </div>
        <?php endif; ?>
        <div id="logic-feedback" class="logic-feedback" role="status" aria-live="polite">Bé bắt đầu khi đã sẵn sàng nhé! ✨</div>
      </section>
    </div>
  </main>
</div>
<div class="logic-device-notice"><img src="../../assets/images/brand/brain.webp" alt="" width="85"><h2>Little Brain · Phiên bản máy tính</h2><p>Vui lòng mở website trên máy tính hoặc laptop để chơi.</p></div>
<div class="logic-modal-backdrop" id="logic-modal" hidden><div class="logic-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="logic-modal-title"><button type="button" class="logic-modal-close" id="logic-modal-close" aria-label="Đóng">×</button><div id="logic-modal-body"></div></div></div>
<div class="logic-toast" id="logic-toast" role="status" aria-live="polite" hidden></div>
</body>
</html>
