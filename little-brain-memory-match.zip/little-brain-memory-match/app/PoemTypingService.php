<?php
declare(strict_types=1);

/** One-poem sessions. The server checks the exact Vietnamese Unicode text. */
final class PoemTypingService
{
    public function __construct(private Storage $db, private GameService $games) {}

    private function currentPlayer(string $playerId): void
    {
        if ($playerId === '' || !hash_equals((string)($_SESSION['player_id'] ?? 'PLAYER001'), $playerId)) {
            throw new InvalidArgumentException('Hồ sơ bé đã thay đổi. Hãy tải lại trò chơi.');
        }
    }

    /** Collapse any runs of whitespace, retaining punctuation, case and diacritics. */
    public static function compareText(string $text): string
    {
        if (class_exists('Normalizer')) {
            $text = Normalizer::normalize($text, Normalizer::FORM_C) ?: $text;
        }
        return trim((string) preg_replace('/[\s\p{Z}\x{FEFF}]+/u', ' ', $text));
    }

    public function start(string $playerId, string $difficulty): array
    {
        $this->currentPlayer($playerId);
        $poems = require __DIR__ . '/poems.php';
        if (!isset($poems[$difficulty]) || !in_array($difficulty, ['easy','normal','advanced','hard'], true)) {
            throw new InvalidArgumentException('Cấp độ không hợp lệ.');
        }
        $exists = $this->db->transaction(function (Storage $db) use ($playerId): bool {
            foreach ($db->read('profiles')['players'] as $player) {
                if ($player['id'] === $playerId) return true;
            }
            return false;
        });
        if (!$exists) throw new InvalidArgumentException('Không tìm thấy hồ sơ bé.');

        $all = array_column($poems[$difficulty], 'id');
        $prior = $_SESSION['poem_seen'][$playerId][$difficulty] ?? [];
        $remaining = array_values(array_diff($all, $prior));
        if (!$remaining) {
            // A new round of five: avoid repeating the previous poem immediately.
            $remaining = array_values(array_diff($all, [end($prior)]));
            $prior = [];
        }
        $chosen = $remaining[random_int(0, count($remaining)-1)];
        $poem = null;
        foreach ($poems[$difficulty] as $p) if ($p['id'] === $chosen) { $poem = $p; break; }
        if ($poem === null) throw new RuntimeException('Không tìm thấy bài thơ.');
        $prior[] = $chosen;
        $_SESSION['poem_seen'][$playerId][$difficulty] = $prior;
        $token = bin2hex(random_bytes(16));
        $_SESSION['poem_round'] = [
            'token'=>$token, 'player_id'=>$playerId, 'difficulty'=>$difficulty,
            'poem_id'=>$poem['id'], 'poem_text'=>$poem['text'], 'poem_title'=>$poem['title'],
            'started_at'=>date('c'), 'started_unix'=>time(), 'checks'=>0,
            'completed'=>false,
        ];
        return [
            'round_token'=>$token, 'id'=>$poem['id'], 'title'=>$poem['title'],
            'text'=>$poem['text'], 'art'=>'../../assets/images/'.$poem['art'],
            'number'=>count($prior), 'total_poems'=>count($poems[$difficulty]),
            'difficulty'=>$difficulty,
        ];
    }

    public function check(string $playerId, string $token, string $typed): array
    {
        $this->currentPlayer($playerId);
        $round = $_SESSION['poem_round'] ?? null;
        if (!is_array($round) || !preg_match('/^[0-9a-f]{32}$/D', $token)
            || !hash_equals((string)($round['token'] ?? ''), $token)
            || ($round['player_id'] ?? null) !== $playerId) {
            throw new InvalidArgumentException('Ván thơ đã thay đổi. Hãy chọn một bài mới.');
        }
        if ($round['completed'] === true) {
            return ['matched'=>true, 'record'=>$round['record']];
        }
        if ($typed === '' || strlen($typed) > 5000 || !preg_match('//u', $typed)) {
            throw new InvalidArgumentException('Bé hãy gõ đoạn thơ bằng tiếng Việt trước khi kiểm tra.');
        }
        $expected = self::compareText($round['poem_text']);
        $actual = self::compareText($typed);
        if ($actual !== $expected) {
            $_SESSION['poem_round']['checks']++;
            return [
                'matched'=>false,
                'checks'=>$_SESSION['poem_round']['checks'],
                'message'=>'Chưa giống hoàn toàn. Bé xem lại chữ, dấu tiếng Việt và dấu câu nhé!',
            ];
        }
        $elapsed = max(1, min(86400, time() - (int)$round['started_unix']));
        // No time pressure or penalty for editing a poem; complete means 100% correct.
        $record = $this->games->saveTypingWin(
            $round['token'], $playerId, $round['difficulty'], $round['poem_id'],
            $round['poem_title'], $round['started_at'], $elapsed,
            (int)$round['checks'] + 1
        );
        $_SESSION['poem_round']['completed'] = true;
        $_SESSION['poem_round']['record'] = $record;
        return ['matched'=>true,'record'=>$record];
    }
}
