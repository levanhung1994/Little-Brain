<?php
declare(strict_types=1);
/** Balance Puzzle standalone layout; intentionally separate from existing game code. */
if (!isset($logicGameKey) || !in_array($logicGameKey, ['balance-puzzle'], true)) {
    http_response_code(404);
    exit;
}
require_once __DIR__ . '/bootstrap.php';
$gameName = html_entity_decode('C&#226;n b&#7857;ng th&#244;ng minh', ENT_QUOTES, 'UTF-8');
$gameEnglish = 'BALANCE PUZZLE';
$description = '';
$steps = 5;
$csrf = htmlspecialchars((string) $_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
$jsConfig = json_encode(['gameKey'=>$logicGameKey, 'totalSteps'=>$steps], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#f6f8ff">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <title><?= $gameName ?> | LITTLE BRAIN PC</title>
  <link rel="icon" type="image/svg+xml" href="../../assets/images/brand/brain.svg">
  <link rel="stylesheet" href="../../assets/css/logic-games.css?v=1.0.0">
  <link rel="stylesheet" href="../../assets/css/logic-simple.css?v=4.2.0">
  <link rel="stylesheet" href="../../assets/css/balance-game.css?v=1.0.0">
  <script id="logic-config" type="application/json"><?= $jsConfig ?></script>
  <script src="../../assets/js/balance-game.js?v=20261014.1" defer></script>
  <link rel="stylesheet" href="../../assets/css/3d-kids.css?v=20261014.1">
  <link rel="stylesheet" href="../../assets/css/victory-celebration.css?v=1.0.0">
  <script src="../../assets/js/victory-celebration.js?v=1.0.0" defer></script>
  <link rel="stylesheet" href="../../assets/css/kids-mode.css?v=20261017.1">
<link rel="stylesheet" href="../../assets/css/daily-challenge.css?v=20261017.2">
<link rel="stylesheet" href="../../assets/css/kids-readable.css?v=20261017.2">
<script src="../../assets/js/daily-challenge.js?v=20261017.2" defer></script>
</head>
<body class="kids-mode" data-game="<?= $logicGameKey ?>">
<div class="logic-shell">
  <header class="logic-topbar">
    <a href="../../index.php" class="logic-brand" aria-label="Về kho trò chơi Little Brain"><span class="logic-logo"><img src="../../assets/images/brand/brain.webp" alt="" /></span><span><b>LITTLE <em>BRAIN</em></b></span></a>
    <nav class="logic-nav" aria-label="Điều hướng trò chơi"><a href="../../index.php">← <span>Kho game</span></a></nav>
    <div class="logic-header-actions"><button class="round-action" id="logic-sound" type="button" title="Bật / tắt âm thanh" aria-label="Bật hoặc tắt âm thanh">♫</button><button class="round-action" id="logic-fullscreen" type="button" title="Toàn màn hình" aria-label="Toàn màn hình">⛶</button></div>
  </header>
  <main>
    <div class="logic-page-head"><h1><?= $gameName ?></h1><button type="button" class="logic-panel-toggle" id="logic-panel-toggle" aria-controls="logic-sidebar" aria-expanded="false">⚙ &nbsp; Tùy chọn</button></div>
    <div class="logic-workspace sidebar-collapsed" id="logic-workspace">
      <aside class="logic-sidebar logic-panel" id="logic-sidebar">
        <div class="panel-head"><span class="head-mark">⚙</span><div><h2>Tùy chọn</h2></div><button type="button" class="logic-sidebar-close" id="logic-sidebar-close" aria-label="Thu gọn bảng điều khiển" title="Thu gọn">×</button></div>
        <label class="logic-field-label" for="logic-player">BÉ ĐANG CHƠI</label>
        <div class="logic-profile-control"><span class="profile-emoji">☺</span><select id="logic-player" aria-label="Chọn hồ sơ bé"><option>Đang tải...</option></select><button type="button" id="logic-add-profile" title="Thêm hồ sơ bé" aria-label="Thêm hồ sơ bé">＋</button></div>
        <div class="logic-section-label">◈ &nbsp; Chọn cấp độ</div>
        <div class="logic-levels" id="logic-levels">
          <button data-level="easy" type="button" class="active"><b>Dễ</b><small>★</small></button>
          <button data-level="normal" type="button"><b>Vừa</b><small>★★</small></button>
          <button data-level="advanced" type="button"><b>Khá</b><small>★★★</small></button>
          <button data-level="hard" type="button"><b>Khó</b><small>★★★★</small></button>
        </div>
        <button class="logic-main-button" id="logic-restart" type="button">↻ &nbsp; Chơi ván mới</button>
        <button class="logic-soft-button" id="logic-hint" type="button">☀ &nbsp; Gợi ý cho bé</button>
      </aside>
      <section class="logic-playarea logic-panel" aria-label="Bàn chơi <?= $gameName ?>">
        <div class="logic-play-header"><div><h2>C&#226;n cho hai b&#234;n b&#7857;ng nhau</h2></div><span class="logic-level-tag" id="logic-level-tag">✦ Cấp độ Dễ</span></div>
        <div class="logic-stats" aria-live="off">
          <div class="logic-stat stat-sky"><span class="stat-graphic">✦</span><div><strong id="logic-progress-stat">0/<?= $steps ?></strong><small>B&#224;i c&#226;n xong</small></div></div>
          <div class="logic-stat stat-lilac"><span class="stat-graphic">◎</span><div><strong id="logic-attempts">0</strong><small>L&#432;&#7907;t ch&#7885;n</small></div></div>
          <div class="logic-stat stat-peach"><span class="stat-graphic">◷</span><div><strong id="logic-time">00:00</strong><small>Thời gian</small></div></div>
          <div class="logic-stat stat-lemon"><span class="stat-graphic">★</span><div><strong id="logic-stars">☆☆☆</strong><small>Ngôi sao</small></div></div>
        </div>
        <div class="logic-progress-line"><div id="logic-step-dots" class="logic-step-dots"></div><span id="logic-stage-label">B&#224;i 1 / <?= $steps ?></span></div>

        <div id="balance-area" class="balance-game-area">
          <div class="balance-taskline"><span class="balance-pill">B&#224;i <b id="balance-question-number">1</b> / 5</span><span id="balance-task-name">Ch&#7885;n nh&#243;m qu&#7843; c&#242;n thi&#7871;u</span></div>
          <div class="balance-guide" id="balance-guide" aria-label="B&#7843;ng tr&#7885;ng l&#432;&#7907;ng"></div>
          <div class="balance-scene">
            <div class="balance-scene-flag"><span class="balance-sparkle">&#10022;</span> C&#226;n n&#224;o!</div>
            <svg id="balance-scale" class="balance-scale" viewBox="0 0 900 415" role="img" aria-label="C&#226;n &#273;&#242;n, &#273;&#297;a b&#234;n tr&#225;i v&#224; b&#234;n ph&#7843;i" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="balance-metal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff6cf"/><stop offset=".18" stop-color="#ffe69b"/><stop offset=".48" stop-color="#f1ba52"/><stop offset=".72" stop-color="#d89434"/><stop offset="1" stop-color="#fff0bc"/></linearGradient>
                <linearGradient id="balance-bowl" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff6d3"/><stop offset=".35" stop-color="#ffdf89"/><stop offset="1" stop-color="#e6a450"/></linearGradient>
              </defs>
              <ellipse cx="450" cy="389" rx="130" ry="15" fill="#a5b3df" opacity=".17"/>
              <path d="M447 128 L432 354 Q449 368 469 354 L453 128Z" fill="url(#balance-metal)"/>
              <path d="M400 359 Q450 344 500 359 L526 384 H374Z" fill="url(#balance-metal)"/>
              <path d="M384 382 H516" stroke="#cb8d2b" stroke-width="8" stroke-linecap="round"/>
              <g id="balance-moving" style="transform-origin:450px 132px">
                <rect x="128" y="119" width="644" height="25" rx="12" fill="url(#balance-metal)"/>
                <circle cx="180" cy="131" r="13" fill="#fff0bb" stroke="#d3a042" stroke-width="5"/>
                <circle cx="720" cy="131" r="13" fill="#fff0bb" stroke="#d3a042" stroke-width="5"/>
                <path d="M180 140 L112 289 M180 140 L248 289 M720 140 L652 289 M720 140 L788 289" stroke="#b99a63" stroke-width="5" stroke-linecap="round"/>
                <g id="balance-left-fruits"></g>
                <g id="balance-right-fruits"></g>
                <path d="M98 284 Q180 335 262 284 L250 306 Q180 345 110 306Z" fill="url(#balance-bowl)" stroke="#e2a54c" stroke-width="3"/>
                <path d="M638 284 Q720 335 802 284 L790 306 Q720 345 650 306Z" fill="url(#balance-bowl)" stroke="#e2a54c" stroke-width="3"/>
              </g>
              <circle cx="450" cy="132" r="23" fill="#fff8d9" stroke="#dba845" stroke-width="9"/>
              <circle cx="450" cy="132" r="7" fill="#fbc270"/>
            </svg>
            <div class="balance-plate-labels"><span>B&#234;n tr&#225;i</span><span>B&#234;n ph&#7843;i <b>+ ?</b></span></div>
          </div>
          <div class="balance-answer-line"><b>Ch&#7885;n nh&#243;m qu&#7843; &#273;&#7875; th&#234;m v&#224;o b&#234;n ph&#7843;i</b><span id="balance-choice-count">4 l&#7921;a ch&#7885;n</span></div>
          <div id="balance-options" class="balance-options" role="group" aria-label="C&#225;c nh&#243;m qu&#7843; &#273;&#7875; ch&#7885;n"></div>
          <div id="balance-inline-feedback" class="balance-inline-feedback" role="status" aria-live="polite"></div>
        </div>

        <div id="logic-feedback" class="logic-feedback" role="status" aria-live="polite">Bé bắt đầu khi đã sẵn sàng nhé! ✨</div>
              </section>
    </div>
  </main>
  <footer class="logic-footer"><span><b>LITTLE BRAIN</b> · Khám phá và phát triển tư duy mỗi ngày</span><span>Made with ♥ for little explorers</span></footer>
</div>
<div class="logic-device-notice"><img src="../../assets/images/brand/brain.webp" alt="" width="85"><h2>Little Brain · Phiên bản máy tính</h2><p>Hãy mở website trên PC hoặc laptop có màn hình đủ rộng để bé chơi nhé!</p></div>
<div class="logic-modal-backdrop" id="logic-modal" hidden><div class="logic-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="logic-modal-title"><button type="button" class="logic-modal-close" id="logic-modal-close" aria-label="Đóng">×</button><div id="logic-modal-body"></div></div></div>
<div class="logic-toast" id="logic-toast" role="status" aria-live="polite" hidden></div>
</body>
</html>
