<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Ho_Chi_Minh');

if (session_status() !== PHP_SESSION_ACTIVE) {
    if (PHP_SAPI !== 'cli') {
        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Strict');
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            ini_set('session.cookie_secure', '1');
        }
    }
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}

require_once __DIR__ . '/Storage.php';
require_once __DIR__ . '/GameService.php';
require_once __DIR__ . '/DailyMathService.php';
require_once __DIR__ . '/PoemTypingService.php';
require_once __DIR__ . '/DailyChallengeService.php';

function storage(): Storage
{
    static $instance = null;
    if ($instance === null) {
        $instance = new Storage(dirname(__DIR__) . '/data');
    }
    return $instance;
}

function catalog(): array
{
    static $data = null;
    return $data ??= require __DIR__ . '/catalog.php';
}

function service(): GameService
{
    static $instance = null;
    return $instance ??= new GameService(storage(), catalog());
}

function daily_math(): DailyMathService
{
    static $instance = null;
    return $instance ??= new DailyMathService(storage());
}

function poem_typing(): PoemTypingService
{
    static $instance = null;
    return $instance ??= new PoemTypingService(storage(), service());
}

function daily_challenge(): DailyChallengeService
{
    static $instance = null;
    return $instance ??= new DailyChallengeService(storage());
}
