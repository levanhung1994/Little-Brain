<?php
declare(strict_types=1);

/**
 * New (2026-10) two-task, five-petal attendance program.
 * The old daily_math.json is deliberately untouched: previous rewards/history are archived.
 * History records are authoritative, and changes are serialized under Storage::transaction().
 */
final class DailyChallengeService
{
    private const GAMES = [
        'missing-number' => ['name' => 'Tìm số bí mật', 'url' => 'games/missing-number/index.php'],
        'balance-puzzle' => ['name' => 'Cân bằng thông minh', 'url' => 'games/balance-puzzle/index.php'],
        'little-shop' => ['name' => 'Siêu thị của bé', 'url' => 'games/little-shop/index.php'],
        'daily-math-sharing' => ['name' => 'Chia bánh cho bạn', 'url' => 'games/daily-math-sharing/index.php'],
    ];
    private const REWARD_DAYS = 5;
    private const AMOUNT_VND = 10000;

    public function __construct(private Storage $storage) {}

    public static function gameForDay(string $date): string
    {
        $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $date, new DateTimeZone('Asia/Ho_Chi_Minh'));
        if ($dt === false || $dt->format('Y-m-d') !== $date) {
            throw new InvalidArgumentException('Ngày điểm danh không hợp lệ.');
        }
        $start = new DateTimeImmutable('2026-10-17 00:00:00', new DateTimeZone('Asia/Ho_Chi_Minh'));
        $delta = (int)$start->diff($dt)->format('%r%a');
        $games = array_keys(self::GAMES);
        $index = (($delta % count($games)) + count($games)) % count($games);
        return $games[$index];
    }

    public function status(string $playerId): array
    {
        $this->assertActivePlayer($playerId);
        return $this->storage->transaction(function (Storage $db) use ($playerId): array {
            $this->verifyProfile($db, $playerId);
            $doc = $db->read('daily_challenge');
            $entry = $doc['players'][$playerId] ?? ['days'=>[], 'rewards'=>[]];
            $this->validateEntry($entry);
            $today = date('Y-m-d');
            $selected = self::gameForDay($today);
            $history = $db->read('history');
            $mathRecord = null;
            $poemRecord = null;
            foreach ($history['records'] as $record) {
                if (($record['player_id'] ?? null) !== $playerId || ($record['completed'] ?? false) !== true ||
                    ($record['difficulty'] ?? null) !== 'advanced' || ($record['date'] ?? null) !== $today ||
                    substr((string)($record['finished_at'] ?? ''), 0, 10) !== $today) {
                    continue;
                }
                if (($record['game_key'] ?? null) === $selected && $mathRecord === null) $mathRecord = $record;
                if (($record['game_key'] ?? null) === 'poem-typing' && $poemRecord === null) $poemRecord = $record;
            }
            $todayAlreadyRecorded = false;
            foreach ($entry['days'] as $day) {
                if (($day['date'] ?? null) === $today) { $todayAlreadyRecorded = true; break; }
            }
            $justAwarded = false;
            $justReward = false;
            if (!$todayAlreadyRecorded && $mathRecord !== null && $poemRecord !== null) {
                $entry['days'][] = [
                    'date'=>$today,
                    'math_game'=>$selected,
                    'math_game_id'=>$mathRecord['game_id'],
                    'poem_game_id'=>$poemRecord['game_id'],
                    'completed_at'=>date('c'),
                ];
                $justAwarded = true;
                if (count($entry['days']) % self::REWARD_DAYS === 0) {
                    $cycle = intdiv(count($entry['days']), self::REWARD_DAYS);
                    $entry['rewards'][] = [
                        'id'=>sprintf('CHALLENGE-%s-%03d', $playerId, $cycle),
                        'cycle'=>$cycle,
                        'amount_vnd'=>self::AMOUNT_VND,
                        'sender'=>'Mẹ Xoài',
                        'earned_at'=>date('c'),
                        'claimed_at'=>null,
                    ];
                    $justReward = true;
                }
                $doc['players'][$playerId] = $entry;
                $db->write('daily_challenge', $doc);
            }
            $legacy = $db->read('daily_math');
            $archive = $legacy['players'][$playerId] ?? ['days'=>[], 'rewards'=>[]];
            return $this->makeStatus($entry, $archive, $today, $selected, $mathRecord !== null,
                $poemRecord !== null, $justAwarded, $justReward);
        });
    }

    public function confirmReward(string $playerId, string $id): array
    {
        $this->assertActivePlayer($playerId);
        if (!preg_match('/^CHALLENGE-PLAYER[0-9]{3}-[0-9]{3}$/D', $id)) {
            throw new InvalidArgumentException('Mã phần thưởng không hợp lệ.');
        }
        $this->storage->transaction(function (Storage $db) use ($playerId, $id): void {
            $this->verifyProfile($db, $playerId);
            $doc = $db->read('daily_challenge');
            $entry = $doc['players'][$playerId] ?? ['days'=>[], 'rewards'=>[]];
            $this->validateEntry($entry);
            $found = false;
            foreach ($entry['rewards'] as &$reward) {
                if (($reward['id'] ?? '') === $id) {
                    $found = true;
                    if (($reward['claimed_at'] ?? null) === null) $reward['claimed_at'] = date('c');
                    break;
                }
            }
            unset($reward);
            if (!$found) throw new InvalidArgumentException('Không tìm thấy phần thưởng của bé.');
            $doc['players'][$playerId] = $entry;
            $db->write('daily_challenge', $doc);
        });
        return $this->status($playerId);
    }

    private function makeStatus(array $entry, array $archive, string $today, string $mathGame,
        bool $mathDone, bool $poemDone, bool $justAwarded, bool $justReward): array
    {
        $days = $entry['days'];
        $rewards = $entry['rewards'];
        $total = count($days);
        $petals = $total % self::REWARD_DAYS;
        if ($petals === 0 && $total > 0) $petals = self::REWARD_DAYS;
        $todayDone = false;
        foreach ($days as $day) {
            if (($day['date'] ?? null) === $today) { $todayDone = true; break; }
        }
        $pending = array_values(array_filter($rewards,
            static fn(array $r): bool => ($r['claimed_at'] ?? null) === null));
        $archiveRewards = is_array($archive['rewards'] ?? null) ? $archive['rewards'] : [];
        return [
            'date'=>$today,
            'math_game'=>$mathGame,
            'math_name'=>self::GAMES[$mathGame]['name'],
            'math_url'=>self::GAMES[$mathGame]['url'] . '?difficulty=advanced&daily=1',
            'poem_url'=>'games/poem-typing/index.php?difficulty=advanced&daily=1',
            'required_level'=>'advanced',
            'math_done'=>$mathDone || $todayDone,
            'poem_done'=>$poemDone || $todayDone,
            'done_today'=>$todayDone,
            'just_awarded'=>$justAwarded,
            'just_reward_earned'=>$justReward,
            'total_days'=>$total,
            'petals'=>$petals,
            'flowers_completed'=>intdiv($total, self::REWARD_DAYS),
            'flower_number'=>intdiv(max(0, $total-1), self::REWARD_DAYS)+1,
            'last_days'=>array_slice($days,-15),
            'rewards'=>$rewards,
            'pending_rewards'=>$pending,
            'reward_vnd'=>self::AMOUNT_VND,
            'sender'=>'Mẹ Xoài',
            'legacy_total_days'=>count(is_array($archive['days'] ?? null) ? $archive['days'] : []),
            'legacy_pending_rewards'=>array_values(array_filter($archiveRewards,
                static fn(array $r): bool => ($r['claimed_at'] ?? null) === null)),
        ];
    }

    private function assertActivePlayer(string $playerId): void
    {
        if ($playerId === '' || $playerId !== ($_SESSION['player_id'] ?? 'PLAYER001')) {
            throw new InvalidArgumentException('Hồ sơ bé không khớp.');
        }
    }

    private function verifyProfile(Storage $db, string $playerId): void
    {
        foreach ($db->read('profiles')['players'] as $profile) {
            if (($profile['id'] ?? null) === $playerId) return;
        }
        throw new InvalidArgumentException('Không tìm thấy hồ sơ bé.');
    }

    private function validateEntry(array $entry): void
    {
        if (!isset($entry['days'], $entry['rewards']) || !is_array($entry['days']) ||
            !array_is_list($entry['days']) || !is_array($entry['rewards']) || !array_is_list($entry['rewards'])) {
            throw new RuntimeException('Lịch sử bông hoa mới không hợp lệ.');
        }
    }
}
