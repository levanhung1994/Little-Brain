<?php
declare(strict_types=1);
/** Shared standalone layout for reasoning games (kept outside the web root). */
if (!isset($logicGameKey) || !in_array($logicGameKey, ['pattern-logic', 'robot-coder'], true)) {
    http_response_code(404);
    exit;
}
require_once __DIR__ . '/bootstrap.php';
$isPattern = $logicGameKey === 'pattern-logic';
$gameName = $isPattern ? 'Tìm quy luật' : 'Bé lập trình Robot';
$gameEnglish = $isPattern ? 'PATTERN LOGIC' : 'LITTLE CODER';
$description = $isPattern
    ? 'Nhìn thật kỹ những hình ảnh xinh xắn, tìm ra quy luật và chọn hình còn thiếu!'
    : 'Chọn mũi tên theo thứ tự, lập trình cho robot đi qua mê cung để nhận ngôi sao!';
$steps = $isPattern ? 6 : 5;
$csrf = htmlspecialchars((string) $_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
$jsConfig = json_encode(['gameKey'=>$logicGameKey, 'totalSteps'=>$steps], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#f6f8ff">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <title><?= $gameName ?> | LITTLE BRAIN PC</title>
  <link rel="icon" type="image/svg+xml" href="../../assets/images/brand/brain.svg">
  <link rel="stylesheet" href="../../assets/css/logic-games.css?v=1.0.0">
  <link rel="stylesheet" href="../../assets/css/logic-simple.css?v=4.2.0">
  <script id="logic-config" type="application/json"><?= $jsConfig ?></script>
  <script src="../../assets/js/logic-games.js?v=20261014.1" defer></script>
  <link rel="stylesheet" href="../../assets/css/3d-kids.css?v=20261014.1">
  <link rel="stylesheet" href="../../assets/css/victory-celebration.css?v=1.0.0">
  <script src="../../assets/js/victory-celebration.js?v=1.0.0" defer></script>
  <link rel="stylesheet" href="../../assets/css/kids-mode.css?v=20261017.1">
<link rel="stylesheet" href="../../assets/css/daily-challenge.css?v=20261017.2">
<link rel="stylesheet" href="../../assets/css/kids-readable.css?v=20261017.2">
<script src="../../assets/js/daily-challenge.js?v=20261017.2" defer></script>
</head>
<body class="kids-mode" data-game="<?= $logicGameKey ?>">
<div class="logic-shell">
  <header class="logic-topbar">
    <a href="../../index.php" class="logic-brand" aria-label="Về kho trò chơi Little Brain"><span class="logic-logo"><img src="../../assets/images/brand/brain.webp" alt="" /></span><span><b>LITTLE <em>BRAIN</em></b></span></a>
    <nav class="logic-nav" aria-label="Điều hướng trò chơi"><a href="../../index.php">← <span>Kho game</span></a></nav>
    <div class="logic-header-actions"><button class="round-action" id="logic-sound" type="button" title="Bật / tắt âm thanh" aria-label="Bật hoặc tắt âm thanh">♫</button><button class="round-action" id="logic-fullscreen" type="button" title="Toàn màn hình" aria-label="Toàn màn hình">⛶</button></div>
  </header>
  <main>
    <div class="logic-page-head"><h1><?= $gameName ?></h1><button type="button" class="logic-panel-toggle" id="logic-panel-toggle" aria-controls="logic-sidebar" aria-expanded="false">⚙ &nbsp; Tùy chọn</button></div>
    <div class="logic-workspace sidebar-collapsed" id="logic-workspace">
      <aside class="logic-sidebar logic-panel" id="logic-sidebar">
        <div class="panel-head"><span class="head-mark">⚙</span><div><h2>Tùy chọn</h2></div><button type="button" class="logic-sidebar-close" id="logic-sidebar-close" aria-label="Thu gọn bảng điều khiển" title="Thu gọn">×</button></div>
        <label class="logic-field-label" for="logic-player">BÉ ĐANG CHƠI</label>
        <div class="logic-profile-control"><span class="profile-emoji">☺</span><select id="logic-player" aria-label="Chọn hồ sơ bé"><option>Đang tải...</option></select><button type="button" id="logic-add-profile" title="Thêm hồ sơ bé" aria-label="Thêm hồ sơ bé">＋</button></div>
        <div class="logic-section-label">◈ &nbsp; Chọn cấp độ</div>
        <div class="logic-levels" id="logic-levels">
          <button data-level="easy" type="button" class="active"><b>Dễ</b><small>★</small></button>
          <button data-level="normal" type="button"><b>Vừa</b><small>★★</small></button>
          <button data-level="advanced" type="button"><b>Khá</b><small>★★★</small></button>
          <button data-level="hard" type="button"><b>Khó</b><small>★★★★</small></button>
        </div>
        <button class="logic-main-button" id="logic-restart" type="button">↻ &nbsp; Chơi ván mới</button>
        <button class="logic-soft-button" id="logic-hint" type="button">☀ &nbsp; Gợi ý cho bé</button>
      </aside>
      <section class="logic-playarea logic-panel" aria-label="Bàn chơi <?= $gameName ?>">
        <div class="logic-play-header"><div><h2><?= $isPattern ? 'Chọn hình còn thiếu' : 'Đưa Robot đến ngôi sao' ?></h2></div><span class="logic-level-tag" id="logic-level-tag">✦ Cấp độ Dễ</span></div>
        <div class="logic-stats" aria-live="off">
          <div class="logic-stat stat-sky"><span class="stat-graphic">✦</span><div><strong id="logic-progress-stat">0/<?= $steps ?></strong><small><?= $isPattern ? 'Câu hoàn thành' : 'Bản đồ xong' ?></small></div></div>
          <div class="logic-stat stat-lilac"><span class="stat-graphic">◎</span><div><strong id="logic-attempts">0</strong><small><?= $isPattern ? 'Lượt chọn' : 'Lượt chạy' ?></small></div></div>
          <div class="logic-stat stat-peach"><span class="stat-graphic">◷</span><div><strong id="logic-time">00:00</strong><small>Thời gian</small></div></div>
          <div class="logic-stat stat-lemon"><span class="stat-graphic">★</span><div><strong id="logic-stars">☆☆☆</strong><small>Ngôi sao</small></div></div>
        </div>
        <div class="logic-progress-line"><div id="logic-step-dots" class="logic-step-dots"></div><span id="logic-stage-label"><?= $isPattern ? 'Câu' : 'Bản đồ' ?> 1 / <?= $steps ?></span></div>
        <?php if ($isPattern): ?>
        <div id="pattern-area" class="pattern-game-area">
          <div class="pattern-question-heading"><span class="pattern-detective">🔍</span><div><b id="pattern-prompt">Quan sát thật kỹ...</b><span id="pattern-subtitle">Chọn hình đúng.</span></div></div>
          <div id="pattern-sequence" class="pattern-sequence" aria-label="Dãy hình chứa một ô cần điền"></div>
          <div class="answer-heading"><span>Chọn đáp án</span></div>
          <div id="pattern-options" class="pattern-options" aria-label="Bốn đáp án"></div>
        </div>
        <?php else: ?>
        <div class="robot-game-area">
          <div class="robot-mission-heading"><div><b id="robot-prompt">Robot đang chờ lệnh...</b></div><span id="robot-map-size" class="robot-map-tag">4 × 4 ô</span></div>
          <div class="robot-game-main"><div class="robot-map-wrap"><div class="robot-map" id="robot-map" aria-label="Bản đồ robot"></div><div class="robot-map-legend"><span>🤖 Bắt đầu</span><span>⭐ Đích đến</span><span>🪨 Chướng ngại</span></div></div><div class="robot-command-panel"><div class="robot-command-heading"><b>Chọn hướng đi</b></div><div class="robot-arrows" role="group" aria-label="Các nút điều khiển Robot">
                  <button type="button" class="robot-direction" data-command="U" aria-label="Thêm bước đi lên" title="Đi lên"><span class="arrow-glyph" aria-hidden="true">↑</span><small>Lên</small></button>
                  <button type="button" class="robot-direction" data-command="L" aria-label="Thêm bước sang trái" title="Sang trái"><span class="arrow-glyph" aria-hidden="true">←</span><small>Trái</small></button>
                  <span class="robot-pad-center" aria-hidden="true"><img src="../../assets/images/robot/robot.webp" alt=""></span>
                  <button type="button" class="robot-direction" data-command="R" aria-label="Thêm bước sang phải" title="Sang phải"><span class="arrow-glyph" aria-hidden="true">→</span><small>Phải</small></button>
                  <button type="button" class="robot-direction" data-command="D" aria-label="Thêm bước đi xuống" title="Đi xuống"><span class="arrow-glyph" aria-hidden="true">↓</span><small>Xuống</small></button>
                </div><div class="robot-command-heading robot-command-step"><b>Các bước di chuyển</b><small id="robot-command-count">0 lệnh</small></div><div id="robot-queue" class="robot-queue" aria-label="Danh sách lệnh"><span class="robot-queue-empty">Chọn mũi tên để bắt đầu...</span></div><div class="robot-tools"><button type="button" id="robot-undo">↶ Xóa 1 lệnh</button><button type="button" id="robot-clear">⌫ Xóa hết</button></div><button type="button" class="robot-run-button" id="robot-run">▶ Chạy thử</button><div id="robot-hint-message" class="robot-hint-message" aria-live="polite">💡 Mẹo: Dùng ít bước đi và tránh đá nhé!</div></div></div>
        </div>
        <?php endif; ?>
        <div id="logic-feedback" class="logic-feedback" role="status" aria-live="polite">Bé bắt đầu khi đã sẵn sàng nhé! ✨</div>
              </section>
    </div>
  </main>
  <footer class="logic-footer"><span><b>LITTLE BRAIN</b> · Khám phá và phát triển tư duy mỗi ngày</span><span>Made with ♥ for little explorers</span></footer>
</div>
<div class="logic-device-notice"><img src="../../assets/images/brand/brain.webp" alt="" width="85"><h2>Little Brain · Phiên bản máy tính</h2><p>Hãy mở website trên PC hoặc laptop có màn hình đủ rộng để bé chơi nhé!</p></div>
<div class="logic-modal-backdrop" id="logic-modal" hidden><div class="logic-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="logic-modal-title"><button type="button" class="logic-modal-close" id="logic-modal-close" aria-label="Đóng">×</button><div id="logic-modal-body"></div></div></div>
<div class="logic-toast" id="logic-toast" role="status" aria-live="polite" hidden></div>
</body>
</html>
