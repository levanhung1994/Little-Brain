<?php
declare(strict_types=1);

/**
 * A JSON-document store protected by a single cross-process flock mutex.
 * Reads, read-modify-write operations and backups share the same mutex.
 */
final class Storage
{
    private string $directory;

    public function __construct(string $directory)
    {
        $this->directory = rtrim($directory, DIRECTORY_SEPARATOR);
        if (!is_dir($this->directory) && !@mkdir($this->directory, 0700, true) && !is_dir($this->directory)) {
            throw new RuntimeException('Không thể tạo thư mục lưu dữ liệu.');
        }
        if (!is_writable($this->directory)) {
            throw new RuntimeException('Thư mục lưu dữ liệu không có quyền ghi.');
        }
    }

    /** @template T @param callable(self):T $callback @return T */
    public function transaction(callable $callback): mixed
    {
        $path = $this->directory . DIRECTORY_SEPARATOR . '.storage.lock';
        $handle = @fopen($path, 'c+b');
        if ($handle === false) {
            throw new RuntimeException('Không mở được khóa lưu trữ.');
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('Không khóa được dữ liệu.');
            }
            try {
                return $callback($this);
            } finally {
                flock($handle, LOCK_UN);
            }
        } finally {
            fclose($handle);
        }
    }

    /** Call only inside transaction(). */
    public function read(string $name): array
    {
        $path = $this->path($name);
        $defaults = self::defaults($name);
        if (!file_exists($path)) {
            $this->write($name, $defaults);
            return $defaults;
        }
        $raw = @file_get_contents($path);
        if ($raw === false) {
            throw new RuntimeException('Không thể đọc ' . $name . '.json.');
        }
        $data = $this->decodeDocument($name, $raw);
        if ($data !== null) {
            return $data;
        }

        // Preserve the original corrupted bytes before attempting any repair.
        $corruptName = $path . '.corrupt-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3));
        if (!@copy($path, $corruptName)) {
            throw new RuntimeException('Dữ liệu lỗi, không thể tạo bản sao dự phòng của ' . $name . '.json.');
        }
        $backup = $path . '.bak';
        if (is_file($backup)) {
            $backupRaw = @file_get_contents($backup);
            $recovered = $backupRaw !== false ? $this->decodeDocument($name, $backupRaw) : null;
            if ($recovered !== null) {
                $this->write($name, $recovered, false);
                error_log('[Little Brain] ' . $name . '.json bị lỗi; đã giữ bản gốc tại ' . basename($corruptName) . ' và phục hồi từ .bak.');
                if (session_status() === PHP_SESSION_ACTIVE) {
                    $_SESSION['storage_alerts'][] = 'Dữ liệu ' . $name . '.json từng bị lỗi và đã phục hồi từ bản sao lưu. Bản lỗi được giữ lại để kiểm tra.';
                }
                return $recovered;
            }
        }
        throw new RuntimeException('File ' . $name . '.json không hợp lệ. Đã giữ bản lỗi tại ' . basename($corruptName) . '; cần khôi phục từ bản sao lưu.');
    }

    /** Call only inside transaction(). */
    public function write(string $name, array $value, bool $backupExisting = true): void
    {
        if (!$this->shapeIsValid($name, $value)) {
            throw new InvalidArgumentException('Cấu trúc dữ liệu ' . $name . ' không hợp lệ.');
        }
        $path = $this->path($name);
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR) . "\n";
        $temp = $path . '.tmp-' . bin2hex(random_bytes(6));
        try {
            $out = @fopen($temp, 'xb');
            if ($out === false) {
                throw new RuntimeException('Không tạo được tệp tạm trong thư mục data.');
            }
            try {
                $bytes = 0;
                $length = strlen($json);
                while ($bytes < $length) {
                    $written = fwrite($out, substr($json, $bytes));
                    if ($written === false || $written === 0) {
                        throw new RuntimeException('Lỗi ghi tệp JSON.');
                    }
                    $bytes += $written;
                }
                fflush($out);
                if (function_exists('fsync')) {
                    @fsync($out);
                }
            } finally {
                fclose($out);
            }

            if ($backupExisting && is_file($path)) {
                $previous = @file_get_contents($path);
                // Never replace a valid backup with damaged bytes.
                if ($previous === false || $this->decodeDocument($name, $previous) === null) {
                    throw new RuntimeException('Tệp dữ liệu cũ bị lỗi; từ chối ghi đè.');
                }
                if (!@copy($path, $path . '.bak')) {
                    throw new RuntimeException('Không sao lưu được ' . $name . '.json.');
                }
            }
            if (!@rename($temp, $path)) {
                // Windows may not atomically replace an existing target.
                // All application reads still use the same exclusive mutex.
                if (!@copy($temp, $path)) {
                    throw new RuntimeException('Không cập nhật được ' . $name . '.json.');
                }
            }
        } finally {
            if (is_file($temp)) {
                @unlink($temp);
            }
        }
    }

    public static function defaults(string $name): array
    {
        return match ($name) {
            'history' => ['version'=>1, 'records'=>[]],
            'profiles' => ['version'=>1, 'players'=>[
                ['id'=>'PLAYER001', 'name'=>'Bé yêu', 'created_at'=>date('c')],
            ]],
            'achievements' => ['version'=>1, 'players'=>[]],
            'settings' => ['version'=>1, 'sound_default'=>true, 'app_name'=>'Little Brain'],
            'daily_math' => ['version'=>1, 'players'=>[]],
            'daily_challenge' => ['version'=>1, 'players'=>[]],
            default => throw new InvalidArgumentException('Tên tệp dữ liệu không hợp lệ.'),
        };
    }

    private function shapeIsValid(string $name, mixed $value): bool
    {
        if (!is_array($value) || ($value['version'] ?? null) !== 1) {
            return false;
        }
        return match ($name) {
            'history' => isset($value['records']) && is_array($value['records']) && array_is_list($value['records'])
                && $this->allArrayEntries($value['records']),
            'profiles' => isset($value['players']) && is_array($value['players']) && array_is_list($value['players'])
                && $this->allArrayEntries($value['players']),
            'achievements' => isset($value['players']) && is_array($value['players']) &&
                ($value['players'] === [] || !array_is_list($value['players'])),
            'settings' => isset($value['sound_default'], $value['app_name']) && is_bool($value['sound_default']) && is_string($value['app_name']),
            'daily_math', 'daily_challenge' => isset($value['players']) && is_array($value['players']) &&
                ($value['players'] === [] || !array_is_list($value['players'])),
            default => false,
        };
    }

    private function allArrayEntries(array $items): bool
    {
        foreach ($items as $item) {
            if (!is_array($item)) return false;
        }
        return true;
    }

    private function decodeDocument(string $name, string $json): ?array
    {
        try {
            $value = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            return null;
        }
        return $this->shapeIsValid($name, $value) ? $value : null;
    }

    private function path(string $name): string
    {
        self::defaults($name); // Whitelist, never allow user-provided filenames.
        return $this->directory . DIRECTORY_SEPARATOR . $name . '.json';
    }
}
