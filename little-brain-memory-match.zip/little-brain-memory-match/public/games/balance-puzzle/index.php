<?php
declare(strict_types=1);
$logicGameKey = 'balance-puzzle';
require dirname(__DIR__, 3) . '/app/balance-game-template.php';
