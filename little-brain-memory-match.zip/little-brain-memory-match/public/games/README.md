# Mô-đun game của LITTLE BRAIN

Các mô-đun có thể chơi hiện nay:

- `pattern-logic/index.php` – Tìm quy luật.
- `robot-coder/index.php` – Bé lập trình Robot.
- `balance-puzzle/index.php` – Cân bằng thông minh.

Giao diện và logic chung: `app/logic-game-template.php`, `public/assets/css/logic-games.css`, `public/assets/js/logic-games.js`.

Lưu tiến độ vào cùng API PHP và lịch sử JSON với Memory Match; game sắp ra mắt chỉ được mở khi có đường dẫn mô-đun hợp lệ và trạng thái `available` tại `app/games.php`. Không sửa logic Memory Match khi thêm mô-đun.

Balance Puzzle is an isolated module with its own PHP template, CSS, and JS; it shares only the existing challenge API and player history.
