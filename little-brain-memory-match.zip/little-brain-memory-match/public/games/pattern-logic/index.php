<?php
declare(strict_types=1);
$logicGameKey = 'pattern-logic';
require dirname(__DIR__, 3) . '/app/logic-game-template.php';
