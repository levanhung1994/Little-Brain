<?php
declare(strict_types=1);
require dirname(__DIR__, 3) . '/app/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
$csrf = htmlspecialchars((string)$_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#f5f8ff"><meta name="csrf-token" content="<?= $csrf ?>">
<title>Bé chép thơ | LITTLE BRAIN</title>
<link rel="icon" type="image/svg+xml" href="../../assets/images/brand/brain.svg">
<link rel="stylesheet" href="../../assets/css/poem-typing.css?v=1.0.1">
<link rel="stylesheet" href="../../assets/css/victory-celebration.css?v=1.0.0">
<script src="../../assets/js/victory-celebration.js?v=1.0.0" defer></script>
<script src="../../assets/js/poem-typing.js?v=1.0.1" defer></script>
  <link rel="stylesheet" href="../../assets/css/kids-mode.css?v=20261017.1">
<link rel="stylesheet" href="../../assets/css/daily-challenge.css?v=20261017.2">
<link rel="stylesheet" href="../../assets/css/kids-readable.css?v=20261017.2">
<script src="../../assets/js/daily-challenge.js?v=20261017.2" defer></script>
</head>
<body class="kids-mode">
<div class="typing-app">
  <header class="typing-nav">
    <a href="../../index.php" class="typing-brand"><img src="../../assets/images/brand/brain.webp" alt=""><b>LITTLE <span>BRAIN</span></b></a>
    <a class="typing-hub" href="../../index.php">← <span>Kho game</span></a>
    <div class="typing-profile"><label for="typing-player">Bé đang chơi</label><select id="typing-player" aria-label="Chọn hồ sơ"><option>Đang tải...</option></select><button id="typing-add-player" type="button" aria-label="Tạo hồ sơ bé" title="Thêm hồ sơ">+</button></div>
  </header>
  <main>
    <div class="typing-heading">
      <div class="typing-heading-title"><span class="typing-eyebrow">LITTLE BRAIN · TYPING ADVENTURE</span><h1>Bé chép thơ <span aria-hidden="true">✍️</span></h1><p>Nhìn bài thơ, gõ lại thật giống mẫu nhé!</p></div>
      <button id="typing-options-toggle" type="button" aria-controls="typing-options" aria-expanded="false" class="typing-options-button">⚙ Chọn cấp độ</button>
    </div>
    <div class="typing-options" id="typing-options" hidden>
      <b>Chọn cấp độ</b>
      <div class="typing-level-buttons" id="typing-level-buttons" role="group" aria-label="Cấp độ chép thơ">
        <button data-level="easy" class="active" type="button">Dễ <small>2 dòng</small></button>
        <button data-level="normal" type="button">Vừa <small>3 dòng</small></button>
        <button data-level="advanced" type="button">Khá <small>4 dòng</small></button>
        <button data-level="hard" type="button">Khó <small>6 dòng</small></button>
      </div>
    </div>
    <div class="typing-statusline">
      <span class="typing-pill"><span class="typing-pill-dot"></span> <b id="typing-level-label">Dễ</b> <span>·</span> Bài <b id="typing-number">1</b>/5</span>
      <div class="typing-status-right"><span>⏱ <b id="typing-time">00:00</b></span><span>✦ <b id="typing-percent">0%</b> đã khớp</span></div>
    </div>
    <div class="typing-workspace">
      <section class="typing-card typing-poem-card" aria-label="Bài thơ mẫu">
        <div class="typing-card-top"><span class="typing-tag">📖 BÀI THƠ MẪU</span><span class="typing-printed">Bé đọc rồi gõ lại nhé!</span></div>
        <div class="typing-poem-title" id="typing-poem-title">Đang chọn bài thơ...</div>
        <div class="typing-poem-sheet">
          <div class="typing-poem-art"><img id="typing-poem-image" src="../../assets/images/animals/cat.webp" alt="Hình minh họa bài thơ" draggable="false"></div>
          <div class="typing-poem-text" id="typing-poem-text" aria-label="Nội dung bài thơ cần gõ"></div>
          <div class="typing-paper-mark" aria-hidden="true">✿ ✨</div>
        </div>
        <div class="typing-poem-note"><span aria-hidden="true">💡</span> Nhớ gõ đúng chữ và dấu nhé! Dấu cách thừa không sao.</div>
      </section>
      <section class="typing-card typing-write-card" aria-label="Bé gõ thơ">
        <div class="typing-card-top"><span class="typing-tag lavender">⌨️ PHẦN BÉ GÕ</span><span class="typing-keyboard-chip">Bàn phím thật</span></div>
        <label class="typing-write-title" for="typing-input">Bé viết lại bài thơ ở đây</label>
        <div class="typing-editor-shell">
          <textarea id="typing-input" spellcheck="false" autocomplete="off" autocapitalize="off" autocorrect="off" maxlength="1300" placeholder="Bé đặt tay lên bàn phím và bắt đầu gõ nhé!" aria-describedby="typing-help"></textarea>
          <div class="typing-editor-bottom"><span id="typing-char-count">0 ký tự</span><span id="typing-editor-state">Chưa bắt đầu</span></div>
        </div>
        <div class="typing-progress" aria-label="Tiến độ gõ"><div id="typing-progress-fill"></div></div>
        <p class="typing-help" id="typing-help">Nhấn Enter để xuống dòng, Backspace để xóa chữ sai.</p>
        <p class="typing-feedback" id="typing-feedback" role="status" aria-live="polite">Bé bắt đầu gõ nhé! 🌟</p>
        <div class="typing-actions"><button type="button" id="typing-new" class="typing-btn secondary">↻ Đổi bài thơ</button><button type="button" id="typing-check" class="typing-btn primary" disabled>✓ Kiểm tra bài</button></div>
      </section>
    </div>
  </main>
  <footer class="typing-footer"><span>LITTLE BRAIN · Chăm chỉ mỗi ngày, tiến bộ mỗi ngày</span><span>Chơi offline cùng gia đình ♥</span></footer>
</div>
<div id="typing-modal-overlay" class="typing-modal-overlay" hidden>
  <section class="typing-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="typing-modal-title">
    <button id="typing-modal-close" class="typing-modal-close" type="button" aria-label="Đóng">×</button>
    <div id="typing-modal-content"></div>
  </section>
</div>
</body>
</html>
