<?php
declare(strict_types=1);
$mathGameKey = 'missing-number';
require dirname(__DIR__, 3) . '/app/math-game-template.php';
