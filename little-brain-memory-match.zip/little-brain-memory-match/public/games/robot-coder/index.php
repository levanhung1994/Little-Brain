<?php
declare(strict_types=1);
$logicGameKey = 'robot-coder';
require dirname(__DIR__, 3) . '/app/logic-game-template.php';
