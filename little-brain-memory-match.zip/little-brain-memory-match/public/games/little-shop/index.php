<?php
declare(strict_types=1);
$mathGameKey = 'little-shop';
require dirname(__DIR__, 3) . '/app/math-game-template.php';
