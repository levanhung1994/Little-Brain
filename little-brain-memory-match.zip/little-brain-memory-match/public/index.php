<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
$games = require dirname(__DIR__) . '/app/games.php';
$escape = static fn(mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$gameCount = count($games);
$availableGames = array_values(array_filter($games, static fn(array $game): bool => $game['status'] === 'available'));
$plannedGames = array_values(array_filter($games, static fn(array $game): bool => $game['status'] !== 'available'));
$availableCount = count($availableGames);
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-cache');
$csrf = htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#f5f9ff">
    <meta name="description" content="Little Brain – thế giới trò chơi phát triển trí nhớ, tư duy, quan sát và tập trung dành cho trẻ 4–6 tuổi.">
    <meta name="csrf-token" content="<?= $csrf ?>">
    <title>LITTLE BRAIN PC | Kho trò chơi phát triển tư duy cho bé</title>
    <link rel="icon" type="image/svg+xml" href="assets/images/brand/brain.svg">
    <link rel="stylesheet" href="assets/css/styles.css?v=1.0.1">
    <link rel="stylesheet" href="assets/css/games-hub.css?v=3.0.0">
    <link rel="stylesheet" href="assets/css/desktop-only.css?v=3.0.0">
    <link rel="stylesheet" href="assets/css/simple-pc.css?v=4.0.0">
    <link rel="stylesheet" href="assets/css/game-menu-v2.css?v=20261012.2">
    <script src="assets/js/app.js?v=20261014.1" defer></script>
  <link rel="stylesheet" href="assets/css/3d-kids.css?v=20261014.1">
  <link rel="stylesheet" href="assets/css/victory-celebration.css?v=1.0.0">
  <link rel="stylesheet" href="assets/css/kids-mode.css?v=20261017.1">
<link rel="stylesheet" href="assets/css/daily-challenge.css?v=20261017.2">
<link rel="stylesheet" href="assets/css/kids-readable.css?v=20261017.2">
<script src="assets/js/daily-challenge.js?v=20261017.2" defer></script>
  <script src="assets/js/kids-mode.js?v=20261017.1" defer></script>
  <script src="assets/js/victory-celebration.js?v=1.0.0" defer></script>
</head>
<body class="kids-mode">
<div class="site-shell">
    <header class="topbar">
        <a class="brand brand-home" href="#home" data-view="hub" aria-label="Về kho trò chơi Little Brain">
            <div class="brand-icon"><img src="assets/images/brand/brain.webp" alt="" width="54" height="54"></div>
            <div class="brand-copy"><span class="brand-eyebrow">LITTLE <b>BRAIN</b></span></div>
        </a>
        <nav class="main-nav" aria-label="Điều hướng chính">
            <button class="nav-tab active" data-view="hub" type="button" aria-current="page"><span data-icon="layout-grid"></span><span>Kho game</span></button>
        </nav>
        <div class="top-actions">
            <button class="icon-button" id="sound-toggle" type="button" aria-label="Bật hoặc tắt âm thanh" title="Âm thanh"><span data-icon="volume-2"></span></button>
            <button class="icon-button fullscreen-button" id="fullscreen-toggle" type="button" aria-label="Toàn màn hình" title="Toàn màn hình"><span data-icon="expand"></span></button>
            <button class="icon-button" id="settings-toggle" type="button" aria-label="Cài đặt" title="Cài đặt"><span data-icon="settings"></span></button>
        </div>
    </header>

    <main>
        <section class="view view-hub hub-v2 active" id="view-hub" aria-labelledby="hub-title">
            <div class="kids-welcome" aria-label="Chào mừng bé đến kho trò chơi">
                <div class="kids-welcome-copy">
                    <span class="kids-welcome-kicker"><span aria-hidden="true">✦</span> LITTLE BRAIN · KIDS MODE</span>
                    <h1 id="hub-title">Hôm nay mình chơi gì nhỉ?</h1>
                    <p>Chọn một trò thật vui và bắt đầu khám phá nhé!</p>
                    <span class="kids-welcome-count"><span aria-hidden="true">✿</span> <?= $availableCount ?> trò chơi đang chờ bé</span>
                </div>
                <div class="kids-welcome-characters" aria-hidden="true">
                    <span class="kids-character-orbit kids-orbit-one">✦</span>
                    <span class="kids-character-orbit kids-orbit-two">★</span>
                    <img class="kids-welcome-bear" src="assets/images/animals/bear.webp" alt="" width="175" height="175">
                    <img class="kids-welcome-robot" src="assets/images/robot/robot.webp" alt="" width="170" height="170">
                </div>
            </div>
            <section class="daily-quest" id="daily-quest" aria-label="Thử thách chăm chỉ mỗi ngày">
                <div class="dq-head">
                    <div><span class="dq-kicker">🌸 BÔNG HOA CHĂM CHỈ</span><h2>Nhiệm vụ hôm nay</h2></div>
                    <span class="dq-badge" id="dq-date">Đang tải điểm danh...</span>
                </div>
                <div class="dq-layout">
                    <div class="dq-missions">
                        <article class="dq-task" id="dq-math-card">
                            <div class="dq-task-top"><span class="dq-task-number" id="dq-math-check">1</span><span class="dq-task-kind">🧮 NHIỆM VỤ TOÁN</span></div>
                            <h3 id="dq-math-title">Đang chọn trò chơi hôm nay...</h3>
                            <p id="dq-math-status">Hoàn thành 1 ván ở cấp Khá</p>
                            <a href="games/missing-number/index.php?difficulty=advanced&amp;daily=1" id="dq-math-link">Làm toán →</a>
                        </article>
                        <article class="dq-task" id="dq-poem-card">
                            <div class="dq-task-top"><span class="dq-task-number" id="dq-poem-check">2</span><span class="dq-task-kind">⌨️ NHIỆM VỤ TIẾNG VIỆT</span></div>
                            <h3>Bé chép thơ · Khá</h3>
                            <p id="dq-poem-status">Chép đúng 1 bài ở cấp Khá</p>
                            <a href="games/poem-typing/index.php?difficulty=advanced&amp;daily=1" id="dq-poem-link">Chép thơ →</a>
                        </article>
                    </div>
                    <div class="dq-flower-side">
                        <div id="dq-flower" aria-label="Bông hoa điểm danh"></div>
                        <strong id="dq-petals">0/5 cánh</strong>
                        <p>Đủ 5 ngày → 🎁 10.000đ từ mẹ Xoài</p>
                    </div>
                </div>
                <div class="dq-today-note" id="dq-today-note" role="status">Hoàn thành cả 2 nhiệm vụ để nhận 1 cánh hoa nhé!</div>
                <div id="dq-pending-rewards"></div>
                <div id="dq-legacy-rewards"></div>
            </section>
            <div class="hub-library-title" id="games-catalog">
                <div><h2>Kho trò chơi <span aria-hidden="true">✦</span></h2><p>Chọn hình bé thích để chơi ngay!</p></div>
                <div class="kids-filter" role="group" aria-label="Lọc các trò chơi theo chủ đề">
                    <button type="button" class="kids-filter-btn active" data-kids-filter="all" aria-pressed="true">Tất cả <span><?= $availableCount ?></span></button>
                    <button type="button" class="kids-filter-btn" data-kids-filter="logic" aria-pressed="false">🧩 Tư duy</button>
                    <button type="button" class="kids-filter-btn" data-kids-filter="math" aria-pressed="false">🌈 Toán học</button>
                    <button type="button" class="kids-filter-btn" data-kids-filter="language" aria-pressed="false">⌨️ Tiếng Việt</button>
                </div>
            </div>
            <p class="kids-filter-status" id="kids-filter-status" aria-live="polite" hidden></p>

            <?php foreach ([
                ['id' => 'available', 'label' => 'Chơi ngay', 'games' => $availableGames],
                ['id' => 'planned', 'label' => 'Sắp ra mắt', 'games' => $plannedGames],
            ] as $group): ?>
                <?php if (count($group['games']) === 0) continue; ?>
                <?php if ($group['id'] === 'planned'): ?>
                    <details class="kids-coming-soon" id="kids-coming-soon"><summary><span aria-hidden="true">🌟</span><span>Các trò chơi sắp ra mắt <small>Khám phá thêm sau nhé!</small></span><span class="kids-coming-count"><?= count($plannedGames) ?> game <span aria-hidden="true">⌄</span></span></summary>
                <?php endif; ?>
                <section class="hub-v2-group hub-v2-<?= $escape($group['id']) ?>" aria-labelledby="hub-group-<?= $escape($group['id']) ?>">
                    <div class="hub-v2-group-title">
                        <h2 id="hub-group-<?= $escape($group['id']) ?>"><?= $escape($group['label']) ?></h2>
                    </div>
                    <div class="hub-library-grid" aria-label="<?= $escape($group['label']) ?>">
                        <?php foreach ($group['games'] as $game): ?>
                            <?php
                            $available = $game['status'] === 'available';
                            $targetView = (string) ($game['view'] ?? '');
                            $targetUrl = (string) ($game['url'] ?? '');
                            if ($available && $targetView === 'game') {
                                $tag = 'a';
                                $targetAttributes = 'href="#memory-match" data-view="game"';
                            } elseif ($available && preg_match('~^games/[a-z0-9-]+/index\.php$~D', $targetUrl)) {
                                $tag = 'a';
                                $targetAttributes = 'href="' . $escape($targetUrl) . '"';
                            } else {
                                $tag = 'article';
                                $targetAttributes = '';
                                $available = false;
                            }
                            $preview = (string) ($game['preview'] ?? $game['art'][0] ?? '');
                            $category = match ((string) $game['id']) {
                                'memory-match', 'pattern-logic', 'robot-coder' => 'logic',
                                'balance-puzzle', 'missing-number', 'little-shop', 'daily-math-sharing' => 'math',
                                'poem-typing' => 'language',
                                default => 'planned',
                            };
                            $categoryLabel = match ($category) {
                                'logic' => 'Tư duy',
                                'math' => 'Toán học',
                                'language' => 'Tiếng Việt',
                                default => 'Sắp ra mắt',
                            };
                            $tagline = (string) ($game['tagline'] ?? $game['description'] ?? '');
                            ?>
                            <<?= $tag ?> class="hub-game-card hub-game-<?= $available ? 'available' : 'planned' ?> tone-<?= $escape($game['tone']) ?>" data-kids-category="<?= $escape($category) ?>" <?= $targetAttributes ?> <?= $available ? 'aria-label="Chơi ' . $escape($game['vietnamese']) . '"' : '' ?>>
                                <div class="hub-game-cover">
                                    <?php if ($available): ?><span class="kids-category-tag"><?= $escape($categoryLabel) ?></span><?php endif; ?>
                                    <img class="hub-v2-preview" src="<?= $escape($preview) ?>" alt="Hình minh họa 3D cách chơi <?= $escape($game['vietnamese']) ?>" loading="eager" decoding="async" width="600" height="340">
                                    <?php if (!$available): ?><span class="hub-game-status status-soon">SẮP RA MẮT</span><?php endif; ?>
                                </div>
                                <div class="hub-game-details">
                                    <div class="hub-v2-card-copy">
                                        <h3><?= $escape($game['vietnamese']) ?></h3>
                                        <p><?= $escape($tagline) ?></p>
                                    </div>
                                    <?php if ($available): ?>
                                        <span class="hub-v2-go" aria-hidden="true"><span data-icon="play"></span></span>
                                    <?php else: ?>
                                        <span class="hub-v2-lock" aria-hidden="true"><span data-icon="lock"></span></span>
                                    <?php endif; ?>
                                </div>
                            </<?= $tag ?>>
                        <?php endforeach; ?>
                    </div>
                </section>
                <?php if ($group['id'] === 'planned'): ?></details><?php endif; ?>
            <?php endforeach; ?>
        </section>

        <section class="view view-game" id="view-game">
            <div class="memory-page-head">
                <button type="button" class="memory-back" data-view="hub"><span data-icon="arrow-left"></span> Kho game</button>
                <h1><span class="kids-title-star" aria-hidden="true">✦</span> Tìm hai hình giống nhau</h1>
                <button type="button" class="memory-panel-toggle" id="memory-panel-toggle" aria-controls="memory-control-panel" aria-expanded="false"><span data-icon="sliders-horizontal"></span> Tùy chọn</button>
            </div>

            <div class="game-layout sidebar-collapsed" id="memory-layout">
                <aside class="control-panel panel" id="memory-control-panel">
                    <div class="panel-heading"><span class="panel-heading-icon purple"><span data-icon="sliders-horizontal"></span></span><div><h2>Tùy chọn</h2></div><button type="button" class="memory-panel-close" id="memory-panel-close" aria-label="Thu gọn bảng điều khiển" title="Thu gọn"><span data-icon="x"></span></button></div>
                    <div class="profile-card"><div class="profile-avatar"><span data-icon="smile"></span></div><div class="profile-fields"><label for="player-select">BÉ ĐANG CHƠI</label><select id="player-select" aria-label="Chọn người chơi"></select></div><button class="profile-add" type="button" id="add-profile" title="Thêm hồ sơ" aria-label="Thêm hồ sơ"><span data-icon="plus"></span></button></div>

                    <div class="control-section"><div class="section-label"><span data-icon="grid-2x2"></span> Chọn cấp độ</div><div class="difficulty-options" id="difficulty-options"><button class="difficulty-button" data-level="easy" type="button"><span class="difficulty-name">Dễ</span><small>6 ô</small></button><button class="difficulty-button active" data-level="normal" type="button"><span class="difficulty-name">Vừa</span><small>12 ô</small></button><button class="difficulty-button" data-level="advanced" type="button"><span class="difficulty-name">Khá</span><small>20 ô</small></button><button class="difficulty-button" data-level="hard" type="button"><span class="difficulty-name">Khó</span><small>30 ô</small></button></div></div>

                    <div class="control-section theme-section"><div class="section-label"><span data-icon="palette"></span> Thế giới của bé</div><div class="theme-options" id="theme-options"></div></div>
                    <div class="play-actions"><button type="button" class="primary-button" id="restart-button"><span data-icon="play"></span> Chơi ván mới <span data-icon="arrow-right"></span></button><button type="button" class="secondary-button" id="hint-button"><span data-icon="lightbulb"></span> Xem gợi ý</button></div>
                </aside>

                <section class="play-panel panel" aria-label="Bàn chơi tìm hai hình giống nhau">
                    <div class="play-panel-title"><div><h2>Tìm hai hình giống nhau nhé!</h2></div><div class="level-pill" id="level-pill"><span data-icon="sparkles"></span> Bình thường · 12 ô</div></div>
                    <div class="stats-grid" aria-live="off">
                        <div class="stat-item stat-blue"><span class="stat-icon"><span data-icon="puzzle"></span></span><div><div class="stat-number" id="stat-matches">0<span class="stat-total">/6</span></div><div class="stat-caption">Cặp đã tìm</div></div></div>
                        <div class="stat-item stat-purple"><span class="stat-icon"><span data-icon="mouse-pointer-click"></span></span><div><div class="stat-number" id="stat-attempts">0</div><div class="stat-caption">Lượt thử</div></div></div>
                        <div class="stat-item stat-peach"><span class="stat-icon"><span data-icon="timer"></span></span><div><div class="stat-number" id="stat-time">00:00</div><div class="stat-caption">Thời gian</div></div></div>
                        <div class="stat-item stat-yellow"><span class="stat-icon"><span data-icon="star"></span></span><div><div class="stat-number stars-stat" id="stat-stars">☆☆☆</div><div class="stat-caption">Ngôi sao</div></div></div>
                    </div>
                    <div class="board-topline"><div class="board-progress"><span id="progress-label">0 / 6 cặp</span><div class="progress-track"><div id="progress-fill"></div></div></div></div>
                    <div class="memory-board" id="memory-board" aria-label="Các thẻ hình" aria-busy="true"></div>
                </section>
            </div>
        </section>

        <section class="view view-page" id="view-history" aria-labelledby="history-title">
            <div class="page-banner banner-lavender"><span class="page-banner-icon"><span data-icon="history"></span></span><div><div class="eyebrow">HÀNH TRÌNH CỦA BÉ</div><h1 id="history-title">Nhật ký khám phá</h1><p>Những trò chơi đã hoàn thành được lưu ngay trên máy tính này.</p></div></div>
            <div class="page-content panel"><div class="table-heading"><div><h2>Lịch sử chơi</h2><p id="history-count">Các ván đã hoàn thành</p></div><button id="refresh-history" class="outline-button" type="button"><span data-icon="refresh-cw"></span> Làm mới</button></div><div id="history-list" class="history-list"></div><div class="pagination"><button id="load-more-history" class="outline-button" type="button" hidden>Xem thêm <span data-icon="chevron-down"></span></button></div></div>
        </section>

        <section class="view view-page" id="view-achievements" aria-labelledby="achievement-title">
            <div class="page-banner banner-yellow"><span class="page-banner-icon"><span data-icon="trophy"></span></span><div><div class="eyebrow">MỖI NGÀY MỘT TIẾN BỘ</div><h1 id="achievement-title">Vườn sao của bé</h1><p>Khám phá những ngôi sao và cột mốc đáng nhớ!</p></div></div>
            <div class="achievement-summary" id="achievement-summary"></div><div class="page-content panel"><div class="table-heading"><div><h2>Kỷ lục theo cấp độ</h2><p>Thành tích tốt nhất của bé ở mỗi thử thách.</p></div></div><div class="best-levels" id="best-levels"></div></div><div class="page-content panel" id="logic-best-section"><div class="table-heading"><div><h2>K&#7927; l&#7909;c game t&#432; duy</h2><p>Th&#224;nh t&#237;ch T&#236;m quy lu&#7853;t, Robot v&#224; C&#226;n b&#7857;ng.</p></div></div><div class="logic-best-grid" id="logic-best-levels"></div></div><div class="page-content panel badge-panel"><div class="table-heading"><div><h2>Huy hiệu khám phá</h2><p>Chơi vui mỗi ngày để mở khóa thêm nhé!</p></div></div><div class="badges-grid" id="badges-grid"></div></div>
        </section>
    </main>
    <footer class="footer"><span><b>LITTLE BRAIN</b> · Thế giới trò chơi phát triển tư duy cho bé</span><span>Made with <span class="footer-heart">♥</span> for little explorers</span></footer>
</div>

<div class="desktop-device-notice" role="note" aria-label="Thông báo phiên bản máy tính">
    <div class="desktop-device-notice-inner">
        <img src="assets/images/brand/brain.webp" alt="Little Brain" width="90" height="90">
        <h1>Little Brain · Bản máy tính</h1>
        <p>Phiên bản này được tối ưu cho laptop và máy tính để bàn (màn hình từ 1024 px). Hãy mở website trên máy tính để chơi cùng bé nhé!</p>
    </div>
</div>

<div class="modal-overlay" id="modal-overlay" hidden><div class="modal-dialog" id="modal-dialog" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button class="modal-close" type="button" id="modal-close" aria-label="Đóng"><span data-icon="x"></span></button><div id="modal-content"></div></div></div>
<div class="toast-stack" id="toast-stack" aria-live="polite" aria-atomic="true"></div>
<div class="confetti-layer" id="confetti-layer" aria-hidden="true"></div>
</body>
</html>
