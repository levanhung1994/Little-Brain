/* Shared, presentation-only victory effects for every Little Brain game.
 * No game rules, timers, scores, persistence or modal buttons are changed. */
'use strict';
(() => {
  const definitions = [
    ['#modal-overlay','#modal-dialog','#modal-content','.result-illustration'],
    ['#logic-modal','.logic-modal-dialog','#logic-modal-body','.result-big-stars, .robot-success-progress, .balance-success-progress, .math-success-progress'],
    ['#share-modal','.share-modal','#share-modal-body','.share-correct-icon, .share-result-flower'],
    ['#typing-modal-overlay','.typing-modal-dialog','#typing-modal-content','.typing-win-medal'],
  ];
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let particleLayer = null;
  let cleanTimer = null;

  function particles() {
    if (reduceMotion.matches || document.body.classList.contains('reduce-motion')) return;
    try { if (localStorage.getItem('lb-reduced-motion') === 'true') return; } catch {}
    if (!particleLayer) {
      particleLayer=document.createElement('div');
      particleLayer.className='lb-victory-confetti';
      particleLayer.setAttribute('aria-hidden','true');
      document.body.appendChild(particleLayer);
    }
    particleLayer.replaceChildren();
    if (cleanTimer)clearTimeout(cleanTimer);
    const palette=['#fcbb63','#a48cff','#76dcb4','#f98fb5','#7dc9ff','#ffdf76'];
    for(let i=0;i<45;i++) {
      const item=document.createElement('span');
      item.className=i%5===0?'lb-victory-spark':'lb-victory-piece';
      item.style.setProperty('--lb-x', `${(i*31+19)%101}%`);
      item.style.setProperty('--lb-delay', `${(i%9)*.09}s`);
      item.style.setProperty('--lb-duration', `${2.7+(i%6)*.33}s`);
      item.style.setProperty('--lb-color', palette[i%palette.length]);
      item.style.setProperty('--lb-spin', `${(i%2?1:-1)*(300+i*13)}deg`);
      particleLayer.appendChild(item);
    }
    cleanTimer=setTimeout(()=>particleLayer?.replaceChildren(),5500);
  }
  function boot() {
    for(const [overlaySelector,dialogSelector,bodySelector,successSelector] of definitions){
      const overlay=document.querySelector(overlaySelector);
      const dialog=overlay?.querySelector(dialogSelector);
      const content=overlay?.querySelector(bodySelector);
      if(!overlay||!dialog||!content)continue;
      let currentMarker=null;
      const update=()=>{
        const marker=!overlay.hidden?content.querySelector(successSelector):null;
        if(marker && marker!==currentMarker) {
          currentMarker=marker;
          overlay.classList.add('lb-victory-overlay');
          dialog.classList.add('lb-victory-dialog');
          particles();
        } else if(!marker){
          currentMarker=null;
          overlay.classList.remove('lb-victory-overlay');
          dialog.classList.remove('lb-victory-dialog');
        }
      };
      new MutationObserver(update).observe(content,{childList:true});
      new MutationObserver(update).observe(overlay,{attributes:true,attributeFilter:['hidden']});
      update();
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);
  else boot();
})();
