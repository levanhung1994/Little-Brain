'use strict';
(() => {
  const $ = (id) => document.getElementById(id);
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const assets = '../../assets/images/';
  const cookie = `${assets}daily-math/cookie.webp`;
  const friends = [
    {name:'Gấu',image:'animals/bear.webp',color:'peach'},
    {name:'Thỏ',image:'animals/rabbit.webp',color:'lilac'},
    {name:'Gấu trúc',image:'animals/panda.webp',color:'mint'},
    {name:'Cáo',image:'animals/fox.webp',color:'blue'},
  ];
  const labels = {easy:'Dễ',normal:'Vừa',advanced:'Khá',hard:'Khó'};
  const state = {
    playerId:null,profiles:[],level:'easy',token:null,task:null,stage:1,
    totalSteps:5,counts:[],attendance:null,attempts:0,errors:0,
    locked:false,done:false,modalCloseAction:null,modalDismissible:true,
    audio:null,starting:false,
  };
  try { state.level = localStorage.getItem('lb-share-level') || 'easy'; } catch {}
  if (!labels[state.level]) state.level = 'easy';
  if (new URLSearchParams(location.search).get('difficulty') === 'advanced') state.level = 'advanced';
  const escapeHTML = (text) => String(text ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  async function api(action, body) {
    const url = new URL('../../api/index.php', location.href);
    url.searchParams.set('action', action);
    if (body === undefined && state.playerId) url.searchParams.set('player_id', state.playerId);
    const opts = body === undefined
      ? {cache:'no-store',credentials:'same-origin'}
      : {method:'POST',cache:'no-store',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)};
    let response;
    try { response = await fetch(url, opts); } catch { throw new Error('Không kết nối được PHP. Hãy kiểm tra máy chủ.'); }
    let json;
    try { json = await response.json(); } catch { throw new Error('Phản hồi từ PHP không hợp lệ.'); }
    if (!response.ok || !json.ok) throw new Error(json.error || 'Không thực hiện được.');
    return json.data;
  }
  function playSound(which) {
    try {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C || localStorage.getItem('lb-sound') === 'false') return;
      const ctx = state.audio ||= new C();
      if (ctx.state === 'suspended') ctx.resume().catch(()=>{});
      const notes = which === 'win' ? [523,659,784,1047] : which === 'correct' ? [588,784] : [420];
      notes.forEach((hz,i) => {
        const t = ctx.currentTime+i*.1, osc=ctx.createOscillator(), gain=ctx.createGain();
        osc.type='sine'; osc.frequency.value=hz;
        gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.05,t+.015);
        gain.gain.exponentialRampToValueAtTime(.0001,t+.2);
        osc.connect(gain).connect(ctx.destination);osc.start(t);osc.stop(t+.21);
      });
    } catch {}
  }
  function toast(message) {
    const el=$('share-toast'); el.textContent=message;el.hidden=false;
    clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,3400);
  }
  function feedback(message, kind='neutral') {
    $('share-feedback').textContent=message;$('share-feedback').dataset.kind=kind;
  }
  function flowerMarkup(petals=0, small=false) {
    const on = ['#ff9eaa','#ffc86d','#7fd6b2','#b0a0f0','#fa9bcb'];
    const gradients = on.map((color,i)=>`<radialGradient id="fp-${small?'mini':'main'}-${i}" cx="35%" cy="28%" r="85%"><stop stop-color="#fffef4"/><stop offset=".43" stop-color="${color}"/><stop offset="1" stop-color="${color}"/></radialGradient>`).join('');
    const blades = Array.from({length:5},(_,i)=>{
      const earned=i<petals;
      return `<g class="flower-blade ${earned?'earned':'unearned'} flower-blade-${i+1}" transform="rotate(${i*72} 230 196)">
        <ellipse cx="230" cy="107" rx="55" ry="88" fill="${earned?`url(#fp-${small?'mini':'main'}-${i})`:'#eceaf5'}" stroke="${earned?'#fff9fb':'#dad6ec'}" stroke-width="5"/>
        <ellipse cx="213" cy="68" rx="15" ry="29" fill="white" opacity="${earned?'.48':'.24'}" transform="rotate(-16 213 68)"/>
      </g>`;
    }).join('');
    return `<svg class="share-flower-svg ${petals===5?'fully-bloomed':''}" viewBox="0 0 460 420" role="img" aria-label="Bông hoa đang nở ${petals} trong 5 cánh">
      <defs>${gradients}<linearGradient id="stem-${small?'mini':'main'}" x1="0" x2="1"><stop stop-color="#85d9ac"/><stop offset="1" stop-color="#43ab7e"/></linearGradient>
      <radialGradient id="face-${small?'mini':'main'}" cx="37%" cy="30%"><stop stop-color="#fff7bb"/><stop offset="1" stop-color="#ffc969"/></radialGradient>
      <filter id="shadow-${small?'mini':'main'}" x="-40%" y="-40%" width="180%" height="190%"><feDropShadow dx="0" dy="7" stdDeviation="6" flood-color="#9e8fac" flood-opacity=".19"/></filter></defs>
      <path d="M230 256 Q216 322 230 395" stroke="url(#stem-${small?'mini':'main'})" stroke-width="17" fill="none" stroke-linecap="round"/>
      <path d="M223 347 Q160 293 145 328 Q136 368 225 373Z" fill="#91ddb4" stroke="#60b993" stroke-width="4"/>
      <path d="M233 366 Q294 305 313 333 Q325 367 233 382Z" fill="#b3e9a3" stroke="#78c38b" stroke-width="4"/>
      <g filter="url(#shadow-${small?'mini':'main'})">${blades}</g>
      <circle cx="230" cy="196" r="67" fill="url(#face-${small?'mini':'main'})" stroke="#fff5c9" stroke-width="7" filter="url(#shadow-${small?'mini':'main'})"/>
      <circle cx="207" cy="189" r="6.5" fill="#845b57"/><circle cx="253" cy="189" r="6.5" fill="#845b57"/>
      <path d="M213 213 Q230 232 249 213" fill="none" stroke="#ad7161" stroke-width="6" stroke-linecap="round"/>
      <ellipse cx="192" cy="211" rx="10" ry="6" fill="#f8a49d" opacity=".7"/><ellipse cx="268" cy="211" rx="10" ry="6" fill="#f8a49d" opacity=".7"/>
      <g fill="#f9bd62" class="flower-sparkle"><path d="M70 49 L75 65 L91 70 L75 75 L70 91 L65 75 L49 70 L65 65Z"/><circle cx="390" cy="115" r="6"/><path d="M377 280 L381 292 L393 296 L381 300 L377 312 L373 300 L361 296 L373 292Z"/></g>
    </svg>`;
  }
  function renderFlower() {
    const a=state.attendance || {petals:0,total_days:0,done_today:false,last_days:[],pending_rewards:[],flowers_completed:0,flower_number:1};
    const petals=a.petals ?? 0;
    $('share-flower-art').innerHTML=flowerMarkup(petals);
    $('share-flower-count').textContent=`${petals} / 5 cánh`;
    $('share-flower-status').textContent=a.done_today
      ? 'Bé đã nhận một cánh hoa hôm nay. Giỏi quá!'
      : `Bé cần làm Toán Khá và Chép thơ Khá để nhận cánh hoa.`;
    $('share-petal-dots').innerHTML=Array.from({length:5},(_,i)=>`<span class="share-petal-chip ${i<petals?'active':''}">${i<petals?'♥':'✦'}</span>`).join('');
    $('share-total-days').textContent=`${a.total_days || 0} ngày`;
    const history=(a.last_days || []).slice().reverse();
    $('share-day-chips').innerHTML=history.length?history.slice(0,8).map(d=>{
      const [y,m,day] = d.date.split('-');
      return `<span class="share-day-chip">✓ ${day}/${m}</span>`;
    }).join(''):'<span class="share-no-attendance">Bé chưa có ngày điểm danh.</span>';
    const pending=(a.pending_rewards || []);
    $('share-reward-actions').innerHTML=pending.length?
      `<div class="share-pending-reward"><div>🎁 <b>${pending.length} phần thưởng đang chờ</b></div><button id="share-claim-button" type="button" data-reward="${escapeHTML(pending[0].id)}">Phụ huynh: Đã trao 10.000đ</button></div>`:'';
    const btn=$('share-claim-button');if(btn)btn.onclick=()=>confirmReward(btn.dataset.reward);
  }
  function modal(content, action=null, dismissible=true) {
    state.modalCloseAction=action;state.modalDismissible=dismissible;
    $('share-modal-body').innerHTML=content;
    $('share-modal').hidden=false;
    $('share-modal-close').focus();
  }
  function closeModal() {
    if ($('share-modal').hidden || !state.modalDismissible) return;
    $('share-modal').hidden=true;
    const next=state.modalCloseAction;state.modalCloseAction=null;
    if (next) next();
  }
  function displayDone() {
    state.done=true;state.token=null;state.task=null;state.locked=false;
    const dayTip=state.attendance?.math_game==='daily-math-sharing'
      ? (state.attendance.poem_done?'Bé đã hoàn thành hai nhiệm vụ hôm nay!':'Còn nhiệm vụ Chép thơ cấp Khá để nhận cánh hoa nhé!')
      : `Nhiệm vụ Toán hôm nay: ${escapeHTML(state.attendance?.math_name || 'xem Kho game')} cấp Khá.`;
    $('share-friends').innerHTML=`<div class="share-done-panel"><img src="${assets}daily-math/flower.webp" alt="Bông hoa rực rỡ"/><h2>Bé học toán giỏi lắm!</h2><p>${dayTip}</p><span>✓ Đã hoàn thành 5 bài chia bánh</span></div>`;
    $('share-cookie-tray').innerHTML='<div class="share-tray-empty">Bánh đã được chia đều cho các bạn ✨</div>';
    $('share-cookies-left').textContent='Hoàn thành rồi!';
    $('share-stage-count').textContent='5 / 5 bài';
    $('share-steps').innerHTML=Array.from({length:5},()=>'<span class="done"></span>').join('');
    $('share-task-title').textContent='Bé chia bánh giỏi quá!';
    $('share-task-hint').textContent='Bé có thể chơi lại hoặc chép thơ ở mức Khá.';
    $('share-check').disabled=true;$('share-reset').disabled=true;$('share-hint').disabled=true;
    feedback('Hoàn thành rồi! Bé hãy kiểm tra nhiệm vụ hôm nay nhé! 🌷','good');
  }
  function showFinish(result) {
    state.attendance=result.attendance;renderFlower();displayDone();playSound('win');
    const completionText=state.attendance.done_today?'🌸 Hôm nay bé đã có cánh hoa mới!'
      : state.attendance.math_game==='daily-math-sharing'?'Bé chép thơ cấp Khá nữa để hoàn thành nhiệm vụ hôm nay nhé!'
        : `Nhiệm vụ Toán hôm nay là ${escapeHTML(state.attendance.math_name)} cấp Khá nhé!`;
    modal(`<div class="share-result-flower">${flowerMarkup(state.attendance.petals,true)}</div>
      <h2 id="share-modal-title">Chia bánh giỏi quá!</h2><p>Bé đã hoàn thành 5 bài chia bánh!</p>
      <p>${completionText}</p>
      <button type="button" id="share-modal-done" class="share-modal-primary">Tuyệt vời!</button>`);
    $('share-modal-done').onclick=closeModal;
    if (result.attendance?.just_awarded) window.LittleBrainDailyChallenge?.announce?.(result.attendance);
    document.dispatchEvent(new CustomEvent('littlebrain:game-completed',{detail:{game_key:'daily-math-sharing',difficulty:state.level}}));
  }
  function showCorrect(result) {
    state.locked=true;playSound('correct');
    modal(`<div class="share-correct-icon">⭐</div><h2 id="share-modal-title">Chia đều rồi!</h2><p>Bé đã chia bánh thật công bằng cho các bạn.</p><span class="share-complete-count">✓ Bài ${result.finished_step} / 5</span><button id="share-modal-next" type="button" class="share-modal-primary">Bài tiếp theo →</button>`, () => {
      state.stage=result.step;state.task=result.task;state.counts=Array(result.task.friends).fill(0);state.locked=false;renderTask();
    });
    $('share-modal-next').onclick=closeModal;
  }
  function updateStepBar() {
    $('share-stage-count').textContent=`Bài ${state.stage} / 5`;
    $('share-steps').innerHTML=Array.from({length:5},(_,i)=>`<span class="${i<state.stage-1?'done':i===state.stage-1?'current':''}"></span>`).join('');
  }
  function renderTask() {
    if (!state.task || state.done) return;
    const {friends:friendsCount,cookies}=state.task;
    $('share-task-title').textContent=`Có ${cookies} chiếc bánh, chia cho ${friendsCount} bạn nhé!`;
    $('share-task-hint').textContent='Kéo bánh vào đĩa, hoặc bấm vào đĩa để chia.';
    state.counts=Array(friendsCount).fill(0);
    updateStepBar();renderPlates();renderTray();
    $('share-check').disabled=false;$('share-reset').disabled=false;$('share-hint').disabled=false;
    feedback('Mỗi bạn cần có số bánh bằng nhau nhé!');
  }
  function renderPlates() {
    const count=state.task.friends;
    $('share-friends').dataset.count=String(count);
    $('share-friends').innerHTML=friends.slice(0,count).map((f,i)=>{
      const n=state.counts[i];
      const cookies=Array.from({length:n},()=>`<img src="${cookie}" alt="" draggable="false">`).join('');
      return `<div class="share-friend ${f.color}">
        <div class="share-friend-head"><div class="share-avatar"><img src="${assets+f.image}" alt=""></div><div><b>Bạn ${f.name}</b><span><strong>${n}</strong> chiếc bánh</span></div></div>
        <button class="share-plate" type="button" data-add="${i}" aria-label="Cho bạn ${f.name} thêm một chiếc bánh" title="Bấm để cho bánh" ${state.locked?'disabled':''}><span class="share-plate-surface">${cookies||'<span class="share-plate-invite">+ Cho bánh</span>'}</span></button>
        <button class="share-take-back" type="button" data-remove="${i}" ${n===0||state.locked?'disabled':''}>− Lấy lại 1 bánh</button>
      </div>`;
    }).join('');
  }
  function remaining() {return state.task.cookies-state.counts.reduce((a,b)=>a+b,0);}
  function renderTray() {
    const left=remaining();
    $('share-cookies-left').textContent=`Còn ${left} / ${state.task.cookies} chiếc`;
    $('share-cookie-tray').innerHTML=left
      ? Array.from({length:left},(_,i)=>`<img class="share-drag-cookie" src="${cookie}" alt="Bánh quy trong giỏ" draggable="true" data-cookie="${i}" title="Kéo bánh vào đĩa bạn bè">`).join('')
      : '<span class="share-tray-empty">Đã chia hết bánh rồi! 🌟</span>';
  }
  function give(index) {
    if (state.done || state.locked || !state.task || index<0 || index>=state.counts.length || remaining()<=0) return;
    state.counts[index]++;renderPlates();renderTray();
    feedback('Bé tiếp tục chia cho các bạn nhé!');
  }
  function take(index) {
    if (state.done || state.locked || !state.task || index<0 || index>=state.counts.length || !state.counts[index]) return;
    state.counts[index]--;renderPlates();renderTray();
  }
  async function checkAnswer() {
    if (state.done || state.locked || !state.token || !state.task)return;
    state.locked=true;$('share-check').disabled=true;
    try {
      const result=await api('daily_math_answer', {player_id:state.playerId,token:state.token,counts:state.counts});
      if (!result.correct) {
        state.attempts=result.attempts;state.errors=result.mistakes;
        feedback(result.message,'try');playSound('bad');
        state.locked=false;$('share-check').disabled=false;
        renderPlates();return;
      }
      state.attempts=result.attempts;
      if (result.finished)showFinish(result);else showCorrect(result);
    } catch(err) {
      state.locked=false;$('share-check').disabled=false;
      toast(err.message);feedback('Có lỗi kết nối. Bé thử lại nhé!','try');
    }
  }
  async function giveHint() {
    if (state.done || state.locked || !state.token)return;
    state.locked=true;
    try {
      const data=await api('daily_math_hint',{player_id:state.playerId,token:state.token});
      feedback(data.message,'hint');
    } catch(err) {toast(err.message);} finally {state.locked=false;}
  }
  async function startLesson() {
    if (state.starting || !state.playerId) return;
    state.starting=true;
    try {
      const data=await api('daily_math_start',{player_id:state.playerId,difficulty:state.level});
      state.attendance=data.attendance;renderFlower();
      if (data.already_done) {displayDone();return;}
      state.token=data.token;state.stage=data.step;state.task=data.task;state.attempts=data.attempts;
      state.done=false;state.locked=false;renderTask();
    } catch(err){toast(err.message);feedback('Chưa mở được bài học, hãy thử tải lại trang.','try');}
    finally {state.starting=false;}
  }
  async function reloadPlayer() {
    state.locked=true;state.done=false;state.token=null;state.task=null;
    try {
      state.attendance=await api('daily_challenge_status');renderFlower();
      await startLesson();
    } catch(err){toast(err.message);} finally {state.locked=false;}
  }
  async function changePlayer(id) {
    if (state.locked||state.starting) {toast('Hãy chờ một chút nhé!');$('share-player').value=state.playerId;return;}
    if (!id || id===state.playerId)return;
    try {
      await api('select_profile',{player_id:id});state.playerId=id;
      try {localStorage.setItem('lb-player-id',id);} catch {}
      await reloadPlayer();
    } catch(err){toast(err.message);$('share-player').value=state.playerId;}
  }
  function refreshPlayerSelect() {
    $('share-player').innerHTML=state.profiles.map(p=>`<option value="${escapeHTML(p.id)}" ${p.id===state.playerId?'selected':''}>${escapeHTML(p.name)}</option>`).join('');
  }
  async function createPlayer() {
    if(state.locked||state.starting)return;
    modal(`<div class="share-correct-icon">🧸</div><h2 id="share-modal-title">Thêm hồ sơ bé</h2><form id="share-add-form" class="share-profile-form"><label for="share-new-name">Tên của bé</label><input required id="share-new-name" maxlength="24" autocomplete="off" placeholder="Ví dụ: Bé Na"><button type="submit" class="share-modal-primary">Tạo hồ sơ</button></form>`);
    $('share-add-form').onsubmit=async e=>{
      e.preventDefault();const btn=$('share-add-form').querySelector('button');btn.disabled=true;
      try {
        const player=await api('create_profile',{name:$('share-new-name').value});
        state.profiles.push(player);state.playerId=player.id;
        try {localStorage.setItem('lb-player-id',player.id);}catch{}
        closeModal();refreshPlayerSelect();await reloadPlayer();
      } catch(err){toast(err.message);btn.disabled=false;}
    };
  }
  async function confirmReward(id) {
    if (!id) return;
    if (!window.confirm('Phụ huynh xác nhận đã trao phần thưởng 10.000đ cho bé?'))return;
    try {
      state.attendance=await api('daily_challenge_mark_reward',{player_id:state.playerId,reward_id:id});
      renderFlower();toast('Đã ghi nhận bố mẹ trao thưởng cho bé!');
    } catch(err){toast(err.message);}
  }
  function bind() {
    $('share-player').onchange=e=>changePlayer(e.target.value);
    $('share-add-player').onclick=createPlayer;
    $('share-level-toggle').onclick=()=>{
      const picker=$('share-level-picker');picker.hidden=!picker.hidden;
      $('share-level-toggle').setAttribute('aria-expanded',String(!picker.hidden));
    };
    $('share-level-picker').addEventListener('click', async e=>{
      const button=e.target.closest('[data-level]');if(!button||state.starting||state.locked)return;
      const level=button.dataset.level;if(!labels[level]||level===state.level)return;
      if (!state.done && state.stage>1 && !window.confirm('Đổi cấp độ sẽ bắt đầu lại 5 bài hôm nay. Tiếp tục?'))return;
      state.level=level;try{localStorage.setItem('lb-share-level',level);}catch{}
      document.querySelectorAll('#share-level-picker button').forEach(el=>el.classList.toggle('active',el.dataset.level===level));
      if(!state.done){state.token=null;await startLesson();}
    });
    $('share-friends').addEventListener('click',e=>{
      const add=e.target.closest('[data-add]'),remove=e.target.closest('[data-remove]');
      if (add)give(Number(add.dataset.add));else if(remove)take(Number(remove.dataset.remove));
    });
    $('share-cookie-tray').addEventListener('dragstart',e=>{
      const el=e.target.closest('[data-cookie]');if(!el||state.locked)return;
      e.dataTransfer.setData('text/plain','little-brain-cookie');e.dataTransfer.effectAllowed='move';
    });
    $('share-friends').addEventListener('dragover',e=>{
      if(e.target.closest('[data-add]')&&!state.locked){e.preventDefault();e.dataTransfer.dropEffect='move';}
    });
    $('share-friends').addEventListener('drop',e=>{
      const plate=e.target.closest('[data-add]');if(!plate||e.dataTransfer.getData('text/plain')!=='little-brain-cookie')return;
      e.preventDefault();give(Number(plate.dataset.add));
    });
    $('share-reset').onclick=()=>{
      if (state.done || state.locked || !state.task)return;
      state.counts=Array(state.task.friends).fill(0);renderPlates();renderTray();feedback('Cùng chia lại từ đầu nhé!');
    };
    $('share-hint').onclick=giveHint;$('share-check').onclick=checkAnswer;
    $('share-modal-close').onclick=closeModal;
    $('share-modal').addEventListener('click',e=>{if(e.target===$('share-modal'))closeModal();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
  }
  async function init() {
    bind();
    document.querySelectorAll('#share-level-picker button').forEach(el=>el.classList.toggle('active',el.dataset.level===state.level));
    try {
      const b=await api('bootstrap');state.profiles=b.players;state.playerId=b.player_id;
      let previous=null;try{previous=localStorage.getItem('lb-player-id');}catch{}
      if(previous&&previous!==state.playerId&&state.profiles.some(p=>p.id===previous)){
        try{await api('select_profile',{player_id:previous});state.playerId=previous;}catch{}
      }
      refreshPlayerSelect();await reloadPlayer();
    } catch(err){toast(err.message);feedback('Chưa tải được hồ sơ bé. Kiểm tra PHP nhé!','try');}
  }
  init();
})();
