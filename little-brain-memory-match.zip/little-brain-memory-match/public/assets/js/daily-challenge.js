'use strict';
/* Daily two-task challenge: informational overlay only. PHP is authoritative. */
(() => {
  const $ = id => document.getElementById(id);
  const isGame = /\/games\/[a-z0-9-]+\/index\.php(?:$|\?)/.test(location.pathname);
  const base = isGame ? '../../' : '';
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
  let latest = null;
  let currentPlayer = null;
  let busy = false;
  let noticeTimer = null;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  async function api(action, body, playerId) {
    const url = new URL(base + 'api/index.php', location.href);
    url.searchParams.set('action', action);
    if (body === undefined && playerId) url.searchParams.set('player_id', playerId);
    const opts = body === undefined ? {cache:'no-store',credentials:'same-origin'} : {
      method:'POST',cache:'no-store',credentials:'same-origin',
      headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)
    };
    const response = await fetch(url, opts);
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || 'Không tải được điểm danh.');
    return result.data;
  }
  const flower = petals => {
    const colors = ['#ff9fb7','#ffc76b','#91dbb7','#bba9f4','#89cffa'];
    const petalsSvg = colors.map((color,i)=>`<g transform="rotate(${i*72} 110 105)"><ellipse cx="110" cy="63" rx="27" ry="41" fill="${i<petals?color:'#e7e9f3'}" stroke="#fff" stroke-width="3"/><ellipse cx="101" cy="49" rx="7" ry="14" fill="#fff" opacity="${i<petals?.38:.17}" transform="rotate(-12 101 49)"/></g>`).join('');
    return `<svg class="dq-flower-svg" viewBox="0 0 220 245" role="img" aria-label="Bông hoa đã nở ${petals} trong 5 cánh"><path d="M110 130 Q112 179 108 220" stroke="#5abe7d" stroke-width="10" stroke-linecap="round" fill="none"/><path d="M109 189 Q67 156 53 181 Q70 209 109 200" fill="#92dda0" stroke="#4fbc79" stroke-width="3"/><path d="M110 203 Q145 168 165 188 Q150 212 111 212" fill="#92dda0" stroke="#4fbc79" stroke-width="3"/>${petalsSvg}<circle cx="110" cy="105" r="31" fill="#ffe59b" stroke="#f2b94f" stroke-width="3"/><circle cx="98" cy="99" r="3.2" fill="#8b582e"/><circle cx="122" cy="99" r="3.2" fill="#8b582e"/><path d="M99 111 Q110 124 122 111" fill="none" stroke="#8b582e" stroke-width="3" stroke-linecap="round"/><circle cx="90" cy="109" r="6" fill="#ff9c9e" opacity=".6"/><circle cx="130" cy="109" r="6" fill="#ff9c9e" opacity=".6"/></svg>`;
  };
  function render(s) {
    const section = $('daily-quest');
    if (!section) return;
    section.hidden = false;
    $('dq-date').textContent = `${s.total_days} ngày chăm chỉ`;
    $('dq-math-title').textContent = s.math_name + ' · Khá';
    $('dq-math-status').textContent = s.math_done ? 'Đã hoàn thành ✓' : 'Hoàn thành 1 ván cấp Khá';
    $('dq-poem-status').textContent = s.poem_done ? 'Đã chép đúng ✓' : 'Chép đúng 1 bài cấp Khá';
    $('dq-math-card').classList.toggle('dq-done', s.math_done);
    $('dq-poem-card').classList.toggle('dq-done', s.poem_done);
    $('dq-math-check').textContent = s.math_done ? '✓' : '1';
    $('dq-poem-check').textContent = s.poem_done ? '✓' : '2';
    $('dq-math-link').href = esc(s.math_url);
    $('dq-poem-link').href = esc(s.poem_url);
    $('dq-math-link').textContent = s.math_done ? 'Chơi lại' : 'Làm toán →';
    $('dq-poem-link').textContent = s.poem_done ? 'Chép tiếp' : 'Chép thơ →';
    $('dq-flower').innerHTML = flower(s.petals);
    $('dq-petals').textContent = s.petals + '/5 cánh';
    $('dq-today-note').textContent = s.done_today
      ? '🌟 Bé đã nhận 1 cánh hoa hôm nay!'
      : s.math_done ? 'Tuyệt vời! Bé chỉ cần chép thơ nữa.'
        : s.poem_done ? 'Hay lắm! Bé làm toán mức Khá nữa nhé.'
          : 'Làm xong cả 2 nhiệm vụ để nhận 1 cánh nhé!';
    $('dq-today-note').classList.toggle('dq-achieved',s.done_today);
    $('dq-pending-rewards').innerHTML = (s.pending_rewards || []).map(r=>`<div class="dq-reward-row"><span>🎁 Mẹ Xoài thưởng bé <b>10.000đ</b>!</span><button type="button" data-dq-claim="${esc(r.id)}">Đã trao thưởng</button></div>`).join('');
    const old = s.legacy_pending_rewards || [];
    $('dq-legacy-rewards').innerHTML = old.length ? `<details><summary>Phần thưởng cũ còn chờ xác nhận (${old.length})</summary>${old.map(r=>`<div class="dq-reward-row"><span>🎁 Phần thưởng theo quy tắc trước đây: <b>10.000đ</b></span><button type="button" data-dq-old-claim="${esc(r.id)}">Đã trao</button></div>`).join('')}</details>` : '';
  }
  function toast(petals, reward) {
    let el = $('dq-celebration');
    if (!el) {el=document.createElement('div');el.id='dq-celebration';el.className='dq-celebration';document.body.appendChild(el);}
    el.innerHTML = `<div class="dq-celebrate-art" aria-hidden="true">${flower(petals)}</div>
      <div><div class="dq-celebrate-kicker">${reward?'🎁 BÔNG HOA HOÀN THÀNH':'🌸 THÊM MỘT CÁNH HOA'}</div>
      <h2>${reward?'Mẹ Xoài thưởng bé 10.000đ!':'Giỏi quá! Bé nhận 1 cánh hoa!'}</h2>
      <p>${reward?'Bé đã hoàn thành 5 ngày học. Chờ mẹ trao phần thưởng nhé!':`Bông hoa đã có ${petals}/5 cánh rồi!`}</p>
      <a href="${base}index.php#daily-quest">Xem bông hoa →</a></div>
      <button class="dq-celebrate-close" type="button" aria-label="Đóng thông báo">×</button>`;
    el.hidden = false;
    el.querySelector('.dq-celebrate-close').onclick=()=>{el.hidden=true;};
    clearTimeout(noticeTimer);
    noticeTimer=setTimeout(()=>{el.hidden=true;},reward?16000:10000);
  }
  async function refresh(celebrate=false) {
    if (busy) return latest;
    busy=true;
    try {
      const b=await api('bootstrap');
      currentPlayer=b.player_id;
      const status=await api('daily_challenge_status',undefined,currentPlayer);
      latest=status;
      render(status);
      if (celebrate && status.just_awarded) toast(status.petals,status.just_reward_earned);
      return status;
    } catch (err) {
      if ($('dq-today-note')) $('dq-today-note').textContent='Chưa tải được nhiệm vụ. Bé thử lại nhé!';
      console.warn('Little Brain daily challenge:',err.message);
      return null;
    } finally {busy=false;}
  }
  window.LittleBrainDailyChallenge={refresh, announce: status => {if(status?.just_awarded) toast(status.petals, status.just_reward_earned);}};
  document.addEventListener('littlebrain:game-completed', () => {refresh(true);});
  document.addEventListener('littlebrain:profile-changed', ()=>{refresh(false);});
  document.addEventListener('click', async e=>{
    const btn=e.target.closest('[data-dq-claim], [data-dq-old-claim]');
    if (!btn) return;
    if (!confirm('Mẹ Xoài xác nhận đã trao 10.000đ cho bé?')) return;
    btn.disabled=true;
    try {
      const old=btn.hasAttribute('data-dq-old-claim');
      await api(old?'daily_math_mark_reward':'daily_challenge_mark_reward',{
        player_id:currentPlayer,reward_id:btn.dataset[old?'dqOldClaim':'dqClaim']
      });
      await refresh(false);
    } catch(err){alert('Chưa lưu được: '+err.message);btn.disabled=false;}
  });
  if ($('daily-quest')) {
    document.addEventListener('DOMContentLoaded',()=>{refresh(false);});
    // Navigation from Memory Match doesn't always reload the home page.
    document.addEventListener('click', e=>{if(e.target.closest('[data-view="hub"]'))setTimeout(()=>refresh(false),200);});
  }
})();
