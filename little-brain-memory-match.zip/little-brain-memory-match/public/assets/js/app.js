'use strict';
(() => {
  const iconPaths = {
    'house':'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    'layout-grid':'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    'arrow-left':'<path d="M20 12H4m7 7-7-7 7-7"/>',
    'history':'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    'trophy':'<path d="M8 21h8M12 17v4M7 4h10v7a5 5 0 0 1-10 0zM7 6H4v3a4 4 0 0 0 4 4m9-7h3v3a4 4 0 0 1-4 4"/>',
    'volume-2':'<path d="M11 5 6 9H3v6h3l5 4zM15 9a5 5 0 0 1 0 6m3-9a9 9 0 0 1 0 12"/>',
    'volume-x':'<path d="M11 5 6 9H3v6h3l5 4zM17 9l5 6m0-6-5 6"/>',
    'expand':'<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3"/>',
    'settings':'<path d="M12 3v2m0 14v2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4M3 12h2m14 0h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="2"/>',
    'sliders-horizontal':'<path d="M3 7h5m4 0h9M3 17h9m4 0h5"/><circle cx="10" cy="7" r="2"/><circle cx="14" cy="17" r="2"/>',
    'smile':'<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2.5 4 2.5 4-2.5 4-2.5M9 9h.01M15 9h.01"/>',
    'plus':'<path d="M12 5v14M5 12h14"/>',
    'grid-2x2':'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    'palette':'<circle cx="12" cy="12" r="9"/><circle cx="7" cy="10" r="1"/><circle cx="11" cy="6.5" r="1"/><circle cx="17" cy="9" r="1"/><path d="M19 16h-3a2 2 0 0 0-1 4"/>',
    'play':'<path d="m8 5 12 7-12 7z"/>', 'arrow-right':'<path d="M4 12h16m-7-7 7 7-7 7"/>',
    'lightbulb':'<path d="M9 18h6m-6 3h6M8 14a7 7 0 1 1 8 0l-1 3H9z"/>',
    'heart':'<path d="M20.8 4.8a5.6 5.6 0 0 0-7.9 0l-.9.9-.9-.9a5.6 5.6 0 0 0-7.9 7.9l8.8 8.3 8.8-8.3a5.6 5.6 0 0 0 0-7.9z"/>',
    'sparkles':'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7zM19 17l.7 2.3L22 20l-2.3.7L19 23l-.7-2.3L16 20l2.3-.7zM4 2l.5 1.5L6 4l-1.5.5L4 6l-.5-1.5L2 4l1.5-.5z"/>',
    'puzzle':'<path d="M8 3H5a2 2 0 0 0-2 2v4h2a2 2 0 1 1 0 4H3v6a2 2 0 0 0 2 2h5v-2a2 2 0 1 1 4 0v2h5a2 2 0 0 0 2-2v-5h-2a2 2 0 1 1 0-4h2V5a2 2 0 0 0-2-2h-5v2a2 2 0 1 1-4 0V3z"/>',
    'mouse-pointer-click':'<path d="m5 3 4 17 3-6 6-2zM15 3v3M20 8h-3m1-5-2 2"/>',
    'timer':'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6m4 4 2-2"/>',
    'star':'<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.3-6.2 3.3L7 14.2l-5-4.9 6.9-1z"/>',
    'wand-sparkles':'<path d="m4 20 12-12 4 4L8 24M15 3l.5 2.5L18 6l-2.5.5L15 9l-.5-2.5L12 6l2.5-.5M20 2v3M22 3.5h-4"/>',
    'shield-check':'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9 12l2 2 4-4"/>',
    'mouse-pointer-2':'<path d="m5 3 14 9-7 1-3 7z"/>', 'refresh-cw':'<path d="M20 7v5h-5M4 17v-5h5M6 9a7 7 0 0 1 12-2l2 5M4 12l2 5a7 7 0 0 0 12-2"/>',
    'chevron-down':'<path d="m6 9 6 6 6-6"/>', 'x':'<path d="M5 5 19 19M19 5 5 19"/>',
    'paw-print':'<ellipse cx="12" cy="16" rx="6" ry="4"/><ellipse cx="5" cy="9" rx="1.8" ry="2.5"/><ellipse cx="10" cy="6" rx="1.8" ry="2.5"/><ellipse cx="15" cy="6" rx="1.8" ry="2.5"/><ellipse cx="20" cy="9" rx="1.8" ry="2.5"/>',
    'apple':'<path d="M12 8c-4-5-10-1-9 6s5 9 9 7c4 2 8 0 9-7S16 3 12 8zM12 8c-2-3-1-5 1-6m-1 6c2-4 5-4 7-3"/>',
    'car-front':'<path d="M5 11 7 5h10l2 6M5 11h14v8H5zM7 19v2m10-2v2M5 15h2m10 0h2M5 11h14"/>',
    'backpack':'<rect x="4" y="7" width="16" height="15" rx="5"/><path d="M8 7V5a4 4 0 0 1 8 0v2M8 15h8v5H8z"/>',
    'shapes':'<circle cx="7" cy="7" r="4"/><rect x="13" y="4" width="7" height="7" rx="1"/><path d="m12 14 7 8H5z"/>',
    'check':'<path d="m4 12 5 5L20 6"/>','medal':'<circle cx="12" cy="15" r="6"/><path d="m8 10-3-8h5l2 7 2-7h5l-3 8"/>',
    'lock':'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    'users':'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2zM17 6a3 3 0 0 1 0 6m1 3a5 5 0 0 1 3 5"/>',
    'award':'<circle cx="12" cy="8" r="6"/><path d="m8 13-2 9 6-3 6 3-2-9"/>',
    'calendar-days':'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M8 15h2m4 0h2"/>',
    'leaf':'<path d="M20 4C8 4 4 11 4 17a3 3 0 0 0 3 3c6 0 13-4 13-16zM4 20c4-6 8-9 13-11"/>',
    'check-circle':'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  };
  const icon = (name, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths['sparkles']}</svg>`;
  document.querySelectorAll('[data-icon]').forEach(el => el.innerHTML = icon(el.dataset.icon));

  const $ = id => document.getElementById(id);
  const safe = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const getPreference = (key, fallback) => { try { const val = localStorage.getItem('lb-' + key); return val === null ? fallback : JSON.parse(val); } catch { return fallback; } };
  const setPreference = (key, value) => { try { localStorage.setItem('lb-' + key, JSON.stringify(value)); } catch {} };
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const difficultyLabels = {easy:'Dễ', normal:'Bình thường', advanced:'Khá', hard:'Khó'};
  const badgeMap = {
    first_game:{name:'Bước chân đầu tiên',desc:'Hoàn thành ván chơi đầu tiên',symbol:'leaf'},
    five_games:{name:'Nhà thám hiểm',desc:'Hoàn thành 5 ván',symbol:'users'},
    ten_games:{name:'Siêu chăm chỉ',desc:'Hoàn thành 10 ván',symbol:'award'},
    three_stars:{name:'Ngôi sao sáng',desc:'Đạt 3 sao trong một ván',symbol:'star'},
    all_themes:{name:'Vòng quanh thế giới',desc:'Hoàn thành cả 5 chủ đề',symbol:'palette'},
    all_levels:{name:'Chinh phục thử thách',desc:'Hoàn thành cả 4 cấp độ Memory Match',symbol:'trophy'},
    logic_explorer:{name:'Nhà suy luận nhí',desc:'Hoàn thành một ván Tìm quy luật',symbol:'sparkles'},
    robot_pilot:{name:'Kỹ sư Robot',desc:'Giúp Robot đến đích trong một ván',symbol:'award'},
    three_worlds:{name:'Chinh phục 3 trò',desc:'Hoàn thành cả 3 game đang mở',symbol:'trophy'},
  };
  const state = {
    config:null, playerId:'PLAYER001', theme:getPreference('theme','animals'), difficulty:getPreference('difficulty','normal'),
    sound:getPreference('sound',true), reduceMotion:getPreference('reduced-motion',false),
    deck:[], opened:[], matched:0, attempts:0, mistakes:0, hints:0, locked:false,
    gameStarted:false, finished:false, savePending:false, startTime:0, seconds:0, timer:null,
    flipTimeout:null, hintTimeout:null, roundPromise:null, roundToken:null, generation:0,
    historyOffset:0, historyTotal:0, view:'hub', audio:null,
  };
  let pendingAction = null;
  let controlsBound = false;
  const jsonApi = async (action, body=null, params={}) => {
    const url = new URL('api/index.php', window.location.href);
    url.searchParams.set('action', action);
    Object.entries(params).forEach(([key,value]) => url.searchParams.set(key, String(value)));
    const opts = body === null ? {method:'GET'} : {method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)};
    let response;
    try { response = await fetch(url.toString(), {...opts, cache:'no-store', credentials:'same-origin'}); }
    catch { throw new Error('Không kết nối được PHP. Hãy kiểm tra máy chủ đã khởi động.'); }
    let parsed;
    try { parsed = await response.json(); }
    catch { throw new Error('Máy chủ trả về dữ liệu không hợp lệ.'); }
    if (!response.ok || !parsed.ok) throw new Error(parsed.error || 'Đã xảy ra lỗi.');
    return parsed.data;
  };

  function notify(message) {
    const el = document.createElement('div'); el.className='toast'; el.innerHTML=`${icon('sparkles')} <span>${safe(message)}</span>`;
    $('toast-stack').append(el);
    setTimeout(() => {el.classList.add('fade-out'); setTimeout(()=>el.remove(),250);}, 3800);
  }
  function playTone(kind) {
    if (!state.sound) return;
    try {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!Context) return;
      state.audio ||= new Context();
      if (state.audio.state === 'suspended') state.audio.resume().catch(()=>{});
      const notes = kind === 'win' ? [523,659,784,1047] : kind === 'correct' ? [660,880] : kind === 'wrong' ? [260,220] : [440];
      notes.forEach((freq,i) => {
        const start = state.audio.currentTime + i * (kind === 'win' ? .12 : .085);
        const osc=state.audio.createOscillator(), gain=state.audio.createGain();
        osc.type=kind==='wrong'?'sine':'triangle'; osc.frequency.value=freq;
        gain.gain.setValueAtTime(.0001,start); gain.gain.exponentialRampToValueAtTime(.065,start+.022); gain.gain.exponentialRampToValueAtTime(.0001,start+.22);
        osc.connect(gain); gain.connect(state.audio.destination); osc.start(start); osc.stop(start+.23);
      });
    } catch { /* Sound is optional; game must work without AudioContext. */ }
  }
  function toggleSound() {
    state.sound = !state.sound; setPreference('sound',state.sound);
    $('sound-toggle').innerHTML = icon(state.sound ? 'volume-2' : 'volume-x');
    $('sound-toggle').classList.toggle('off', !state.sound);
    $('sound-toggle').setAttribute('aria-pressed',String(state.sound));
    if (state.sound) playTone('tap');
  }
  function randomize(list) {
    for (let i=list.length-1;i>0;i--) {const j=Math.floor(Math.random()*(i+1)); [list[i],list[j]]=[list[j],list[i]];}
    return list;
  }
  function canWarn() { return state.gameStarted && !state.finished && !state.savePending && state.matched < (state.config?.difficulties[state.difficulty] || 0); }
  function requestChange(fn) {
    if (state.savePending) { notify('Đang lưu ván chơi, bé nhé!'); return; }
    if (!canWarn()) {fn();return;}
    pendingAction=fn;
    openModal(`<div class="modal-icon pink">${icon('refresh-cw')}</div><h2 id="modal-title">Bắt đầu thử thách mới?</h2><p class="modal-description">Ván đang chơi sẽ chưa được lưu. Bé có muốn chuyển sang ván mới không?</p><div class="modal-actions"><button class="outline-button" id="modal-cancel">Chơi tiếp</button><button class="primary-button" id="modal-confirm">Đổi ván mới ${icon('arrow-right')}</button></div>`);
    $('modal-cancel').onclick=closeModal;
    $('modal-confirm').onclick=()=>{const action=pendingAction; closeModal(); pendingAction=null; if(action)action();};
  }
  function openModal(content) {
    $('modal-content').innerHTML=content;
    $('modal-overlay').hidden=false;
    $('modal-close').focus();
  }
  function closeModal() { $('modal-overlay').hidden=true; pendingAction=null; }
  function updateControls() {
    document.querySelectorAll('.difficulty-button').forEach(b=> {const active=b.dataset.level===state.difficulty; b.classList.toggle('active',active);b.setAttribute('aria-pressed', String(active));});
    document.querySelectorAll('.theme-button').forEach(b=> {const active=b.dataset.theme===state.theme;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
    $('level-pill').innerHTML=`${icon('sparkles')} ${safe(difficultyLabels[state.difficulty])} · ${state.config.difficulties[state.difficulty]*2} ô`;
  }
  function makeThemes() {
    $('theme-options').innerHTML=Object.entries(state.config.themes).map(([key,theme])=>
      `<button class="theme-button" data-theme="${safe(key)}" type="button" aria-pressed="false"><span class="theme-thumb"><img src="${safe(theme.items[0].src)}" alt="" loading="lazy"></span><span class="theme-text"><b>${safe(theme.label)}</b><small>${safe(theme.subtitle)}</small></span><span class="theme-tick">${icon('check')}</span></button>`
    ).join('');
    $('theme-options').querySelectorAll('[data-theme]').forEach(b=>b.addEventListener('click',()=>{
      if (b.dataset.theme===state.theme) return;
      requestChange(()=>{state.theme=b.dataset.theme;setPreference('theme',state.theme);resetGame();});
    }));
  }
  function makeProfiles() {
    $('player-select').innerHTML=state.config.players.map(p=>`<option value="${safe(p.id)}" ${p.id===state.playerId?'selected':''}>${safe(p.name)}</option>`).join('');
    const selected=state.config.players.find(p=>p.id===state.playerId);
    if ($('hub-player-label')) $('hub-player-label').textContent=selected ? `Chào ${selected.name}!` : 'Chào bạn nhỏ!';
  }
  function resetGame() {
    state.generation++;
    clearInterval(state.timer); clearTimeout(state.flipTimeout); clearTimeout(state.hintTimeout);
    state.timer=null; state.flipTimeout=null; state.hintTimeout=null;
    state.opened=[]; state.matched=0; state.attempts=0; state.mistakes=0; state.hints=0; state.seconds=0;
    state.locked=false; state.gameStarted=false; state.finished=false; state.savePending=false;
    state.roundPromise=null; state.roundToken=null; state.stars=0;
    const items=randomize([...state.config.themes[state.theme].items]).slice(0,state.config.difficulties[state.difficulty]);
    state.deck=randomize([...items,...items].map((item,index)=>({...item,cardId:index, matched:false, revealed:false})));
    renderBoard(); updateControls(); updateStats(); $('memory-board').setAttribute('aria-busy','false');
  }
  function renderBoard() {
    const n=state.deck.length;
    $('memory-board').dataset.level=state.difficulty;
    $('memory-board').innerHTML=state.deck.map((c,index)=>`<button type="button" class="memory-card" data-index="${index}" aria-label="Thẻ số ${index+1}, đang úp" aria-pressed="false"><span class="card-inner"><span class="card-face card-back"><span class="question-mark">?</span><span class="card-mini-star star-a">✦</span><span class="card-mini-star star-b">✧</span></span><span class="card-face card-front"><img draggable="false" src="${safe(c.src)}" alt="${safe(c.label)}"></span></span></button>`).join('');
  }
  function updateStats() {
    const pairs=state.config.difficulties[state.difficulty];
    $('stat-matches').innerHTML=`${state.matched}<span class="stat-total">/${pairs}</span>`;
    $('stat-attempts').textContent=String(state.attempts);
    $('stat-time').textContent=formatTime(state.seconds);
    $('stat-stars').textContent=state.finished ? '★'.repeat(state.stars) + '☆'.repeat(3-state.stars) : '☆☆☆';
    $('progress-label').textContent=`${state.matched} / ${pairs} cặp`;
    $('progress-fill').style.width=`${100*state.matched/pairs}%`;
    $('hint-button').disabled=state.finished || state.savePending || state.locked || state.matched===pairs;
    $('restart-button').disabled=state.savePending;
  }
  const formatTime = secs => `${String(Math.floor(secs/60)).padStart(2,'0')}:${String(secs%60).padStart(2,'0')}`;
  function beginRound() {
    if (state.gameStarted) return;
    state.gameStarted=true;
    state.startTime=performance.now();
    state.timer=setInterval(()=>{state.seconds=Math.floor((performance.now()-state.startTime)/1000);$('stat-time').textContent=formatTime(state.seconds);},250);
    const generation=state.generation;
    state.roundPromise=jsonApi('start',{theme:state.theme,difficulty:state.difficulty,player_id:state.playerId}).then(data=>{
      if (generation===state.generation) state.roundToken=data.round_token;
      return data;
    }).catch(error=>{if (generation===state.generation) notify(error.message+' Không thể lưu ván này.'); throw error;});
    // Avoid browser unhandled-rejection reporting while finish awaits this promise.
    state.roundPromise.catch(()=>{});
  }
  function reveal(index, on) {
    const card=state.deck[index], node=$('memory-board').querySelector(`[data-index="${index}"]`);
    if (!node) return;
    card.revealed=on;
    node.classList.toggle('flipped',on);
    node.setAttribute('aria-pressed',String(on));
    node.setAttribute('aria-label',on?`Thẻ số ${index+1}: ${card.label}`:`Thẻ số ${index+1}, đang úp`);
  }
  function onCardClick(index) {
    const card=state.deck[index];
    if (!card || state.locked || state.finished || state.savePending || card.revealed || card.matched) return;
    if (!state.gameStarted) beginRound();
    reveal(index,true);
    state.opened.push(index);
    if (state.opened.length!==2) return;
    state.attempts++;
    const [firstIndex,secondIndex]=state.opened;
    if (state.deck[firstIndex].id===state.deck[secondIndex].id) {
      state.deck[firstIndex].matched=true; state.deck[secondIndex].matched=true;
      // Keep the original grid positions. CSS animates matched cards away, leaving empty cells.
      // No timeout is necessary, so restarting cannot cause a previous pair to disappear in a new game.
      for (const idx of [firstIndex,secondIndex]) {
        const node=$('memory-board').querySelector(`[data-index="${idx}"]`);
        if (!node) continue;
        node.blur();
        node.disabled=true;
        node.setAttribute('aria-hidden','true');
        node.classList.add('matched');
      }
      state.matched++; state.opened=[]; playTone('correct');
      if (state.matched===state.config.difficulties[state.difficulty]) {
        state.finished=true; state.seconds=Math.floor((performance.now()-state.startTime)/1000);
        clearInterval(state.timer); state.timer=null;
        state.savePending=true; updateStats(); completeRound(state.generation);
      }
    } else {
      state.mistakes++; state.locked=true; playTone('wrong');
      const generation=state.generation;
      state.flipTimeout=setTimeout(()=>{
        if (generation!==state.generation) return;
        reveal(firstIndex,false);reveal(secondIndex,false);
        state.opened=[];state.locked=false; updateStats();
      },1000);
    }
    updateStats();
  }
  function showHint() {
    if (state.locked || state.finished || state.savePending || !state.config) return;
    if (state.opened.length > 0) { notify('Bé hãy chọn đủ hai thẻ trước khi xem gợi ý nhé!'); return; }
    const buckets=new Map();
    state.deck.forEach((card,index)=>{
      if (!card.matched && !card.revealed) {
        if(!buckets.has(card.id)) buckets.set(card.id,[]);
        buckets.get(card.id).push(index);
      }
    });
    const options=[...buckets.values()].filter(indices=>indices.length===2);
    if (!options.length) return;
    const [one,two]=options[Math.floor(Math.random()*options.length)];
    state.hints++; state.locked=true;
    reveal(one,true); reveal(two,true);
    $('hint-button').disabled=true;
    const generation=state.generation;
    state.hintTimeout=setTimeout(()=>{
      if (generation!==state.generation) return;
      reveal(one,false); reveal(two,false);state.locked=false; updateStats();
    },1400);
  }
  async function completeRound(generation) {
    let record;
    try {
      const started=await state.roundPromise;
      if (generation!==state.generation) return;
      record=await jsonApi('finish',{round_token:started.round_token,attempts:state.attempts,mistakes:state.mistakes,hints_used:state.hints,duration_seconds:state.seconds});
    } catch (e) {
      if (generation!==state.generation) return;
      state.savePending=false;updateStats();
      openModal(`<div class="modal-icon pink">${icon('history')}</div><h2 id="modal-title">Chưa lưu được kết quả</h2><p class="modal-description">${safe(e.message)}. Bé đã hoàn thành ván này; hãy thử lưu lại nhé!</p><div class="modal-actions"><button class="outline-button" id="save-cancel">Đóng</button><button class="primary-button" id="save-retry">Lưu lại ${icon('refresh-cw')}</button></div>`);
      $('save-cancel').onclick=closeModal;
      $('save-retry').onclick=()=>{closeModal();state.savePending=true;updateStats();completeRound(generation);};
      return;
    }
    if (generation!==state.generation) return;
    state.savePending=false;state.stars=record.stars; updateStats();playTone('win'); celebrate();
    openModal(`<div class="result-illustration"><img src="assets/images/animals/bear.webp" alt="Gấu chúc mừng"></div><div class="eyebrow result-eyebrow">HOAN HÔ BÉ YÊU!</div><h2 id="modal-title">Tuyệt vời quá!</h2><p class="modal-description">Bé đã tìm đúng tất cả <b>${record.total_pairs} cặp hình</b> rồi!</p><div class="result-stars">${'★'.repeat(record.stars)}<span>${'☆'.repeat(3-record.stars)}</span></div><div class="result-stats"><div><b>${record.attempts}</b><span>Lượt thử</span></div><div><b>${formatTime(record.duration_seconds)}</b><span>Thời gian</span></div><div><b>${Number(record.accuracy).toFixed(1)}%</b><span>Chính xác</span></div></div><p class="saved-message">${icon('check-circle')} Đã lưu vào lịch sử của bé</p><div class="modal-actions"><button class="outline-button" id="result-history">Xem lịch sử</button><button class="primary-button" id="result-play">Chơi tiếp ${icon('arrow-right')}</button></div>`);
    $('result-play').onclick=()=>{closeModal();resetGame();};
    $('result-history').onclick=()=>{closeModal();navigate('history');};
  }
  function celebrate() {
    const host=$('confetti-layer');host.innerHTML='';
    if (state.reduceMotion) return;
    const palette=['#fac96c','#9ddcd2','#d1b7fa','#f4aebe','#8ebefa'];
    for (let i=0;i<40;i++) {
      const bit=document.createElement('i');bit.className='confetti-bit';
      bit.style.left=`${Math.random()*100}%`;bit.style.background=palette[i%palette.length];
      bit.style.animationDelay=`${Math.random()*.7}s`;bit.style.animationDuration=`${2+Math.random()*1.9}s`;
      host.append(bit);
    }
    setTimeout(()=>host.replaceChildren(),4800);
  }
  function navigate(view) {
    // Navigation only changes visible views. It never resets a Memory Match
    // round or touches its JSON history, even when the child visits the hub.
    if (!['hub','game','history','achievements'].includes(view)) return;
    state.view=view;
    document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${view}`));
    document.querySelectorAll('.nav-tab[data-view]').forEach(b=>{
      const active=b.dataset.view===view;
      b.classList.toggle('active',active);
      if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
    });
    if (view==='history') {state.historyOffset=0;loadHistory(true);}
    if (view==='achievements') loadAchievements();
    window.scrollTo({top:0,behavior:state.reduceMotion?'auto':'smooth'});
  }
  function emptyState(title,desc) {return `<div class="empty-state"><div class="empty-state-img"><img src="assets/images/animals/rabbit.webp" alt=""></div><h3>${safe(title)}</h3><p>${safe(desc)}</p><button type="button" class="primary-button" id="empty-play">Bắt đầu chơi ${icon('arrow-right')}</button></div>`;}
  async function loadHistory(firstPage=false) {
    const host=$('history-list');
    if(firstPage) {host.innerHTML='<div class="loading-line">Đang lấy nhật ký của bé...</div>'; $('load-more-history').hidden=true;}
    try {
      const data=await jsonApi('history',null,{player_id:state.playerId,limit:15,offset:state.historyOffset});
      if (state.view!=='history') return;
      state.historyTotal=data.total;state.historyOffset+=data.records.length;
      $('history-count').textContent=`${data.total} ván đã hoàn thành`;
      if (firstPage && data.total===0) {host.innerHTML=emptyState('Nhật ký còn trống','Chơi thử một ván để ghi lại khoảnh khắc đầu tiên nhé!'); $('empty-play').onclick=()=>navigate('game');return;}
      const html=data.records.map(r=>{
        const date=new Date(r.finished_at);
        const pretty=Number.isNaN(date.valueOf())?r.date:date.toLocaleString('vi-VN',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Ho_Chi_Minh'});
        const key=r.game_key||'memory-match';
        const theme=state.config.themes[r.theme];
        const extra=key==='pattern-logic'?{title:'Tìm quy luật',src:'assets/images/shapes/star.webp',detail:`${Number(r.total_steps||6)} câu`,attemptLabel:'Lượt chọn'}:
          key==='balance-puzzle'?{title:'C\u00e2n b\u1eb1ng th\u00f4ng minh',src:'assets/images/balance/scale.webp',detail:`${Number(r.total_steps||5)} b\u00e0i`,attemptLabel:'L\u01b0\u1ee3t ch\u1ecdn'}:
          key==='missing-number'?{title:'Tìm số bí mật',src:'assets/images/math/question.webp',detail:`${Number(r.total_steps||5)} câu`,attemptLabel:'Lượt chọn'}:
          key==='little-shop'?{title:'Siêu thị của bé',src:'assets/images/math/shop-bag.webp',detail:`${Number(r.total_steps||5)} đơn hàng`,attemptLabel:'Lượt trả lời'}:
          key==='poem-typing'?{title:'Bé chép thơ',src:'assets/images/objects/book.webp',detail:safe(r.poem_title||'Đoạn thơ'),attemptLabel:'Lượt kiểm tra'}:
          key==='daily-math-sharing'?{title:'Chia bánh cho bạn',src:'assets/images/daily-math/cookie.webp',detail:`${Number(r.total_steps||5)} bài · điểm danh`,attemptLabel:'Lượt chia'}:
          key==='robot-coder'?{title:'Bé lập trình Robot',src:'assets/images/robot/robot.webp',detail:`${Number(r.total_steps||5)} nhiệm vụ`,attemptLabel:'Lượt chạy'}:
          {title:theme?.label||'Memory Match',src:theme?.items[0]?.src||'assets/images/animals/cat.webp',detail:`${Number(r.total_pairs||0)} cặp`,attemptLabel:'Lượt thử'};
        return `<article class="history-row"><div class="history-theme-img"><img src="${safe(extra.src)}" alt=""></div><div class="history-info"><h3>${safe(extra.title)} <span class="history-difficulty">${safe(difficultyLabels[r.difficulty]||r.difficulty)}</span></h3><p>${icon('calendar-days')} ${safe(pretty)} · ${safe(extra.detail)} · ${Number(r.hints_used||0)} gợi ý</p></div><div class="history-metric"><b>${Number(r.attempts)}</b><span>${extra.attemptLabel}</span></div><div class="history-metric"><b>${formatTime(Number(r.duration_seconds))}</b><span>Thời gian</span></div><div class="history-metric"><b>${Number(r.accuracy).toFixed(1)}%</b><span>Chính xác</span></div><div class="history-stars">${'★'.repeat(r.stars)}<span>${'☆'.repeat(3-r.stars)}</span></div></article>`;
      }).join('');
      if(firstPage)host.innerHTML=html;else host.insertAdjacentHTML('beforeend',html);
      $('load-more-history').hidden=state.historyOffset>=data.total;
    } catch(error) {if(firstPage) host.innerHTML=`<div class="error-state">${safe(error.message)}</div>`; else notify(error.message);}
  }
  async function loadAchievements() {
    $('achievement-summary').innerHTML='<div class="loading-line">Đang chuẩn bị vườn sao...</div>';
    $('best-levels').innerHTML='';$('badges-grid').innerHTML='';$('logic-best-levels').innerHTML='';
    try {
      const a=await jsonApi('achievements',null,{player_id:state.playerId});
      if (state.view!=='achievements') return;
      $('achievement-summary').innerHTML=[
        {icon:'trophy',label:'Ván hoàn thành',value:a.total_games,color:'purple'},
        {icon:'star',label:'Sao tích lũy',value:a.total_stars,color:'yellow'},
        {icon:'sparkles',label:'Chính xác TB',value:`${Number(a.average_accuracy).toFixed(1)}%`,color:'blue'},
      ].map(x=>`<div class="achievement-card ${x.color}"><span class="achievement-card-icon">${icon(x.icon)}</span><span class="achievement-card-value">${x.value}</span><span class="achievement-card-label">${x.label}</span></div>`).join('');
      $('best-levels').innerHTML=Object.entries(state.config.difficulties).map(([level,pairs])=>{
        const b=a.best_by_level[level];
        return `<div class="best-level"><div class="best-level-name"><span class="best-dot"></span><div><b>${safe(difficultyLabels[level])}</b><small>${pairs*2} ô · ${pairs} cặp</small></div></div>${b?`<div class="best-level-result"><span class="gold-stars">${'★'.repeat(b.stars)}<span>${'☆'.repeat(3-b.stars)}</span></span><b>${Number(b.accuracy).toFixed(1)}%</b><small>${formatTime(b.duration_seconds)}</small></div>`:`<div class="not-played">Chưa chơi · Cùng thử nhé!</div>`}</div>`;
      }).join('');
      $('logic-best-levels').innerHTML=[
        {id:'pattern-logic',name:'Tìm quy luật',img:'assets/images/shapes/star.webp',steps:'6 câu'},
        {id:'robot-coder',name:'Bé lập trình Robot',img:'assets/images/robot/robot.webp',steps:'5 nhiệm vụ'},
        {id:'balance-puzzle',name:'C\u00e2n b\u1eb1ng th\u00f4ng minh',img:'assets/images/balance/scale.webp',steps:'5 b\u00e0i'},
        {id:'missing-number',name:'Tìm số bí mật',img:'assets/images/math/question.webp',steps:'5 câu'},
        {id:'little-shop',name:'Siêu thị của bé',img:'assets/images/math/shop-bag.webp',steps:'5 đơn hàng'},
        {id:'daily-math-sharing',name:'Chia bánh cho bạn',img:'assets/images/daily-math/cookie.webp',steps:'5 bài mỗi ngày'},
        {id:'poem-typing',name:'Bé chép thơ',img:'assets/images/objects/book.webp',steps:'1 bài thơ'}
      ].map(g=>{
        const levels=a.best_by_game?.[g.id]||{};
        return `<div class="logic-best-card"><div class="logic-best-head"><img src="${safe(g.img)}" alt=""><div><b>${safe(g.name)}</b><small>${safe(g.steps)} mỗi ván</small></div></div><div class="logic-best-level-row">${Object.keys(difficultyLabels).map(k=>{
          const best=levels[k];
          return `<div class="logic-best-item"><b>${safe(difficultyLabels[k])}</b><span>${best?'★'.repeat(best.stars)+'☆'.repeat(3-best.stars):'—'}</span><small>${best?Number(best.accuracy).toFixed(1)+'% · '+formatTime(best.duration_seconds):'Chưa chơi'}</small></div>`;
        }).join('')}</div></div>`;
      }).join('');
      $('badges-grid').innerHTML=Object.entries(badgeMap).map(([key,b])=>{
        const unlocked=a.badges.includes(key);
        return `<div class="badge-item ${unlocked?'unlocked':'locked'}"><div class="badge-illustration">${unlocked?icon(b.symbol):icon('lock')}</div><h3>${safe(b.name)}</h3><p>${safe(b.desc)}</p><span class="badge-status">${unlocked?'Đã mở khóa':'Chưa mở khóa'}</span></div>`;
      }).join('');
    }catch(error){ $('achievement-summary').innerHTML=`<div class="error-state">${safe(error.message)}</div>`;}
  }
  function openProfileModal() {
    openModal(`<div class="modal-icon purple">${icon('users')}</div><h2 id="modal-title">Thêm một bạn nhỏ</h2><p class="modal-description">Tạo hồ sơ riêng để lưu thành tích của từng bé.</p><form id="profile-form" class="profile-form"><label for="profile-name">Tên bé</label><input id="profile-name" name="name" type="text" autocomplete="off" maxlength="24" placeholder="Ví dụ: Bé Na" required><p class="input-hint">Tối đa 24 ký tự · Lưu dữ liệu trên máy này</p><div class="modal-actions"><button class="outline-button" type="button" id="profile-cancel">Để sau</button><button class="primary-button" id="profile-submit" type="submit">Tạo hồ sơ ${icon('check')}</button></div></form>`);
    $('profile-cancel').onclick=closeModal; $('profile-name').focus();
    $('profile-form').onsubmit=async event=>{
      event.preventDefault();const button=$('profile-submit');button.disabled=true;
      try {const profile=await jsonApi('create_profile',{name:$('profile-name').value});state.config.players.push(profile);state.playerId=profile.id;setPreference('player-id',profile.id);makeProfiles();closeModal();resetGame();notify(`Đã tạo hồ sơ cho ${profile.name}!`);}
      catch(error){notify(error.message);button.disabled=false;}
    };
  }
  function setMemoryPanelOpen(open) {
    const layout=$('memory-layout');
    layout.classList.toggle('sidebar-collapsed',!open);
    const toggle=$('memory-panel-toggle');
    toggle.setAttribute('aria-expanded',String(open));
    toggle.innerHTML=open?`${icon('x')} Đóng tùy chọn`:`${icon('sliders-horizontal')} Tùy chọn`;
  }
  function openSettings() {
    openModal(`<div class="modal-icon purple">${icon('settings')}</div><h2 id="modal-title">Cài đặt trò chơi</h2><p class="modal-description">Tùy chỉnh trải nghiệm phù hợp với bé.</p><div class="settings-shortcuts"><button type="button" data-view="history" class="outline-button">${icon('history')} Lịch sử</button><button type="button" data-view="achievements" class="outline-button">${icon('trophy')} Thành tích</button></div><div class="settings-list"><label class="setting-line"><span><b>Âm thanh vui nhộn</b><small>Giai điệu khi tìm đúng cặp hình</small></span><input id="setting-sound" type="checkbox" ${state.sound?'checked':''}><span class="toggle-control"></span></label><label class="setting-line"><span><b>Giảm chuyển động</b><small>Hạn chế hiệu ứng lật và pháo giấy</small></span><input id="setting-motion" type="checkbox" ${state.reduceMotion?'checked':''}><span class="toggle-control"></span></label></div><p class="settings-footer">Trò chơi hoạt động offline. Lịch sử và thành tích được lưu trong thư mục <code>data/</code> trên máy chạy PHP.</p><div class="modal-actions"><button id="settings-ok" class="primary-button">Xong ${icon('check')}</button></div>`);
    $('setting-sound').onchange=e=>{state.sound=e.target.checked;setPreference('sound',state.sound);$('sound-toggle').innerHTML=icon(state.sound?'volume-2':'volume-x');$('sound-toggle').classList.toggle('off',!state.sound);};
    $('setting-motion').onchange=e=>{state.reduceMotion=e.target.checked;setPreference('reduced-motion',state.reduceMotion);document.body.classList.toggle('reduce-motion',state.reduceMotion);};
    $('settings-ok').onclick=closeModal;
  }
  function bindControls() {
    $('memory-board').addEventListener('click',e=>{const b=e.target.closest('.memory-card');if(b)onCardClick(Number(b.dataset.index));});
    document.querySelectorAll('.difficulty-button').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.level===state.difficulty)return;requestChange(()=>{state.difficulty=b.dataset.level;setPreference('difficulty',state.difficulty);resetGame();});}));
    $('restart-button').addEventListener('click',()=>requestChange(resetGame));
    $('memory-panel-toggle').addEventListener('click',()=>setMemoryPanelOpen($('memory-layout').classList.contains('sidebar-collapsed')));
    $('memory-panel-close').addEventListener('click',()=>setMemoryPanelOpen(false));
    $('hint-button').addEventListener('click',showHint);
    $('sound-toggle').addEventListener('click',toggleSound);
    $('settings-toggle').addEventListener('click',openSettings);
    $('fullscreen-toggle').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{notify('Trình duyệt chưa hỗ trợ chế độ toàn màn hình.');}});
    // A single listener also supports new game launch cards and the home logo.
    // New games with an external URL need no JavaScript changes.
    document.addEventListener('click',event=>{
      const link=event.target.closest('[data-view]');
      if (link && !link.disabled) {
        if (link.tagName==='A')event.preventDefault();
        if (link.closest('#modal-overlay'))closeModal();
        navigate(link.dataset.view);
        return;
      }
      const scrollButton=event.target.closest('[data-scroll-target]');
      if (scrollButton) {
        const target=document.getElementById(scrollButton.dataset.scrollTarget);
        target?.scrollIntoView({behavior:state.reduceMotion?'auto':'smooth',block:'start'});
      }
    });
    window.addEventListener('hashchange',()=>{
      const page=({history:'history',achievements:'achievements',game:'game','memory-match':'game',hub:'hub'})[window.location.hash.slice(1)];
      if(page) navigate(page);
    });
    $('refresh-history').addEventListener('click',()=>{state.historyOffset=0;loadHistory(true);});
    $('load-more-history').addEventListener('click',()=>loadHistory());
    $('add-profile').addEventListener('click',()=>requestChange(openProfileModal));
    $('player-select').addEventListener('change',e=>{
      const wanted=e.target.value; e.target.value=state.playerId;
      if(wanted===state.playerId)return;
      requestChange(async()=>{
        try{await jsonApi('select_profile',{player_id:wanted});state.playerId=wanted;setPreference('player-id',wanted);makeProfiles();resetGame();document.dispatchEvent(new Event('littlebrain:profile-changed'));notify('Đã chuyển hồ sơ người chơi.');}
        catch(error){notify(error.message);makeProfiles();}
      });
    });
    $('modal-close').addEventListener('click',closeModal);
    $('modal-overlay').addEventListener('click',e=>{if(e.target===$('modal-overlay'))closeModal();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('modal-overlay').hidden)closeModal();});
  }
  async function initialize() {
    if (!controlsBound) {bindControls();controlsBound=true;}
    document.body.classList.toggle('reduce-motion',state.reduceMotion);
    $('sound-toggle').innerHTML=icon(state.sound?'volume-2':'volume-x');
    try {
      const config=await jsonApi('bootstrap');
      state.config=config;state.playerId=config.player_id;
      const remembered=getPreference('player-id',config.player_id);
      if (remembered!==config.player_id && config.players.some(p=>p.id===remembered)) {
        try {await jsonApi('select_profile',{player_id:remembered});state.playerId=remembered;} catch {}
      }
      if(!config.themes[state.theme])state.theme='animals';
      if(!config.difficulties[state.difficulty])state.difficulty='normal';
      makeProfiles();makeThemes();resetGame();
      (config.storage_alerts || []).forEach(message=>notify(message));
      const fromHash=({history:'history',achievements:'achievements',game:'game','memory-match':'game',hub:'hub'})[window.location.hash.slice(1)];
      if(fromHash) navigate(fromHash);
    }catch(error){
      $('memory-board').setAttribute('aria-busy','false');
      $('memory-board').innerHTML=`<div class="error-state"><h3>Chưa khởi động được trò chơi</h3><p>${safe(error.message)}</p><button class="outline-button" id="retry-init">Thử lại</button></div>`;
      $('retry-init').onclick=initialize;
    }
  }
  initialize();
})();
