/* LITTLE BRAIN Kids Mode: game discovery only.
   No game state, scoring, timer, API or localStorage keys are changed. */
'use strict';
(() => {
  function init() {
    const toolbar = document.querySelector('.kids-filter');
    if (!toolbar) return;
    const buttons = [...toolbar.querySelectorAll('[data-kids-filter]')];
    const cards = [...document.querySelectorAll('.hub-v2-available .hub-game-card[data-kids-category]')];
    const summary = document.querySelector('#kids-filter-status');
    const counts = Object.create(null);
    counts.all = cards.length;
    for (const card of cards) counts[card.dataset.kidsCategory] = (counts[card.dataset.kidsCategory] || 0) + 1;
    const allCount = toolbar.querySelector('[data-kids-filter="all"] span');
    if (allCount) allCount.textContent = String(counts.all);
    const labels = {logic:'Tư duy', math:'Toán học', language:'Tiếng Việt'};
    function choose(category) {
      const isValid = buttons.some(button => button.dataset.kidsFilter === category);
      if (!isValid) return;
      let visible = 0;
      for (const card of cards) {
        const show = category === 'all' || card.dataset.kidsCategory === category;
        card.hidden = !show;
        card.classList.toggle('kids-hide-card', !show);
        if (show) visible++;
      }
      for (const button of buttons) {
        const selected = button.dataset.kidsFilter === category;
        button.classList.toggle('active', selected);
        button.setAttribute('aria-pressed', String(selected));
      }
      if (summary) {
        summary.hidden = category === 'all';
        summary.textContent = category === 'all' ? '' : `${visible} trò chơi ${labels[category] || ''} cho bé khám phá`;
      }
    }
    for (const button of buttons) button.addEventListener('click', () => choose(button.dataset.kidsFilter));
    choose('all');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
