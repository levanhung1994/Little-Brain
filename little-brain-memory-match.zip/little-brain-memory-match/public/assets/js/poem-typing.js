'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const labels = {easy:'Dễ', normal:'Vừa', advanced:'Khá', hard:'Khó'};
  const state = {playerId:null,players:[],difficulty:'easy',lesson:null,ready:false,checking:false,
    generation:0,finished:false,seconds:0,timer:null,composing:false};
  try {const pref=localStorage.getItem('lb-typing-level');if(labels[pref])state.difficulty=pref;}catch{}
  if (new URLSearchParams(location.search).get('difficulty') === 'advanced') state.difficulty = 'advanced';
  const escapeHTML = s => String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const normalize = s => String(s).normalize('NFC').replace(/[\s\u00a0\ufeff]+/gu,' ').trim();
  const timestamp = n => `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
  async function api(action,body) {
    const url=new URL('../../api/index.php',location.href);url.searchParams.set('action',action);
    const options=body===undefined ? {cache:'no-store',credentials:'same-origin'} :
      {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)};
    let response,data;
    try {response=await fetch(url,options);data=await response.json();}
    catch {throw new Error('Không kết nối được PHP. Bé thử mở lại trang nhé!');}
    if(!response.ok || !data.ok) throw new Error(data.error || 'Có lỗi khi lưu kết quả.');
    return data.data;
  }
  function feedback(message,tone='neutral') {
    $('typing-feedback').textContent=message;
    $('typing-feedback').dataset.tone=tone;
  }
  function showModal(content) {
    $('typing-modal-content').innerHTML=content;
    $('typing-modal-overlay').hidden=false;
    $('typing-modal-close').focus();
  }
  function closeModal() {$('typing-modal-overlay').hidden=true;}
  function updateLevels() {
    document.querySelectorAll('[data-level]').forEach(button=>{
      const active=button.dataset.level===state.difficulty;
      button.classList.toggle('active',active);
      button.setAttribute('aria-pressed',String(active));
    });
    $('typing-level-label').textContent=labels[state.difficulty];
  }
  function updatePlayerList() {
    $('typing-player').innerHTML=state.players.map(p=>`<option value="${escapeHTML(p.id)}" ${p.id===state.playerId?'selected':''}>${escapeHTML(p.name)}</option>`).join('');
  }
  function drawProgress() {
    if(!state.lesson)return;
    const original=normalize(state.lesson.text);
    const typed=normalize($('typing-input').value);
    let match=0;
    while(match<original.length && match<typed.length && original[match]===typed[match]) match++;
    const percent=original.length ? Math.floor(match/original.length*100) : 0;
    $('typing-percent').textContent=`${percent}%`;
    $('typing-progress-fill').style.width=`${percent}%`;
    $('typing-char-count').textContent=`${$('typing-input').value.length} ký tự`;
    $('typing-editor-state').textContent=typed ? (typed===original?'Đã khớp!':'Đang luyện tập...') : 'Chưa bắt đầu';
    const text=state.lesson.text.normalize('NFC');
    // The poem only uses one ordinary whitespace character at each break,
    // so normalized indices map directly to display offsets.
    let visible=0, cutoff=0;
    for(let i=0;i<text.length;i++) {
      if (visible===match) break;
      cutoff=i+1;visible++;
    }
    $('typing-poem-text').innerHTML=`<span class="typing-done">${escapeHTML(text.slice(0,cutoff))}</span>`+
      (cutoff<text.length?`<span class="typing-next">${escapeHTML(text.slice(cutoff,cutoff+1))}</span>`:'')+
      escapeHTML(text.slice(cutoff+1));
    $('typing-check').disabled=!typed || state.checking || state.finished || !state.ready;
    return {expected:original,typed,percent};
  }
  function tick() {state.seconds++;$('typing-time').textContent=timestamp(state.seconds);}
  function stopClock(){clearInterval(state.timer);state.timer=null;}
  async function startLesson(ask=false) {
    if (ask && $('typing-input').value.trim() && !state.finished && !confirm('Bé muốn đổi sang bài thơ mới? Bài đang gõ sẽ không được lưu.'))return;
    const gen=++state.generation;state.ready=false;state.finished=false;state.checking=false;
    stopClock();state.seconds=0;$('typing-time').textContent='00:00';
    $('typing-new').disabled=true;$('typing-check').disabled=true;$('typing-input').disabled=true;
    feedback('Đang chuẩn bị bài thơ cho bé...');
    try {
      const data=await api('typing_start',{player_id:state.playerId,difficulty:state.difficulty});
      if(gen!==state.generation)return;
      state.lesson=data;state.ready=true;
      $('typing-poem-title').textContent=data.title;
      $('typing-poem-image').src=data.art;
      $('typing-poem-image').alt=`Minh họa ${data.title}`;
      $('typing-number').textContent=String(data.number);
      $('typing-input').value='';$('typing-input').disabled=false;
      $('typing-new').disabled=false;updateLevels();drawProgress();
      feedback('Nhìn mẫu rồi gõ nhé! 🌷');
      state.timer=setInterval(tick,1000);
      $('typing-input').focus();
    } catch(error) {
      if(gen!==state.generation)return;
      feedback(error.message,'warn');$('typing-new').disabled=false;
    }
  }
  function celebrateWin(record) {
    state.finished=true;stopClock();$('typing-input').disabled=true;drawProgress();
    feedback('Chúc mừng! Bé đã chép đúng toàn bộ bài thơ!','good');
    showModal(`<div class="typing-win-medal" aria-hidden="true">🏆</div>
      <h2 id="typing-modal-title">Chúc mừng bé!</h2>
      <p>Bé đã chép đúng hoàn toàn bài thơ <strong>${escapeHTML(state.lesson.title)}</strong>, kể cả dấu tiếng Việt và dấu câu!</p>
      <div class="typing-win-stats"><div><b>100%</b><small>Chính xác</small></div><div><b>${timestamp(Number(record.duration_seconds)||state.seconds)}</b><small>Thời gian</small></div><div><b>★★★</b><small>3 ngôi sao</small></div></div>
      <p>✓ Thành tích của bé đã được lưu vào lịch sử.</p>
      <div class="typing-win-buttons"><a href="../../index.php">Kho trò chơi</a><button type="button" id="typing-play-again">Chép bài mới →</button></div>`);
    $('typing-play-again').onclick=()=>{closeModal();startLesson(false);};
    document.dispatchEvent(new CustomEvent('littlebrain:game-completed', {detail:{game_key:'poem-typing',difficulty:state.difficulty}}));
  }
  async function checkPoem() {
    if(!state.ready || state.finished || state.checking || state.composing)return;
    const typed=$('typing-input').value;
    if(!normalize(typed))return;
    state.checking=true;$('typing-check').disabled=true;
    feedback('Đang kiểm tra bài...');
    const gen=state.generation;
    try {
      const result=await api('typing_check',{player_id:state.playerId,round_token:state.lesson.round_token,typed_text:typed});
      if(gen!==state.generation)return;
      if(result.matched)celebrateWin(result.record);
      else {
        drawProgress();
        feedback('Chưa đúng nhé! Bé xem lại chữ và dấu.','warn');
        $('typing-input').focus();
      }
    } catch(e) {
      if(gen===state.generation)feedback(e.message,'warn');
    } finally {
      if(gen===state.generation){state.checking=false;drawProgress();}
    }
  }
  function profileForm() {
    showModal(`<h2 id="typing-modal-title">Tạo hồ sơ cho bé</h2><p>Hãy nhập tên của bé nhé!</p>
      <form id="typing-profile-form"><label class="typing-form-label" for="typing-profile-name">Tên bé</label>
      <input class="typing-form-input" id="typing-profile-name" type="text" maxlength="24" autocomplete="off" required placeholder="Ví dụ: Bé Na">
      <div class="typing-win-buttons"><button type="submit">Lưu hồ sơ</button></div></form>`);
    $('typing-profile-form').onsubmit=async e=>{
      e.preventDefault();const name=$('typing-profile-name').value;
      try {
        const newProfile=await api('create_profile',{name});
        state.players.push(newProfile);state.playerId=newProfile.id;updatePlayerList();closeModal();
        $('typing-input').value='';await startLesson(false);
      } catch(err) {alert(err.message);}
    };
    $('typing-profile-name').focus();
  }
  async function init() {
    $('typing-input').addEventListener('compositionstart',()=>{state.composing=true;});
    $('typing-input').addEventListener('compositionend',()=>{state.composing=false;drawProgress();});
    $('typing-input').addEventListener('input',()=>{if(!state.composing)drawProgress();});
    $('typing-input').addEventListener('keydown',e=>{if(e.ctrlKey&&e.key==='Enter'){e.preventDefault();checkPoem();}});
    $('typing-check').onclick=checkPoem;
    $('typing-new').onclick=()=>startLesson(true);
    $('typing-options-toggle').onclick=()=>{const open=$('typing-options').hidden;$('typing-options').hidden=!open;$('typing-options-toggle').setAttribute('aria-expanded',String(open));};
    document.querySelectorAll('[data-level]').forEach(button=>button.onclick=async()=>{
      if(button.dataset.level===state.difficulty)return;
      if($('typing-input').value.trim()&&!state.finished&&!confirm('Bé muốn đổi cấp độ và bắt đầu bài mới?'))return;
      state.difficulty=button.dataset.level;
      try{localStorage.setItem('lb-typing-level',state.difficulty);}catch{}
      $('typing-options').hidden=true;$('typing-options-toggle').setAttribute('aria-expanded','false');
      await startLesson(false);
    });
    $('typing-add-player').onclick=profileForm;
    $('typing-player').onchange=async()=>{
      const id=$('typing-player').value;
      if(id===state.playerId)return;
      try {
        await api('select_profile',{player_id:id});state.playerId=id;await startLesson(false);
      } catch(err) {feedback(err.message,'warn');updatePlayerList();}
    };
    $('typing-modal-close').onclick=closeModal;
    $('typing-modal-overlay').onclick=e=>{if(e.target===$('typing-modal-overlay'))closeModal();};
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('typing-modal-overlay').hidden)closeModal();});
    try {
      const bootstrap=await api('bootstrap');state.players=bootstrap.players;state.playerId=bootstrap.player_id;
      updatePlayerList();await startLesson(false);
    } catch(err) {feedback(err.message,'warn');}
  }
  document.addEventListener('DOMContentLoaded',init);
})();
