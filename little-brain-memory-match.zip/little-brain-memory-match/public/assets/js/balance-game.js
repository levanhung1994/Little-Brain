'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const info = JSON.parse($('logic-config').textContent);
  const gameKey = 'balance-puzzle';
  if (info.gameKey !== gameKey || info.totalSteps !== 5) return;
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const levels = {easy:'D\u1ec5', normal:'V\u1eeba', advanced:'Kh\u00e1', hard:'Kh\u00f3'};
  const fruits = {
    apple:{mass:1,name:'t\u00e1o'},
    strawberry:{mass:1,name:'d\u00e2u'},
    banana:{mass:2,name:'chu\u1ed1i'},
    orange:{mass:3,name:'cam'},
    watermelon:{mass:4,name:'d\u01b0a h\u1ea5u'}
  };
  const allowed = {
    easy:['apple','strawberry'],
    normal:['apple','strawberry','banana'],
    advanced:['apple','strawberry','banana','orange'],
    hard:['apple','strawberry','banana','orange','watermelon']
  };
  // Each chapter has five specifically designed, verified weight equations.
  // L is the left pan, R the already loaded right pan, A the missing answer.
  const puzzles = {
    easy:[
      {L:{apple:2},R:{},A:{strawberry:2}},
      {L:{strawberry:3},R:{apple:1},A:{apple:2}},
      {L:{apple:3,strawberry:1},R:{apple:2},A:{strawberry:2}},
      {L:{apple:4},R:{strawberry:1},A:{apple:3}},
      {L:{apple:2,strawberry:1},R:{apple:2},A:{strawberry:1}}
    ],
    normal:[
      {L:{banana:1},R:{},A:{strawberry:2}},
      {L:{banana:1,apple:1},R:{apple:1},A:{banana:1}},
      {L:{banana:2},R:{banana:1},A:{apple:2}},
      {L:{banana:1,strawberry:2},R:{apple:1},A:{banana:1,strawberry:1}},
      {L:{banana:2,apple:1},R:{banana:1},A:{apple:1,banana:1}}
    ],
    advanced:[
      {L:{orange:1,apple:1},R:{banana:1},A:{strawberry:2}},
      {L:{orange:2},R:{banana:1},A:{orange:1,strawberry:1}},
      {L:{banana:2,strawberry:1},R:{strawberry:2},A:{orange:1}},
      {L:{orange:1,banana:1},R:{apple:2},A:{banana:1,apple:1}},
      {L:{orange:2,apple:1},R:{orange:1},A:{banana:2}}
    ],
    hard:[
      {L:{watermelon:1,orange:1},R:{banana:1},A:{orange:1,banana:1}},
      {L:{watermelon:2},R:{orange:1},A:{banana:2,apple:1}},
      {L:{watermelon:1,banana:2},R:{orange:1,apple:1},A:{watermelon:1}},
      {L:{watermelon:1,orange:1,apple:1},R:{banana:2},A:{strawberry:1,orange:1}},
      {L:{watermelon:2,strawberry:1},R:{orange:1,banana:1},A:{watermelon:1}}
    ]
  };
  const mass = group => Object.entries(group).reduce((n,[fruit,count])=>n+fruits[fruit].mass*count,0);
  const expanded = group => Object.entries(group).flatMap(([fruit,count])=>Array.from({length:count},()=>fruit));
  const getPref = (k,fallback) => { try {let v=localStorage.getItem('lb-'+k);return v===null?fallback:JSON.parse(v);}catch{return fallback;} };
  const setPref = (k,v) => {try{localStorage.setItem('lb-'+k,JSON.stringify(v));}catch{}};
  const escapeHTML = s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const state = {
    profiles:[],playerId:null,level:getPref(gameKey+'-level','easy'),
    sound:getPref('sound',true),reduceMotion:getPref('reduced-motion',false),
    stage:0,attempts:0,mistakes:0,hints:0,elapsed:0,
    started:false,finished:false,saving:false,busy:false,successPending:false,
    generation:0,startTime:0,startPromise:null,clock:null,timers:[],
    choices:[],question:null,picked:null,audio:null
  };
  if (new URLSearchParams(location.search).get('difficulty') === 'advanced') state.level = 'advanced';
  const api = async(action,body=null) => {
    const url = new URL('../../api/index.php',location.href);
    url.searchParams.set('action',action);
    let res;
    try {res=await fetch(url,body===null?{credentials:'same-origin',cache:'no-store'}:{
      method:'POST',credentials:'same-origin',cache:'no-store',
      headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)
    });}catch{throw new Error('Ch\u01b0a k\u1ebft n\u1ed1i \u0111\u01b0\u1ee3c PHP.');}
    let json;
    try{json=await res.json();}catch{throw new Error('D\u1eef li\u1ec7u tr\u1ea3 v\u1ec1 kh\u00f4ng h\u1ee3p l\u1ec7.');}
    if(!res.ok||!json.ok)throw new Error(json.error||'C\u00f3 l\u1ed7i x\u1ea3y ra.');
    return json.data;
  };
  function shuffle(array){for(let i=array.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[array[i],array[j]]=[array[j],array[i]];}return array;}
  function schedule(fn,ms){const id=setTimeout(()=>{state.timers=state.timers.filter(t=>t!==id);fn();},ms);state.timers.push(id);}
  function cancelTimers(){state.timers.forEach(clearTimeout);state.timers=[];clearInterval(state.clock);state.clock=null;}
  function timeText(n){return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
  function notify(msg){const el=$('logic-toast');el.textContent=msg;el.hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>el.hidden=true,3100);}
  function feedback(msg,tone='neutral'){$('logic-feedback').textContent=msg;$('logic-feedback').dataset.tone=tone;}
  function inlineFeedback(msg,tone='neutral'){$('balance-inline-feedback').textContent=msg;$('balance-inline-feedback').dataset.tone=tone;}
  function playSound(kind){
    if(!state.sound)return;
    try {
      const Context=window.AudioContext||window.webkitAudioContext;
      if(!Context)return;
      state.audio ||= new Context();if(state.audio.state==='suspended')state.audio.resume().catch(()=>{});
      const notes=kind==='win'?[523,659,784,988]:kind==='correct'?[630,795]:kind==='wrong'?[365,320]:[540];
      notes.forEach((freq,i)=>{
        const t=state.audio.currentTime+i*.105,osc=state.audio.createOscillator(),gain=state.audio.createGain();
        osc.type='sine';osc.frequency.value=freq;
        gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.055,t+.018);gain.gain.exponentialRampToValueAtTime(.0001,t+.22);
        osc.connect(gain);gain.connect(state.audio.destination);osc.start(t);osc.stop(t+.23);
      });
    }catch{}
  }
  function modal(html){$('logic-modal-body').innerHTML=html;$('logic-modal').hidden=false;$('logic-modal-close').focus();}
  function closeModal(){
    $('logic-modal').hidden=true;
    if(state.successPending){state.successPending=false;goNext();}
  }
  function askChange(fn){
    if(state.saving){notify('K\u1ebft qu\u1ea3 \u0111ang \u0111\u01b0\u1ee3c l\u01b0u!');return;}
    if(!state.started||state.finished){fn();return;}
    modal(`<div class="result-mark">&#8635;</div><h2 id="logic-modal-title">Ch\u01a1i v\u00e1n m\u1edbi?</h2><p>V\u00e1n hi\u1ec7n t\u1ea1i s\u1ebd kh\u00f4ng \u0111\u01b0\u1ee3c l\u01b0u.</p><div class="logic-modal-actions"><button class="logic-soft-button" id="balance-stay">Ch\u01a1i ti\u1ebfp</button><button class="logic-main-button" id="balance-change">\u0110\u1ed5i v\u00e1n</button></div>`);
    $('balance-stay').onclick=closeModal;
    $('balance-change').onclick=()=>{closeModal();fn();};
  }
  function setPanel(open){
    $('logic-workspace').classList.toggle('sidebar-collapsed',!open);
    $('logic-panel-toggle').setAttribute('aria-expanded',String(open));
    $('logic-panel-toggle').textContent=open?'\u2715 \u0110\u00f3ng t\u00f9y ch\u1ecdn':'\u2699 T\u00f9y ch\u1ecdn';
  }
  function makeProfiles(){
    const select=$('logic-player');select.replaceChildren();
    state.profiles.forEach(player=>{const o=document.createElement('option');o.value=player.id;o.textContent=player.name;select.appendChild(o);});
    select.value=state.playerId;
  }
  function createProfile(){
    modal(`<h2 id="logic-modal-title">Th\u00eam h\u1ed3 s\u01a1 b\u00e9</h2><form class="logic-profile-form" id="balance-profile-form"><label for="balance-profile-name">T\u00ean b\u00e9</label><input type="text" id="balance-profile-name" required maxlength="24" autocomplete="off"><div class="logic-modal-actions"><button type="button" class="logic-soft-button" id="balance-profile-cancel">H\u1ee7y</button><button type="submit" class="logic-main-button" id="balance-profile-save">L\u01b0u</button></div></form>`);
    $('balance-profile-cancel').onclick=closeModal;
    $('balance-profile-name').focus();
    $('balance-profile-form').onsubmit=async e=>{
      e.preventDefault();const btn=$('balance-profile-save');btn.disabled=true;
      try {const player=await api('create_profile',{name:$('balance-profile-name').value});state.profiles.push(player);state.playerId=player.id;setPref('player-id',player.id);makeProfiles();closeModal();newRound();notify('T\u1ea1o h\u1ed3 s\u01a1 th\u00e0nh c\u00f4ng!');}
      catch(err){notify(err.message);btn.disabled=false;}
    };
  }
  function begin(){
    if(state.started)return;
    state.started=true;state.startTime=performance.now();
    state.clock=setInterval(()=>{state.elapsed=Math.min(86400,Math.floor((performance.now()-state.startTime)/1000));$('logic-time').textContent=timeText(state.elapsed);},250);
    const gen=state.generation;
    state.startPromise=api('start_challenge',{game_key:gameKey,difficulty:state.level,player_id:state.playerId}).catch(e=>{if(gen===state.generation)notify('Ch\u01b0a l\u01b0u \u0111\u01b0\u1ee3c: '+e.message);throw e;});
    state.startPromise.catch(()=>{});
  }
  function combinations(level){
    const keys=allowed[level],found=[];
    function extend(start,combos){
      if(combos.length){
        const group={};combos.forEach(k=>group[k]=(group[k]||0)+1);
        if(mass(group)<=12)found.push(group);
      }
      if(combos.length===4)return;
      for(let i=start;i<keys.length;i++)extend(i,[...combos,keys[i]]);
    }
    extend(0,[]);
    return found;
  }
  const pools=Object.fromEntries(Object.keys(levels).map(level=>[level,combinations(level)]));
  function createChoices(){
    const answer=state.question.A,required=mass(answer),pool=pools[state.level];
    const available=[...new Set(pool.map(mass))].filter(n=>n!==required).sort((a,b)=>{
      const av=Math.abs(a-required),bv=Math.abs(b-required);
      return av-bv||a-b;
    });
    const nearest=shuffle(available.slice(0,5)).slice(0,3);
    if(nearest.length!==3)throw new Error('Not enough distinct weights for answers');
    const distractors=nearest.map(target=>{
      const eligible=pool.filter(g=>mass(g)===target);
      const limited=eligible.filter(g=>expanded(g).length<=3);
      const choices=limited.length?limited:eligible;
      return choices[Math.floor(Math.random()*choices.length)];
    });
    const cards=shuffle([answer,...distractors]);
    if(cards.filter(g=>mass(g)===required).length!==1)throw new Error('Ambiguous puzzle');
    return cards;
  }
  function guide(){
    $('balance-guide').innerHTML='<span class="balance-guide-caption">Tr\u1ecdng l\u01b0\u1ee3ng:</span>'+allowed[state.level].map(key=>{
      const item=fruits[key];
      return `<div class="balance-guide-item"><img src="../../assets/images/fruits/${key}.webp" alt="${item.name}"><span class="guide-equals">=</span><span class="balance-unit-dots">${'\u25cf'.repeat(item.mass)}</span></div>`;
    }).join('');
  }
  function fillSVG(id,group,center,missing=false){
    const el=$(id);el.replaceChildren();const items=expanded(group);
    if(missing){
      const circle=document.createElementNS('http://www.w3.org/2000/svg','circle');circle.setAttribute('cx',String(center));circle.setAttribute('cy','237');circle.setAttribute('r','34');circle.setAttribute('fill','#fffcf2');circle.setAttribute('stroke','#efc980');circle.setAttribute('stroke-width','3');circle.setAttribute('stroke-dasharray','6 5');el.appendChild(circle);
      const label=document.createElementNS('http://www.w3.org/2000/svg','text');label.setAttribute('x',String(center));label.setAttribute('y','253');label.setAttribute('text-anchor','middle');label.setAttribute('font-size','49');label.setAttribute('font-weight','900');label.setAttribute('fill','#eab66a');label.textContent='?';el.appendChild(label);
    }
    if(!items.length)return;
    const size=items.length<=2?91:items.length===3?73:61;
    const spacing=items.length===1?0:Math.min(size*.82,163/(items.length-1));
    items.forEach((item,i)=>{
      const x=center-(items.length-1)*spacing/2-size/2+i*spacing;
      const image=document.createElementNS('http://www.w3.org/2000/svg','image');
      image.setAttribute('href',`../../assets/images/fruits/${item}.webp`);
      image.setAttribute('x',x.toFixed(1));image.setAttribute('y',String(289-size));
      image.setAttribute('width',String(size));image.setAttribute('height',String(size));
      el.appendChild(image);
    });
  }
  function drawScale(selected=null){
    const q=state.question;if(!q)return;
    const right={...q.R};
    if(selected)Object.entries(selected).forEach(([key,n])=>right[key]=(right[key]||0)+n);
    const difference=mass(right)-mass(q.L);
    const angle=Math.max(-13,Math.min(13,difference*4));
    fillSVG('balance-left-fruits',q.L,180,false);
    fillSVG('balance-right-fruits',right,720,!selected);
    $('balance-moving').style.transform=`rotate(${angle}deg)`;
    $('balance-scale').setAttribute('aria-label',`B\u00ean tr\u00e1i ${mass(q.L)} \u0111\u01a1n v\u1ecb, b\u00ean ph\u1ea3i ${mass(right)} \u0111\u01a1n v\u1ecb`);
    $('balance-scale').classList.toggle('balanced',Boolean(selected)&&difference===0);
  }
  function makeCards(){
    state.choices=createChoices();
    $('balance-options').innerHTML=state.choices.map((g,i)=>{
      const images=expanded(g).map(k=>`<img src="../../assets/images/fruits/${k}.webp" alt="${fruits[k].name}" draggable="false">`).join('');
      const name=expanded(g).map(k=>fruits[k].name).join(', ');
      return `<button class="balance-option" type="button" data-choice="${i}" aria-label="Nh\u00f3m ${i+1}: ${escapeHTML(name)}"><span class="balance-option-number">${String.fromCharCode(65+i)}</span><span class="balance-option-fruits">${images}</span><span class="balance-option-chevron">\u279c</span></button>`;
    }).join('');
  }
  function setOptionsDisabled(disabled){
    $('balance-options').querySelectorAll('.balance-option').forEach(btn=>btn.disabled=disabled);
  }
  function showPuzzle(){
    state.question=puzzles[state.level][state.stage];state.busy=false;state.picked=null;
    $('balance-question-number').textContent=String(state.stage+1);
    $('balance-task-name').textContent='Ch\u1ecdn nh\u00f3m qu\u1ea3 c\u00f2n thi\u1ebfu';
    guide();makeCards();drawScale();inlineFeedback('');updateStats();
    feedback('H\u00e3y nh\u00ecn c\u00e1c ch\u1ea5m tr\u1ecdng l\u01b0\u1ee3ng v\u00e0 ch\u1ecdn nh\u00f3m qu\u1ea3 nh\u00e9!');
  }
  function updateStats(){
    $('logic-progress-stat').textContent=`${state.stage}/5`;
    $('logic-attempts').textContent=String(state.attempts);
    $('logic-time').textContent=timeText(state.elapsed);
    $('logic-step-dots').innerHTML=Array.from({length:5},(_,i)=>`<i class="${i<state.stage?'done':i===state.stage?'current':''}"></i>`).join('');
    $('logic-stage-label').textContent=state.finished?'Ho\u00e0n th\u00e0nh 5 / 5':`B\u00e0i ${Math.min(state.stage+1,5)} / 5`;
    $('logic-level-tag').textContent='\u2726 '+levels[state.level];
    $('logic-hint').disabled=state.busy||state.saving||state.finished||!state.playerId;
    $('logic-restart').disabled=state.saving;
    document.querySelectorAll('[data-level]').forEach(btn=>{const active=btn.dataset.level===state.level;btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));});
  }
  function newRound(){
    state.generation++;cancelTimers();
    state.stage=0;state.attempts=0;state.mistakes=0;state.hints=0;state.elapsed=0;state.started=false;
    state.finished=false;state.busy=false;state.saving=false;state.successPending=false;state.startPromise=null;
    $('logic-stars').textContent='\u2606\u2606\u2606';
    showPuzzle();
  }
  function choose(i){
    if(!state.question||state.busy||state.finished||state.saving||!state.playerId)return;
    const choice=state.choices[i];if(!choice)return;
    begin();state.attempts++;state.busy=true;state.picked=i;
    setOptionsDisabled(true);
    const ok=mass(state.question.R)+mass(choice)===mass(state.question.L);
    const button=$('balance-options').querySelector(`[data-choice="${i}"]`);
    button?.classList.add(ok?'choice-success':'choice-error');
    drawScale(choice);updateStats();
    if(ok){
      playSound('correct');inlineFeedback('C\u00e2n th\u0103ng b\u1eb1ng r\u1ed3i! \ud83c\udf1f','good');
      feedback('C\u00e2n th\u0103ng b\u1eb1ng r\u1ed3i! B\u00e9 gi\u1ecfi qu\u00e1!','good');
      schedule(showSuccess,state.reduceMotion?80:950);
    }else{
      state.mistakes++;playSound('wrong');
      inlineFeedback('C\u00e2n v\u1eabn nghi\u00eang. B\u00e9 th\u1eed nh\u00f3m kh\u00e1c nh\u00e9!','try');
      feedback('B\u00e9 h\u00e3y th\u1eed l\u1ea1i nh\u00e9!','try');
      schedule(()=>{if(!state.finished){drawScale();state.busy=false;setOptionsDisabled(false);button?.classList.remove('choice-error');updateStats();}},state.reduceMotion?100:1250);
    }
  }
  function showSuccess(){
    if(state.successPending||state.finished)return;
    state.successPending=true;
    const last=state.stage===4;
    modal(`<div class="result-mark balance-win-mark">\ud83c\udf1f</div><h2 id="logic-modal-title">${last?'Xu\u1ea5t s\u1eafc!':'Ch\u00fac m\u1eebng b\u00e9!'}</h2><p>Hai \u0111\u0129a c\u00e2n \u0111\u00e3 th\u0103ng b\u1eb1ng!</p><div class="balance-success-progress">${last?'\ud83c\udfc6 \u0110\u00e3 xong 5 b\u00e0i':'\u2713 B\u00e0i '+(state.stage+1)+' / 5'}</div><div class="logic-modal-actions"><button class="logic-main-button" id="balance-next">${last?'Xem th\u00e0nh t\u00edch':'B\u00e0i ti\u1ebfp theo \u2192'}</button></div>`);
    $('balance-next').onclick=closeModal;
    $('balance-next').focus();
  }
  function goNext(){
    if(state.finished||state.saving)return;
    state.stage++;
    if(state.stage>=5){updateStats();finish();}
    else showPuzzle();
  }
  async function finish(){
    if(state.finished||state.saving||state.stage!==5)return;
    state.finished=true;state.saving=true;state.busy=true;
    state.elapsed=Math.min(86400,Math.floor((performance.now()-state.startTime)/1000));
    clearInterval(state.clock);state.clock=null;updateStats();
    const gen=state.generation;
    try {
      const initial=await state.startPromise;
      if(gen!==state.generation)return;
      const result=await api('finish_challenge',{
        round_token:initial.round_token,attempts:state.attempts,mistakes:state.mistakes,
        hints_used:state.hints,duration_seconds:state.elapsed
      });
      if(gen!==state.generation)return;
      state.saving=false;state.busy=false;updateStats();playSound('win');
      $('logic-stars').textContent='\u2605'.repeat(result.stars)+'\u2606'.repeat(3-result.stars);
      feedback('Hoan h\u00f4! B\u00e9 \u0111\u00e3 ho\u00e0n th\u00e0nh 5 b\u00e0i c\u00e2n!','good');
      modal(`<div class="result-mark balance-win-mark">\ud83c\udfc6</div><h2 id="logic-modal-title">B\u00e9 si\u00eau qu\u00e1!</h2><p>Ho\u00e0n th\u00e0nh c\u1ea3 5 b\u00e0i c\u00e2n b\u1eb1ng!</p><div class="result-big-stars">${'\u2605'.repeat(result.stars)}<span>${'\u2606'.repeat(3-result.stars)}</span></div><div class="result-overview"><div><b>${result.attempts}</b><small>L\u01b0\u1ee3t ch\u1ecdn</small></div><div><b>${timeText(result.duration_seconds)}</b><small>Th\u1eddi gian</small></div><div><b>${Number(result.accuracy).toFixed(1)}%</b><small>Ch\u00ednh x\u00e1c</small></div></div><p class="result-saved">\u2713 \u0110\u00e3 l\u01b0u th\u00e0nh t\u00edch</p><div class="logic-modal-actions"><a class="logic-soft-button" href="../../index.php#history">L\u1ecbch s\u1eed</a><button class="logic-main-button" id="balance-again">Ch\u01a1i ti\u1ebfp \u2192</button></div>`);
      $('balance-again').onclick=()=>{closeModal();newRound();};
      document.dispatchEvent(new CustomEvent('littlebrain:game-completed', {detail:{game_key:gameKey,difficulty:state.level}}));
    }catch(err){
      if(gen!==state.generation)return;
      state.saving=false;state.busy=false;updateStats();
      modal(`<div class="result-mark">\ud83d\udc9b</div><h2 id="logic-modal-title">B\u00e9 \u0111\u00e3 l\u00e0m xong!</h2><p>Ch\u01b0a l\u01b0u \u0111\u01b0\u1ee3c: ${escapeHTML(err.message)}</p><div class="logic-modal-actions"><button class="logic-main-button" id="balance-retry">Th\u1eed l\u01b0u l\u1ea1i</button></div>`);
      $('balance-retry').onclick=()=>{closeModal();state.finished=false;finish();};
    }
  }
  function hint(){
    if(state.finished||state.busy||state.saving||!state.playerId)return;
    begin();state.hints++;
    const left=mass(state.question.L),right=mass(state.question.R);
    const needed=left-right;
    inlineFeedback(`\u2600 G\u1ee3i \u00fd: b\u00ean tr\u00e1i ${left} ch\u1ea5m, b\u00ean ph\u1ea3i ${right} ch\u1ea5m. C\u1ea7n th\u00eam ${needed} ch\u1ea5m n\u1eefa!`,'hint');
    playSound('tap');
  }
  function bind(){
    $('logic-panel-toggle').onclick=()=>setPanel($('logic-workspace').classList.contains('sidebar-collapsed'));
    $('logic-sidebar-close').onclick=()=>setPanel(false);
    $('logic-add-profile').onclick=()=>askChange(createProfile);
    $('logic-restart').onclick=()=>askChange(newRound);
    $('logic-hint').onclick=hint;
    $('logic-levels').addEventListener('click',e=>{
      const btn=e.target.closest('[data-level]');if(!btn||btn.dataset.level===state.level)return;
      askChange(()=>{state.level=btn.dataset.level;setPref(gameKey+'-level',state.level);newRound();});
    });
    $('logic-player').onchange=e=>{
      const requested=e.target.value;e.target.value=state.playerId;
      if(requested===state.playerId)return;
      askChange(async()=>{
        try{await api('select_profile',{player_id:requested});state.playerId=requested;setPref('player-id',requested);makeProfiles();newRound();notify('Ch\u1ecdn h\u1ed3 s\u01a1 th\u00e0nh c\u00f4ng!');}
        catch(err){notify(err.message);makeProfiles();}
      });
    };
    $('balance-options').onclick=e=>{
      const button=e.target.closest('[data-choice]');if(button)choose(Number(button.dataset.choice));
    };
    $('logic-sound').onclick=()=>{state.sound=!state.sound;setPref('sound',state.sound);soundIcon();if(state.sound)playSound('tap');};
    $('logic-fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{notify('Kh\u00f4ng th\u1ec3 b\u1eadt to\u00e0n m\u00e0n h\u00ecnh.');}};
    $('logic-modal-close').onclick=closeModal;
    $('logic-modal').onclick=e=>{if(e.target===$('logic-modal'))closeModal();};
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('logic-modal').hidden)closeModal();});
  }
  function soundIcon(){$('logic-sound').textContent=state.sound?'\u266b':'\u266a\u0338';$('logic-sound').setAttribute('aria-pressed',String(state.sound));}
  async function init(){
    bind();soundIcon();
    if(!levels[state.level])state.level='easy';
    document.body.classList.toggle('reduce-motion',state.reduceMotion);
    try{
      const data=await api('bootstrap');state.profiles=data.players;state.playerId=data.player_id;
      const remembered=getPref('player-id',state.playerId);
      if(remembered!==state.playerId&&state.profiles.some(p=>p.id===remembered)){
        try{await api('select_profile',{player_id:remembered});state.playerId=remembered;}catch{}
      }
      makeProfiles();newRound();
    }catch(err){feedback('Ch\u01b0a t\u1ea3i \u0111\u01b0\u1ee3c game. Ki\u1ec3m tra PHP nh\u00e9!','try');notify(err.message);}
  }
  init();
})();
