<?php
declare(strict_types=1);

/** PHP built-in-server router: only serve files that truly exist in public/. */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$root = realpath(__DIR__);
$requested = rawurldecode($path);

if ($requested === '/' || $requested === '/index.php') {
    return false;
}

$file = realpath(__DIR__ . DIRECTORY_SEPARATOR . ltrim($requested, '/'));
if ($file !== false && str_starts_with($file, $root . DIRECTORY_SEPARATOR) && is_file($file)) {
    return false;
}

http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
header('X-Content-Type-Options: nosniff');
echo '404 - File not found';
