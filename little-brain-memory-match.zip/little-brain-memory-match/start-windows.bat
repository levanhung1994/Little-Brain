@echo off
cd /d "%~dp0"
where php >nul 2>nul
if errorlevel 1 (
  echo PHP could not be found in PATH.
  echo Please install PHP 8.3+ or add its folder to PATH.
  pause
  exit /b 1
)
echo.
echo LITTLE BRAIN - 6 GAMES PC EDITION
echo Web address: http://127.0.0.1:8080
echo Close the separate PHP server window to stop the game.
echo.
start "Little Brain PHP Server" cmd /k php -S 127.0.0.1:8080 -t public public/router.php
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8080"
